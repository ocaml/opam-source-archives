/* --- Generated the 4/9/2015 at 17:28 --- */
/* --- heptagon compiler, version 1.00.06 (compiled fri. sep. 4 17:4:1 CET 2015) --- */
/* --- Command line: heptc -target c -s test -hepts autohiera3.ept --- */

#ifndef AUTOHIERA3_H
#define AUTOHIERA3_H

#include "autohiera3_types.h"
typedef struct Autohiera3__test_mem {
  Autohiera3__st v;
  int v_1;
  Autohiera3__st_1 ck;
  int pnr_1;
} Autohiera3__test_mem;

typedef struct Autohiera3__test_out {
  int st;
} Autohiera3__test_out;

void Autohiera3__test_reset(Autohiera3__test_mem* self);

void Autohiera3__test_step(int r, int r1, int e, Autohiera3__test_out* _out,
                           Autohiera3__test_mem* self);

#endif // AUTOHIERA3_H

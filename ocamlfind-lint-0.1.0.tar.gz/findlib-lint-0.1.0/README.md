# findlib-lint
Checking installed findlib META files.

By now, only checks that META files declare a ``archive`` variable
with a ``plugin`` predicate for each ``archive`` variable declared
with a ``native`` predicate.

Compilation and installation:
````
make
make install
````

Usage:
````
ocamlfind-lint     # check all installed packages
ocamlfind-lint pkg # check only the installed package pkg and its subpackages
````

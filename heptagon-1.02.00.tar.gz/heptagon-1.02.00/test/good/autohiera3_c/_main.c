/* --- Generated the 4/9/2015 at 17:28 --- */
/* --- heptagon compiler, version 1.00.06 (compiled fri. sep. 4 17:4:1 CET 2015) --- */
/* --- Command line: heptc -target c -s test -hepts autohiera3.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "_main.h"

Autohiera3__test_mem mem;
int main(int argc, char** argv) {
  int step_c;
  int step_max;
  int r;
  int r1;
  int e;
  Autohiera3__test_out _res;
  step_c = 0;
  step_max = 0;
  if ((argc==2)) {
    step_max = atoi(argv[1]);
  };
  Autohiera3__test_reset(&mem);
  while ((!(step_max)||(step_c<step_max))) {
    step_c = (step_c+1);
    
    if ((scanf("%d", &r)==EOF)) {
      return 0;
    };;
    
    if ((scanf("%d", &r1)==EOF)) {
      return 0;
    };;
    
    if ((scanf("%d", &e)==EOF)) {
      return 0;
    };;
    Autohiera3__test_step(r, r1, e, &_res, &mem);
    printf("%d\n", _res.st);
    fflush(stdout);
  };
  return 0;
}


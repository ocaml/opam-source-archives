/* --- Generated the 4/9/2015 at 17:28 --- */
/* --- heptagon compiler, version 1.00.06 (compiled fri. sep. 4 17:4:1 CET 2015) --- */
/* --- Command line: heptc -target c -s test -hepts autohiera3.ept --- */

#ifndef _MAIN_H
#define _MAIN_H

#include "autohiera3.h"
#endif // _MAIN_H

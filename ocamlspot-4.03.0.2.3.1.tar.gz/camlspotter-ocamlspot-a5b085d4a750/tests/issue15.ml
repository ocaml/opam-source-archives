open Issue15_2

include F(struct end)

let x = T (* ? T *) (* CR jfuruse: BUG here *)


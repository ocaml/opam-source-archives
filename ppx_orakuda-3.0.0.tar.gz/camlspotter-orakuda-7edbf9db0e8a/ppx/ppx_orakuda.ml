class orakuda = object
  inherit P_sprintf.sprintf as super

  (*  [%name "hello"] ==> {name|hello|name}
      [%name {|hello|}] ==> {name|hello|name}
  *)
  method !expr = function
    | { pexp_desc = Pexp_extension ( {txt=("fmt"|"qq"|"qx"|"m"|"s" as name)},
                                     PStr [ { pstr_desc= Pstr_eval (e, _) } ] ) } ->
        begin match e.pexp_desc with
        | Pexp_constant (Pconst_string (s, (Some "" | None))) ->
            super#expr { e with pexp_desc = Pexp_constant (Pconst_string (s, Some name)) }
        | Pexp_constant (Pconst_string (_s, Some _x)) ->
            assert false
        | _ -> assert false
        end
    | e -> super#expr e

end

let mapper = Ast_mapper_class.to_mapper (new orakuda)

let () = 
  Ppxx.Ppx.run [] "ppx_orakuda" (fun () -> ()) mapper

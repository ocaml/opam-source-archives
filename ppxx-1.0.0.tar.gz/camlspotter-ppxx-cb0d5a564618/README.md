# PPXX: a small extension library for PPX

PPXX contains several utility functions to make PPX preprocessors easier.

let version = "1.0.2"
let date = "Mon Feb 9 15:38:20 CET 2015"
let libdir = "/usr/local/lib/cubicle"

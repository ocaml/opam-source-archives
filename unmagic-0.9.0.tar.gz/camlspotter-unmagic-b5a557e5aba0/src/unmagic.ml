open Spotlib.Spot
open Typerep_lib.Std
open Typerep

module O = Obj

(* [o] must be a block *)
let fields o =
  let sz = O.size o in
  let rec f st = function
    | -1 -> st
    | i -> f (O.field o i :: st) (i-1)
  in
  f [] (sz-1)

let not_supported_yet () = failwith "not supported yet"

type hash = int
type cache = (hash, (Obj.t * Typerep.packed list ref) list ref) Hashtbl.t

(* block size of int64

   sz = 1 + (4 + size_of(value) - 1) / sizeof(value)
      64bit arch: 1 + (8 + 8 - 1) / 8 = 2
      32bit arch: 1 + (8 + 4 - 1) / 4 = 3
*)
let sz_of_int64 = match Sys.word_size with
  | 32 -> 3
  | 64 -> 2
  | n -> failwithf "Unexpected Sys.word_size = %d" n
    
(* Unfortunately, sharing+cycle detection mode is VERY slow. 
   We should pre-scan the type and list the types which can be recursive,
   and record objects only of these recursive types.
*)  
let rec tag_check : type a . cache option -> a Typerep.t -> Obj.t -> unit = fun cache tr o -> 
  if O.is_int o then tag_check_non_block tr o
  else tag_check_block cache tr o

and tag_check_non_block : type a . a Typerep.t -> Obj.t -> unit = fun tr o -> 
  let tg : int = O.obj o in
  match tr with
  | Int -> 
      (* input_value fails in 32bit arch when it tries to read 64bit int,
         therefore we do not care about the size here.
      *)
      ()
  | Char when tg >= 0 && tg < 256 -> ()
  | Char -> failwithf "int %d is found where a char is expected" tg
  | Bool when tg = 0 || tg = 1 -> ()
  | Bool -> failwithf "int %d is found where a bool is expected" tg
  | Variant (v : a Variant.t) when not & Variant.is_polymorphic v -> 
      let num_cstrs = Variant.length v in
      let rec f ctag i =
        if i = num_cstrs then
          failwithf "int %d is out of range for a variant 0-ary tag (%d)" tg num_cstrs
        else
          match Variant.tag v i with
          | Variant.Tag t when Tag.arity t = 0 ->
              if tg = ctag then () (* found *) else  f (ctag+1) (i+1)
          | _ -> f ctag (i+1)
      in
      f 0 0
  | Variant (_v : a Variant.t) -> not_supported_yet ()
  | Option _ when tg = 0 -> () (* None *)
  | Option _ -> failwithf "int %d is found where option is expected" tg
  | List _ when tg = 0 -> () (* [] *)
  | List _ -> failwithf "int %d is found where list is expected" tg
  | Function _ -> assert false (* not supported *)
  | Named (_, Some z) -> tag_check_non_block (Lazy.force z) o (* manifest *)
  | Named _ -> failwith "Non manifest named type is not supported"

  | Lazy tr' -> tag_check_non_block tr' o (* Lazy.from_val <int> *)

  | _ -> failwithf "int %d is found where a block is expected" tg

and tag_check_block : type a . ?skip_cache: bool -> cache option -> a Typerep.t -> Obj.t -> unit = fun ?(skip_cache=false) cache tr o ->
  (* quickly determin worth cache checking *)
  let worth_caching =
    cache <> None
    && not skip_cache
    (* CR jfuruse: not good idea for -rectypes? *)
    && match tr with (* We should have a quick check is the type is recursive or not *)
       | Record r  -> not & Record.has_double_array_tag r (* non recursive data *)
       | String    -> false
       | Int32     -> false
       | Int64     -> false
       | Nativeint -> false
       | Float     -> false
       | Option _  -> false
       | Array _   -> false
       | Tuple _   -> false
       | Named _   -> false (* manifest types are cached as their expanded form *)
       | _ -> true
  in   
  let visited =
    worth_caching
    && match cache with
      | None -> assert false
      | Some cache -> 
          let h = Hashtbl.hash o in
          let packed_tr = Typerep.T tr in
          match Hashtbl.find cache h with
          | exception Not_found -> 
              Hashtbl.replace cache h (ref [o, ref [packed_tr]]); false
          | slot ->
              match List.assq o !slot with
              | exception Not_found -> 
                  slot := (o, ref [packed_tr]) :: !slot; false
              | packs when List.exists (fun ptr -> Typerep.same (Obj.magic packed_tr) (Obj.magic ptr)) !packs -> true (* Ouch we have no Typerep.same for packed *)
              | packs -> packs := packed_tr :: !packs; false
  in
  if visited then ()
  else
  let tg = O.tag o in (* We should not get the size here? *)
  match tr with
  | Variant (v : a Variant.t) when not & Variant.is_polymorphic v -> 
      let sz = O.size o in
      if tg > O.last_non_constant_constructor_tag then failwithf "invalid tag %d for a variant" tg
      else
        let num_cstrs = Variant.length v in
        let rec find_tag ctag i =
          if i = num_cstrs then failwithf "tag %d is too big for this variant type" tg
          else
            let Variant.Tag t = Variant.tag v i in
            let arity = Tag.arity t in
            if arity = 0 then find_tag ctag (i+1)
              else if tg <> ctag then find_tag (ctag+1) (i+1)
              else i
          in
        let i = find_tag 0 0 in
        let Variant.Tag t = Variant.tag v i in
        let arity = Tag.arity t in
        if sz <> arity then failwithf "arity %d does not match with this constructor's arity %d" sz arity
        else if sz = 1 then tag_check cache (Tag.traverse t) (O.field o 0)
        else
          (* This is not to be cached *)
          tag_check_block ~skip_cache:true cache (Tag.traverse t) o
  | Variant (_v : a Variant.t) -> not_supported_yet ()
  | Record r when Record.has_double_array_tag r && tg = O.double_array_tag ->
      let sz = O.size o in
      let rsz = Record.length r in
      if rsz <> sz then failwithf "float record size mismatch value=%d type=%d" sz rsz
  | Record r when Record.has_double_array_tag r ->
      failwithf "tag %d is found where a float record is expected" tg
  | Record _r when tg = O.double_array_tag ->
      failwith "float array tag is found where a non float record is expected"
  | Record r ->
      let sz = O.size o in
      let rsz = Record.length r in
      if rsz <> sz then failwithf "record size mismatch value=%d type=%d" sz rsz
      else
        for i = 0 to sz - 1 do
          let o' = O.field o i in
          let Record.Field f = Record.field r i in
          tag_check cache (Field.traverse f) o'
        done
  | String when tg = O.string_tag -> ()
  | String -> failwithf "tag %d is found where string is expeced" tg

  | Int32 when tg = O.custom_tag -> 
      (* sz = 1 + (4 + size_of(value) - 1) / sizeof(value)
         64bit arch: 1 + (4 + 8 - 1) / 8 = 2
         32bit arch: 1 + (4 + 4 - 1) / 4 = 2
         (x*8)bit arch: 1 + (4 + x - 1) / x = 2
      *)
      let sz = O.size o in
      if sz = 2 then () 
      else failwithf "size %d is found where int32 (size=2) is expeced" sz
  | Int32 -> failwithf "tag %d is found where int32 is expeced" tg

  | Int64 when tg = O.custom_tag ->
      (* sz = 1 + (8 + size_of(value) - 1) / sizeof(value)
         64bit arch: 1 + (8 + 8 - 1) / 8 = 2
         32bit arch: 1 + (8 + 4 - 1) / 4 = 3
      *)
      let sz = O.size o in
      if sz = sz_of_int64 then ()
      else failwithf "size %d is found where int64 (size=%d) is expected" sz sz_of_int64
  | Int64 -> failwithf "tag %d is found where int64 is expeced" tg
      
  | Nativeint when tg = O.custom_tag ->
      (* sz = 1 + (size_of_(intnat) + size_of(value) - 1) / sizeof(value)
         64bit arch: 1 + (8 + 8 - 1) / 8 = 2
         32bit arch: 1 + (4 + 4 - 1) / 4 = 2
      *)
      let sz = O.size o in
      if sz = 2 then () 
      else failwithf "size %d is found where natint (size=2) is expeced" sz
  | Nativeint -> failwithf "tag %d is found where natint is expeced" tg

  | Float when tg = O.double_tag -> ()
  | Float -> failwithf "tag %d is found where float is expected" tg
  | Bool  -> failwithf "tag %d is found where bool is expected" tg
  | Int   -> failwithf "tag %d is found where int is expected" tg
  | Char  -> failwithf "tag %d is found where char is expected" tg
  | Unit  -> failwithf "tag %d is found where unit is expected" tg
  | Option tr when tg = 0 && O.size o = 1 -> tag_check cache tr (O.field o 0)
  | Option _ -> failwithf "tag %d is found where option is expected" tg
  | List tr' when tg = 0 && O.size o = 2 -> 
      tag_check cache tr' (O.field o 0);
      tag_check cache tr  (O.field o 1)
  | List _ -> failwithf "tag %d is found where list is expected" tg
  | Array Float when tg = O.double_array_tag -> ()
  | Array _ when tg = O.double_array_tag -> failwith "float array tag is found where non float array is expected"
  | Array tr -> List.iter (tag_check cache tr) & fields o
  | Tuple (Tuple.T2 (tr1, tr2)) when O.size o = 2 ->
      let o1 = O.field o 0
      and o2 = O.field o 1
      in
      tag_check cache tr1 o1; tag_check cache tr2 o2
  | Tuple (Tuple.T3 (tr1, tr2, tr3)) when O.size o = 3 ->
      let o1 = O.field o 0
      and o2 = O.field o 1
      and o3 = O.field o 2
      in
      tag_check cache tr1 o1; tag_check cache tr2 o2; tag_check cache tr3 o3
  | Tuple (Tuple.T4 (tr1, tr2, tr3, tr4)) when O.size o = 4 -> 
      let o1 = O.field o 0
      and o2 = O.field o 1
      and o3 = O.field o 2
      and o4 = O.field o 3
      in
      tag_check cache tr1 o1; tag_check cache tr2 o2; tag_check cache tr3 o3; tag_check cache tr4 o4
  | Tuple (Tuple.T5 (tr1, tr2, tr3, tr4, tr5)) when O.size o = 5 ->
      let o1 = O.field o 0
      and o2 = O.field o 1
      and o3 = O.field o 2
      and o4 = O.field o 3
      and o5 = O.field o 4
      in
      tag_check cache tr1 o1; tag_check cache tr2 o2; tag_check cache tr3 o3; tag_check cache tr4 o4; tag_check cache tr5 o5
  | Tuple (Tuple.T2 _) -> failwithf "block size %d is found where 2-tuple is expected" tg
  | Tuple (Tuple.T3 _) -> failwithf "block size %d is found where 3-tuple is expected" tg
  | Tuple (Tuple.T4 _) -> failwithf "block size %d is found where 4-tuple is expected" tg
  | Tuple (Tuple.T5 _) -> failwithf "block size %d is found where 5-tuple is expected" tg 

  | Lazy _ when tg = O.lazy_tag -> failwith "lazy closure is not supported"
  | Lazy tr' when tg = O.forward_tag ->
      let o' = O.field o 0 in
      if O.is_block o' then
        let tg' = O.tag o' in
        if tg' = O.forward_tag || tg' = O.lazy_tag || tg' = O.double_tag then
          tag_check_block cache tr' o'
        else
          failwithf "tag %d is found in a forwarded block where forward/lazy/double tag is expected" tg'
      else
        failwithf "int %d is found in a forwarded block where forward/lazy/double tag is expected" (O.obj o' : int)
  | Lazy tr' ->
      if tg = O.double_tag then 
        failwithf "unexpected double tag is found for a forced lazy value";
      tag_check_block cache tr' o

  | Ref tr' ->
      let sz = O.size o in
      if sz = 1 then tag_check_block cache tr' (O.field o 0)
      else failwithf "block size %d is found where an ref is expected" sz

  | Function _ -> failwith "function is not supported"
  | Named (_, Some z) -> tag_check_block cache (Lazy.force z) o
  | Named _ -> failwith "Non manifest named type is not supported"

let tag_check : type a . sharing:bool -> a Typerep.t -> Obj.t -> unit = fun ~sharing:b tr o ->
  tag_check (if b then Some (Hashtbl.create 107) else None) tr o

let obj ~sharing tyrep o =
  tag_check ~sharing tyrep o;
  Obj.obj o

# Wasmer Documentation Assets

This directory contains documentation assets.

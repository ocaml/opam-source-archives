# Wasmer Benches

This directory contains small, punctual benches. Other benchmarks are
landing somewhere else. We will update this section soon.

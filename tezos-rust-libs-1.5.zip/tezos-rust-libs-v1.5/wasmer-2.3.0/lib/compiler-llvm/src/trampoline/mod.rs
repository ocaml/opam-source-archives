mod wasm;

pub use self::wasm::FuncTrampoline;

open Ppxx (* must come after Ast_helper *)
open Ast_mapper

let mapper = 
  Comprehension.extend & Pattern_guard.extend & Do_.extend default_mapper

let () = Ppxx.run "ppx_monadic" mapper

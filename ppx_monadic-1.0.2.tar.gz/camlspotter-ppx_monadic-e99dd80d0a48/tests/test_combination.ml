module Option = struct
  let bind e f = match e with
    | Some v -> f v
    | None -> None
  let return v = Some v
end

(* pattern guard => do_ *)
let t = match () with
  | () when Some x <-- Some 1 -> do_;
      Option.return x
  | _ -> assert false

(* do_ => pattern guard *)
let t2 = Option.do_;
  match () with
  | () when Some x <-- Some 1 -> return x
  | _ -> assert false

(* do_ => do_ *)
let t3 = Option.do_;
  x <-- (Option.do_;
         return 1);
  return x

(* pattern guard => pattern guard *)
let t4 =
  match () with
  | () when Some x <-- begin match () with
                       | () when Some x <-- Some 1 -> Some x
                       | _ -> assert false
                       end ->
      begin match () with
      | () when Some y <-- Some 1 -> x + y
      | _ -> assert false
      end
  | _ -> assert false

(* list comp => list comp *)
let t5 = [%comp x || x <-- [%comp x || x <-- [1;2;3]]]
  
      

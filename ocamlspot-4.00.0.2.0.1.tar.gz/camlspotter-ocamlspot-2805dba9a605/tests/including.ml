include Included

module M : S (* ? S *) = struct
  let x = 1
end

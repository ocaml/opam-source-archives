open Planck

module Stream = Schar

module Parser = struct
  module Base = Pbase.Make(Stream)

  include Base
  include Pbuffer.Extend(Stream)(Base)
end



module M6 : sig
  class ci : int -> object end      
end = struct
end

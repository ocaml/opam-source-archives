open Ocamlbuild_plugin

let () = dispatch Ocb_stubblr.init


type 'a t = string * 'a option ref

let create name = name, ref None

exception Already_initialized of string
exception Not_initialized of string

let set x v = match x with
  | (name, {contents = Some _}) -> raise (Already_initialized name)
  | (_, r) -> r := Some v

let get x = match x with
  | (_name, {contents = Some v}) -> v
  | (name, _) -> raise (Not_initialized name)

## v0.2.0 (2024-03-18)

* Rename pp to pp_hexdump
* Add a pp which just prints the hex with some spaces, but no newlines

## v0.1.0 (2024-03-14)

* Initial release

open Camlp4                                             (* -*- camlp4of -*- *)

module Id : Sig.Id = struct
  let name = "pa_extlex"
  let version = "1.0"
end

module Make (Syntax : Sig.Camlp4Syntax) = struct
  (* open Sig *)
  include Syntax
  module Xlexer = Xlexer.Make(Token)
  let _ = 
    Gram.set_from_lexbuf (fun ?quotations lb ->
      Xlexer.from_lexbuf ?quotations lb)
end

let module M = Register.OCamlSyntaxExtension(Id)(Make) in ()

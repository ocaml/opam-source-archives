let f x y = (x$+{y} <- 1);;

let _ = $s/pattern/00/;;
let _ = $s/pattern/$0/;;
let s = $s/l+/$&$&/g "hello world";;

let fmt = 
  Extprintf.format 
    <string>
    [ String "hello" ;
      Char '%';
      Format "%d";
      Exec_buf (Obj.magic (Extprintf.format_int : _ -> int -> _))
    ]
;;

let _ = Orakuda.Std.Extprintf.Sprintf.exec 10 fmt

let fmt = 
  Extprintf.format 
    <string>
    [ Percent_s; Percent_s ]
;;

(*
let fmt : string Format.t =
  fun out st ->
    let args = st.args in
    Out.out_string out args.(0);
    Out.out_string out args.(1);
    Out.finish out
*)

let _ = Orakuda.Std.Extprintf.Sprintf.exec 10 fmt

let _ = $%"xxx%syyy%dzzz";;
let _ = let x = 1 in $%"xxx%syyy%${x}dzzz";;

let _ = let x = 1 and y = 2 in $%"%d%${x}d%d%${y}d%d";;

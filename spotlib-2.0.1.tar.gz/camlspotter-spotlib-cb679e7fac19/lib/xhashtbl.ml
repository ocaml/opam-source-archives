let replace_list tbl kvs = 
  List.iter (fun (k,v) ->
    Hashtbl.replace tbl k v) kvs

let of_list size kvs =
  let tbl = Hashtbl.create size in
  List.iter (fun (k,v) ->
    Hashtbl.replace tbl k v) kvs;
  tbl
  
let to_list tbl = Hashtbl.fold (fun k v st -> (k,v) :: st) tbl []

let find_opt tbl k = try Some (Hashtbl.find tbl k) with Not_found -> None

let alter tbl k f =
  match f (find_opt tbl k) with
  | None -> Hashtbl.remove tbl k
  | Some v -> Hashtbl.replace tbl k v

package Test_desynch_op;


public class F {
    protected Desynch.Comm n_1;
    
    public F () {
        this.n_1 = new Desynch.Comm();
        
    }
    public int step (boolean a_1, boolean b_1, int x) {
        int y = 0;
        int v_1 = 0;
        int v = 0;
        v = (x + 1);
        v_1 = n_1.step(a_1, b_1, v);
        y = (v_1 * 2);
        return y;
    }
    public void reset () {
        
    }
}

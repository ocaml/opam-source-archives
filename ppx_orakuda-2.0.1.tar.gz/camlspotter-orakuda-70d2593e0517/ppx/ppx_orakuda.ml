class orakuda = object
  inherit P_sprintf.sprintf as super

  (*  name $ "hello" ==> {name|hello|name}
      name $ {|hello|} ==> {name|hello|name}
  *)
  method !expr = function
    | { pexp_desc = Pexp_extension ( {txt=("fmt"|"qq"|"qx"|"m"|"s" as name)},
                                     PStr [ { pstr_desc= Pstr_eval (e, _) } ] ) } ->
        begin match e.pexp_desc with
        | Pexp_constant (Const_string (s, (Some "" | None))) ->
            super#expr { e with pexp_desc = Pexp_constant (Const_string (s, Some name)) }
        | Pexp_constant (Const_string (_s, Some _x)) ->
            assert false
        | _ -> assert false
        end
    | e -> super#expr e

end

let mapper = Ast_mapper_class.to_mapper (new orakuda)

let () = 
  let debug = ref false in
  let rev_files = ref [] in 
  Arg.parse 
    [ "-debug", Arg.Set debug, "debug mode which can take .ml/.mli then print the result"
(*
     "-drop-tests", Arg.Set drop_tests, "Drop unit tests"
    ; "-top-name", Arg.String (fun s -> top_name := Some (parse_as_lident s)), "Set the top module name" 
*)
    ]
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    "ppx_orakuda";
  match !debug, List.rev !rev_files with
  | true, files ->
      List.iter (Ppxx.test mapper) files
  | false, [infile; outfile] ->
      Ast_mapper.apply ~source:infile ~target:outfile mapper
  | _ -> 
      failwith "ppx_test infile outfile"


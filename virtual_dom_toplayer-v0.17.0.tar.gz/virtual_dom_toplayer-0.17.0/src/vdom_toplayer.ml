open! Core

let tooltip = Tooltip.attr
let popover = Popover.attr
let popover_custom = Popover.node

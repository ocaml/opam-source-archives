#require "R.math"

let x = Rmath.pow 2.

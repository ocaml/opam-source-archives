let _ = Array.set

let f1 a x = a.(x)
let f2 a x = a.(x) <- 1

let f3 a x = a.[x]
let f4 a x = a.[x] <- 1

let f5 a x = a.{x}
let f6 a x = a.{x} <- 1

let f7 a x y = a.{x,y}
let f8 a x y = a.{x,y} <- 1

let f9 a x y z = a.{x,y,z}
let f10 a x y z = a.{x,y,z} <- 1

let f11 a x y z w = a.{x,y,z,w}
let f12 a x y z w = a.{x,y,z,w} <- 1
                                 

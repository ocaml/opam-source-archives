# ppx_dotbracket

`ppx_dotbracket` is a PPX extension to rebind "dot-bracket" expressions.  It replaces:

* `a.(x)` by `DotBracket.Array.get a x`
* `a.(x) <- e` by `DotBracket.Array.set a x e`
* `a.[x]` by `DotBracket.String.get a x`
* `a.[x] <- e` by `DotBracket.String.set a x e`
* `a.{..}` by `DotBracket.BigArray.*.get a ..`
* `a.{..} <- e` by `DotBracket.BigArray.*.set a .. e`

if `-unsafe` option is given to the compiler, `DotBracket.*.unsafe_get` 
and `DotBracket.*.unsafe_set` are used instead of 
`DotBracket.*.get` and `DotBracket.*.set` respectively.

`ppx_dotbracket` keeps non bracket accesses like `Array.get a x` as they are.

To use `ppx_dotbracket` correctly you have to define a module `DotBracket`
with necessary value definitions.  For example, the following definition of `DotBrackets`:

```ocaml
module DotBracket = struct
  module String = struct
	let get = Bytes.get
	let set = Byts.set
  end
end
```

replaces `a.[x]` and `a.[x] <- e` from for `string` to for `bytes`.

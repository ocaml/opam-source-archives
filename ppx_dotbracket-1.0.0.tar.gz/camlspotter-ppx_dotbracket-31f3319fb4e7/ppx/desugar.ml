open Ast_405

open Ast_mapper
(*
open Ppxx.Utils
open Ppxx.Helper
*)
open Ppxx.Compilerlib
open Parsetree
open Longident
open Location
open Asttypes

let rec prefix p = function
  | Lident s -> Ldot (Lident p, s)
  | Ldot (t1, s) -> Ldot (prefix p t1, s)
  | Lapply _ -> assert false
  
let extend super = 
  let expr self e = match e.pexp_desc with
    | Pexp_apply( ({ pexp_loc;
                     pexp_desc = Pexp_ident { txt= (Ldot (m, f) as lid); loc= loc } } as fn), 
                  args ) when pexp_loc.loc_ghost && loc.loc_ghost -> 
       begin match Longident.to_string m, f with
       | ("Array" | "String" | "Bigarray.Genarray" | "Bigarray.Array1" | "Bigarray.Array2" | "Bigarray.Array3" ), ("get" | "set" | "unsafe_get" | "unsafe_set") -> 
          let fn' = { fn with pexp_desc= Pexp_ident { txt= prefix "DotBracket" lid; loc } } in
          { e with pexp_desc = Pexp_apply ( fn', args ) }
       | _ -> super.expr self e
       end
    | _ -> super.expr self e
  in
  { super with expr }

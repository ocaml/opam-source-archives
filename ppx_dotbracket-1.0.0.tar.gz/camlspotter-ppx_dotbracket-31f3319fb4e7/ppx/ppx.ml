open Ast_405

(* open Ppxx.Utils (* must come after Ast_helper *) *)
open Ast_mapper

include Ppxx.Ppx.Make(struct
    let name = "ppx_dotbracket"
    let options = []
    let make_mapper _ _ = Desugar.extend default_mapper
  end)


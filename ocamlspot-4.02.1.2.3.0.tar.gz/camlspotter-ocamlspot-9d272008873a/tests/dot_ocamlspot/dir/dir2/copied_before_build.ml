let x = 42

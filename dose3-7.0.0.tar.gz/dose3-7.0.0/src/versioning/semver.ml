let compare = SemverNode.compare

let equal = SemverNode.equal

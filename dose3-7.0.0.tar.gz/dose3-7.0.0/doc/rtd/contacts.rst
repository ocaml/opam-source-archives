[[!meta title=“Get In Touch”]]

Authors And Contributors
~~~~~~~~~~~~~~~~~~~~~~~~

Active Developers :

-  Main Developer [[Pietro Abate|http://mancoosi.org/~abate/]]
-  [[Roberto Di Cosmo|http://www.dicosmo.org/]]
-  [[Johannes Schauer|https://blog.mister-muffin.de/]]
-  Cudf Author : [[Stefano Zacchiroli|https://upsilon.cc/~zack/]]
-  [[Ralf Treinen|http://www.pps.univ-paris-diderot.fr/~treinen/]]

Past contributors :

-  Jaap Boender
-  Jakub Zwolakowski
-  Olivier Rosello

Want to help ?
~~~~~~~~~~~~~~

-  Dose-devel :
   [[Archives|https://lists.gforge.inria.fr/pipermail/dose-devel/]] \|
   [[Subscribe/Unsubscribe/Preferences|https://lists.gforge.inria.fr/mailman/listinfo/dose-devel]]

-  Report a bug in our
   [[BTS|https://gforge.inria.fr/tracker/?group_id=4395]]

-  Check out Continous integration [[page|https://ci.inria.fr/dose/?]]

-  Follow us on [[identi.ca|http://identi.ca/group/dose3]]

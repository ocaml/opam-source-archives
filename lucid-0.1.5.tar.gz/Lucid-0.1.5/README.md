# Lucid
Super simple logging library for OCaml.

Lucid has no runtime dependencies, but it requires [dune](https://dune.build/) for building.

<br/>

## Installation
Lucid is available through opam
```
opam install lucid
```
<br/>

## Contact 
You can reach me on Discord - `Rhaenys#3166`

<br/>

## Contributions
Contributions and suggestions of any kind are welcome, further, see [CONTRIBUTING.md](https://github.com/kodwx/Lucid/blob/main/CONTRIBUTING.md).
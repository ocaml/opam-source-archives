Contributions of any kind to this project are welcome and appreciated. 

They should be submitted via GitHub pull requests or issues.

<br />

## Signing Contributions
In case of pull requests, your contributions should be signed.
If your signature certifies [this](https://developercertificate.org/), then simply add your real name and your email in the end of every git commit message.
```
Tarun Agarwal <me@tarunagarwal.me>
```
You can also use `git commit -s` if you have set up your git configs.
open Ast_mapper

module F(A : sig
  val tool_name : string
  val args : (Arg.key * Arg.spec * Arg.doc) list
  val firstUntypedTransformation : mapper
  module Typemod : S.Typemod
  module TypedTransformation : S.TypedTransformation
  val lastUntypedTransformation : mapper
end) = struct

  open A
      
  module Compile = Compile.Make(Typemod)(TypedTransformation)
    
  let dump_first = ref None
  let dump_untype = ref None

  let dump path ast = match path with
    | None -> ()
    | Some path ->
        let oc = open_out path in
        let ppf = Format.formatter_of_out_channel oc in
        begin match ast with
        | `Str str -> Pprintast.structure ppf str
        | `Sig sg -> Pprintast.signature ppf sg
        end;
        Format.pp_print_newline ppf ();
        close_out oc

  let dump_str path str = dump path (`Str str); str
  let dump_sig path sg  = dump path (`Sig sg);  sg
    
  (* The PPX mapper *)
    
  let mapper = match Ast_mapper.tool_name () with
    | "ocamldep" ->
        (* If the tool is ocamldep, we CANNOT type-check *)
        firstUntypedTransformation
    | _ ->
        let structure _x str =
          Clflags.dont_write_files := true;
          Warnings.parse_options false "a"; (* print warning *)
          Warnings.parse_options true  "a"; (* warning as error *)
          firstUntypedTransformation.structure firstUntypedTransformation str
          |> dump_str !dump_first 
          |> Compile.implementation Format.err_formatter "papa" (* dummy *) "gaga" (* dummy *)
          |> dump_str !dump_untype
          |> lastUntypedTransformation.structure lastUntypedTransformation
        in
        let signature _x sg =
          Clflags.dont_write_files := true;
          Warnings.parse_options false "a"; (* print warning *)
          Warnings.parse_options true  "a"; (* warning as error *)
          firstUntypedTransformation.signature firstUntypedTransformation sg
          |> dump_sig !dump_first
          |> Compile.interface Format.err_formatter "papa" (* dummy *) "gaga" (* dummy *)
          |> dump_sig !dump_untype
          |> lastUntypedTransformation.signature lastUntypedTransformation
        in
        { default_mapper with structure; signature }

  let opts =
    let set_string_opt r = Arg.String (fun s -> r := Some s) in
    [( "-typpx-dump-first", set_string_opt dump_first, "<path>: (TyPPX) Dump the result of the first untyped transformation stage");
     ( "-typpx-dump-untype", set_string_opt dump_untype, "<path>: (TyPPX) Dump the result of the untype stage");
     ( "-dump-typpx-first", set_string_opt dump_first, "OBSOLETE. Use -typpx-dump-first");
     ( "-dump-typpx-untype", set_string_opt dump_untype, "OBSOLTE. Use -typpx-dump-untype");
    ]
    
  let run () = Ppxx.Ppx.run (args @ opts) tool_name (fun () -> ()) mapper
end


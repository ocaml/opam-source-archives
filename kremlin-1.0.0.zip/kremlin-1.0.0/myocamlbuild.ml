open Ocamlbuild_plugin

let _ =
  flag ["ocaml"; "doc"] (A"-stars")

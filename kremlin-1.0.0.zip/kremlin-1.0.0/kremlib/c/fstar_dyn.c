/* Copyright (c) INRIA and Microsoft Corporation. All rights reserved.
   Licensed under the Apache 2.0 License. */

#include <kremlin/internal/types.h>

FStar_Dyn_dyn FStar_Dyn_mkdyn_(void *x) {
  return x;
}

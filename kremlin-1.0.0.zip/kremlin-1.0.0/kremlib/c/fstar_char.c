/* Copyright (c) INRIA and Microsoft Corporation. All rights reserved.
   Licensed under the Apache 2.0 License. */

#include "FStar_Char.h"

FStar_Char_char FStar_Char_char_of_u32(uint32_t x) {
  return x;
}

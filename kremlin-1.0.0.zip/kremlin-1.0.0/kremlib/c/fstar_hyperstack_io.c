/* Copyright (c) INRIA and Microsoft Corporation. All rights reserved.
   Licensed under the Apache 2.0 License. */

#include "FStar_HyperStack_IO.h"

void FStar_HyperStack_IO_print_string(Prims_string s) {
  KRML_HOST_PRINTF("%s", s);
}

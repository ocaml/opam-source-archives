.. The KreMLin user manual documentation master file, created by
   sphinx-quickstart on Mon Apr 23 15:16:54 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

The KreMLin user manual and documentation
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Introduction
   Setup
   Core
   TocLibraries
   TocExamples
   Toy
   AdvancedTips
   AdvancedTopics


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

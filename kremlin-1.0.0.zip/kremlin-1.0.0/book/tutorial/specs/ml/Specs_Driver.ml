(* One might want to do fancier things here, e.g. read from a list of input
 * vectors stored in a file, or in JSON, who knows... *)

let _ =
  Spec_Test.test ();
  print_endline "All tests executed successfully! 🕺"

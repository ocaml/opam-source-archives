# How to build

```
$ git clone https://github.com/FStarLang/kremlin.git
$ cd kremlin
$ git clone https://github.com/fstarlang/fstar-mode.el
$ pip3 install sphinx_rtd_theme
$ cd book
$ make html
$ x-www-browser _build/html/index.html
```

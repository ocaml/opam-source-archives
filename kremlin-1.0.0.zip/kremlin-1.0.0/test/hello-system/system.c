const char *null_string = 0;
int ai_protocol_any = 0;

(* camlp5r *)
(* pa_deriving.ml,v *)
(* Copyright (c) INRIA 2007-2017 *)


Surveil.install();
Pa_deriving.install();


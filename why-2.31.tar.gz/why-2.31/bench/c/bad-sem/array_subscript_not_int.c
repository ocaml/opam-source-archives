int t[5];
int x = t[1.2];

void f (){
  int x = 0x100000000ul;
}

Ptests_config.default_suites:= [ "jessie"; ];;
Ptests_config.toplevel_path :="/usr/local/bin/frama-c";;
Ptests_config.framac_share :="/usr/local/share/frama-c";;
Ptests_config.framac_plugin :=".";;
Ptests_config.framac_plugin_gui :="./gui";;
Ptests_config.framac_lib :="/usr/local/lib/frama-c";;

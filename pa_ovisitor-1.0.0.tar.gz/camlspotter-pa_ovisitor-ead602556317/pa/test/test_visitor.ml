type t = Foo of int * float | Bar with ovisit


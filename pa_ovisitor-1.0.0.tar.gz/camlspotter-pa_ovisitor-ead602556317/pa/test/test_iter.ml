let sum = ref 0 

type 'a t = 
  | Foo of int list 
  | Bar of int * int * 'a
with ovisit

class o' = object (self:'self)
  inherit ovisit
  val mutable st = 0
  method st = st
  method int n = st <- st + n; self
  method list = fun fa xs -> List.fold_left (fun self x -> fa self x) self xs
  method unit () = self
end


let _ = 
  let v = new o' in
  assert ((v#t (fun v -> v#int) (Foo [ 1; 2; 3; 4; 5 ]))#st = 15);
  let v = new o' in
  assert ((v#t (fun v -> v#int) (Bar (1, 2, 3)))#st = 6);
  let v = new o' in
  assert ((v#t (fun v -> v#unit) (Bar (1, 2, ())))#st = 3)

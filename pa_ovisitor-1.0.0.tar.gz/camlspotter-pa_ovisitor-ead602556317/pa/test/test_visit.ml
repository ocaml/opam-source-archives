type x1 = int list with ovisit
type 'a x2 = 'a list with ovisit
type x3 = Hoo.t with ovisit
type x4 = (int, float) Hashtbl.t with ovisit

type x5 = Foo | Bar with ovisit
type x6 = Foo of int | Bar with ovisit
type x7 = Foo of int * float | Bar with ovisit
type 'a x8 = Foo of 'a * float with ovisit
type tup = int * float with ovisit

type tup2 = Foo of (int * float) with ovisit
type re1 = { l : int } with ovisit
type re2 = { l : int; r : float } with ovisit
type ('a, 'b) re3 = { l : 'a; r : 'b } with ovisit
type re4 = { mutable l : int } with ovisit

type e = { desc : edesc; loc : int }
and edesc = Foo of e 
with ovisit

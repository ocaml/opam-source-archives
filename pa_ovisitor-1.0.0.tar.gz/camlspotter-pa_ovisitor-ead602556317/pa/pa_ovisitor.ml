open Camlp4
open PreCast
open Pa_type_conv
open Ast

include Tctools

let _loc = Loc.ghost

(** A.x => A.visit_x *)
let rec visit_id = function
  | IdAcc (loc, a, b) -> IdAcc (loc, a, visit_id b)
  | IdLid (loc, s) -> IdLid (loc, "visit_" ^ s)
  | id -> id

let no_visit_idents = ref []

let is_no_visit_ident id = List.mem (strip_ident_loc id) !no_visit_idents

module StringSet = Set.Make(struct type t = string let compare (x : string) y = compare x y end)
module StringMap = Map.Make(struct type t = string let compare (x : string) y = compare x y end)

module Visitor = struct

  let used = ref StringMap.empty
  let defined = ref StringSet.empty
  let reset_sets () = used := StringMap.empty; defined := StringSet.empty


  let rec gen_ctyp : ctyp -> expr option = function
    | TyId (_loc, id) 
    | TyApp (_loc, TyId(_, id), _) when is_no_visit_ident id -> None
    | TyId (loc, id) -> 
        if not (StringMap.mem (label_of_path id) !used) then
          used := StringMap.add (label_of_path id) 0 !used;
        Some <:expr@loc< self # $label_of_path id$ >>
    | (TyQuo (loc, _) as tv) -> Some <:expr@loc< $ expr_of_tvar tv $ self >>
    | TyApp (loc, (TyId(_, id) as f), args) ->  (* (int, float) Hashtbl.t *)
        let args = list_of_ctyp args [] in
        used := StringMap.add (label_of_path id) (List.length args) !used;
        begin match gen_ctyp f with
        | None -> None
        | Some f -> 
            Some (Gen.apply loc f (List.map (fun x -> match gen_ctyp x with 
            | None -> <:expr<fun self _ -> self>> 
            | Some f -> <:expr< fun self -> $f$ >> ) args))
        end
    | TyApp (loc, TyApp (_loc, f, args1), args2) -> 
        gen_ctyp (TyApp (loc, f, TyCom(_loc, args1, args2)))
    | TyTup (loc, ctyp) ->
        let ctyps = list_of_ctyp ctyp [] in
        let ids = mk_idents "__x" (List.length ctyps) in
        Some (Gen.abstract loc [ PaTup (loc, paCom_of_list (List.map patt_of_id ids)) ]
          (gen_let_seq ctyps (List.map expr_of_id ids)))
    | _ -> assert false
  
  and gen_let_seq ctyps exps = match ctyps, exps with
    | [], [] -> <:expr< self >>
    | (ctyp::ctyps), (exp::exps) ->
        begin match gen_ctyp ctyp with
        | None -> gen_let_seq ctyps exps
        | Some f -> <:expr< let self = $f$ $exp$ in $ gen_let_seq ctyps exps $ >>
        end
    | _ -> assert false
  
  let alias _name _loc cty = 
    match gen_ctyp cty with
    | None -> <:expr< >>
    | Some f -> <:expr< fun __value -> $f$ __value >>
  
  let is_just_self_case = function
    | <:match_case< $_$ -> self >> -> true
    | _ -> false
  
  let sum _name _loc ctyp = 
    let constrs = list_of_ctyp ctyp [] in (* decompose TyOr *)
    let case locOf locId id ctyp =
      let ctyps = list_of_ctyp ctyp [] in (* decompose TyAnd *)
      let ids = mk_idents "__x" (List.length ctyps) in
      let patt = create_patt_app (PaId(locId, id)) (List.map patt_of_id ids) in
      let exp = match ids with
        | [] -> <:expr< self >>
        | _ -> gen_let_seq ctyps (List.map expr_of_id ids)
      in
      <:match_case@locOf< $ patt $ -> $ exp $ >>
    in
    let cases = 
      List.map (function
        | TyOf (locOf, TyId(locId, id), ctyp) -> case locOf locId id ctyp
        | TyId (locId, id) -> case locId locId id (TyNil _loc)
        | _ -> assert false
      ) constrs 
    in
    if List.for_all is_just_self_case cases then
      <:expr< fun __value -> self >>
    else
      <:expr< fun __value -> match __value with $mcOr_of_list cases$ >>
  
  let record _name _loc ctyp = 
    let get_lab cty = match strip_field_flags cty with
      | TyId(_, id) -> id
      | _ -> assert false
    in
    let ctyps = list_of_ctyp ctyp [] in (* decomp TySems *)
    let labs, ctyps = List.split (List.map (function
      | TyCol (_, l, ctyp) -> get_lab l, strip_field_flags ctyp
      | _ -> assert false) ctyps)
    in
    let mems = List.map (fun l -> <:expr< __value.$id:l$ >> ) labs in 
    <:expr< fun __value -> $gen_let_seq ctyps mems $ >>
    
  (** for [X; Y; .. ] and BASE, build ('self -> X -> 'self) -> ('self -> Y -> 'self) -> ... -> BASE *)
  let dispatch_type params base = 
    List.fold_right (fun ctyp st -> <:ctyp< ('self -> $ctyp$ -> 'self) -> $st$ >>) params base
  
  let method_type params name = 
    create_for_all params (dispatch_type params <:ctyp< $ create_param_type params name $ -> 'self >>)
  
  
  (******************* kind of template *)
  
  let def name cty =
    let variants _ = assert false in
    let mani     _ = assert false in
    let nil      _ = assert false in
    let alias  = alias name in
    let sum    = sum name in
    let record = record name in
    Gen.switch_tp_def ~alias ~sum ~record ~variants ~mani ~nil cty
  
  
  let dcl _loc name (params : ctyp list) d =
    if is_no_visit_ident (IdLid (Loc.ghost, name)) then <:class_str_item<>>
    else begin
      defined := StringSet.add name !defined;
      <:class_str_item<
         method $name$ : $method_type params name$ = $Gen.abstract _loc (List.map patt_of_tvar params) (def name d)$
      >>
    end
  
  (* Add "of_sexp" and "sexp_of" as "sexp" to the set of generators *)
  let () = 
    Pa_type_conv.add_generator "ovisit" (fun _bool tds ->
      reset_sets ();
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in (* CR jfuruse: mutual *)
      let methods = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> 
            dcl loc name params def
        | _ -> assert false) decls
      in
      let vmethods = 
        let vmethods = StringSet.fold StringMap.remove !defined !used in
        if StringMap.is_empty vmethods then [] 
        else 
          StringMap.fold (fun name nargs st ->
            let params = 
              let ns = 1--nargs in
              List.map (fun n -> TyQuo (_loc, "a" ^ string_of_int n)) ns
            in
            <:class_str_item< method virtual $name$ : $method_type params name$ >> :: st) vmethods []
      in
      let methods = concat_class_str_items (vmethods @ methods) in
      if vmethods <> [] then
        <:str_item< class virtual ovisit = object (self:'self) $methods$ end >>
      else
        <:str_item< class ovisit = object (self:'self) $methods$ end >>
    )
  ;;
end


module Fold = struct

  let used = ref StringMap.empty
  let defined = ref StringSet.empty
  let reset_sets () = used := StringMap.empty; defined := StringSet.empty


  let rec gen_ctyp : ctyp -> expr option = function
    | TyId (_loc, id) 
    | TyApp (_loc, TyId(_, id), _) when is_no_visit_ident id -> None
    | TyId (loc, id) -> 
        if not (StringMap.mem (label_of_path id) !used) then
          used := StringMap.add (label_of_path id) 0 !used;
        Some <:expr@loc< self # $label_of_path id$ >>
    | (TyQuo (_loc, _) as tv) -> Some (expr_of_tvar tv)
    | TyApp (loc, (TyId(_, id) as f), args) ->  (* (int, float) Hashtbl.t *)
        let args = list_of_ctyp args [] in
        used := StringMap.add (label_of_path id) (List.length args) !used;
        begin match gen_ctyp f with
        | None -> None
        | Some f -> 
            Some (Gen.apply loc f (List.map (fun x -> match gen_ctyp x with 
            | None -> <:expr<fun st _ -> st>> 
            | Some f -> f ) args))
        end
    | TyApp (loc, TyApp (_loc, f, args1), args2) -> 
        gen_ctyp (TyApp (loc, f, TyCom(_loc, args1, args2)))
    | TyTup (loc, ctyp) ->
        let ctyps = list_of_ctyp ctyp [] in
        let ids = mk_idents "__tup" (List.length ctyps) in
        Some (<:expr<fun st -> 
          $ Gen.abstract loc [ PaTup (loc, paCom_of_list (List.map patt_of_id ids)) ]
            (gen_let_seq ctyps (List.map expr_of_id ids)) $ >> )
    | _ -> assert false
  
  and gen_let_seq ctyps exps = match ctyps, exps with
    | [], [] -> <:expr< st >>
    | (ctyp::ctyps), (exp::exps) ->
        begin match gen_ctyp ctyp with
        | None -> gen_let_seq ctyps exps
        | Some f -> <:expr< let st = $f$ st $exp$ in $ gen_let_seq ctyps exps $ >>
        end
    | _ -> assert false
  
  let alias _name _loc cty = 
    match gen_ctyp cty with
    | None -> assert false
    | Some f -> f
  
  let is_just_self_case = function
    | <:match_case< $_$ -> st >> -> true
    | _ -> false
  
  let sum _name _loc ctyp = 
    let constrs = list_of_ctyp ctyp [] in (* decompose TyOr *)
    let case locOf locId id ctyp =
      let ctyps = list_of_ctyp ctyp [] in (* decompose TyAnd *)
      let ids = mk_idents "__x" (List.length ctyps) in
      let patt = create_patt_app (PaId(locId, id)) (List.map patt_of_id ids) in
      let exp = match ids with
        | [] -> <:expr< st >>
        | _ -> gen_let_seq ctyps (List.map expr_of_id ids)
      in
      <:match_case@locOf< $ patt $ -> $ exp $ >>
    in
    let cases = 
      List.map (function
        | TyOf (locOf, TyId(locId, id), ctyp) -> case locOf locId id ctyp
        | TyId (locId, id) -> case locId locId id (TyNil _loc)
        | _ -> assert false
      ) constrs 
    in
    if List.for_all is_just_self_case cases then
      <:expr< fun st __value -> st >>
    else
      <:expr< fun st __value -> match __value with $mcOr_of_list cases$ >>
  
  let record _name _loc ctyp = 
    let get_lab cty = match strip_field_flags cty with
      | TyId(_, id) -> id
      | _ -> assert false
    in
    let ctyps = list_of_ctyp ctyp [] in (* decomp TySems *)
    let labs, ctyps = List.split (List.map (function
      | TyCol (_, l, ctyp) -> get_lab l, strip_field_flags ctyp
      | _ -> assert false) ctyps)
    in
    let mems = List.map (fun l -> <:expr< __value.$id:l$ >> ) labs in 
    <:expr< fun st __value -> $gen_let_seq ctyps mems $ >>
    
  (** for [X; Y; .. ] and BASE, build ('st -> X -> 'st) -> ('st -> Y -> 'st) -> ... -> BASE *)
  let dispatch_type params base = 
    List.fold_right (fun ctyp st -> <:ctyp< ('st -> $ctyp$ -> 'st) -> $st$ >>) params base
  
  let method_type params name = 
    create_for_all params (dispatch_type params <:ctyp< 'st -> $ create_param_type params name $ -> 'st >>)
  
  
  (******************* kind of template *)
  
  let rec def name cty =
    let variants _ = assert false in
    let mani     _loc _ctyp k = def name k in
    let nil      _ = assert false in
    let alias  = alias name in
    let sum    = sum name in
    let record = record name in
    Gen.switch_tp_def ~alias ~sum ~record ~variants ~mani ~nil cty
  
  
  let dcl _loc name (params : ctyp list) d =
    if is_no_visit_ident (IdLid (Loc.ghost, name)) then <:class_str_item<>>
    else begin
      defined := StringSet.add name !defined;
      <:class_str_item<
         method $name$ : $method_type params name$ 
           = $Gen.abstract _loc (List.map patt_of_tvar params) (def name d)$
      >>
    end
  
  (* Add "of_sexp" and "sexp_of" as "sexp" to the set of generators *)
  let () = 
    Pa_type_conv.add_generator "ofold" (fun _bool tds ->
      reset_sets ();
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in (* CR jfuruse: mutual *)
      let methods = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> 
            dcl loc name params def
        | _ -> assert false) decls
      in
      let vmethods = 
        let vmethods = StringSet.fold StringMap.remove !defined !used in
        if StringMap.is_empty vmethods then [] 
        else 
          StringMap.fold (fun name nargs st ->
            let params = 
              let ns = 1--nargs in
              List.map (fun n -> TyQuo (_loc, "a" ^ string_of_int n)) ns
            in
            <:class_str_item< method virtual $name$ : $method_type params name$ >> :: st) vmethods []
      in
      let methods = concat_class_str_items (vmethods @ methods) in
      if vmethods <> [] then
        <:str_item< class virtual ['st] ofold = object (self) $methods$ end >>
      else
        <:str_item< class ['st] ofold = object (self) $methods$ end >>
    )
  ;;
end


module Map = struct

  let used = ref StringMap.empty
  let defined = ref StringSet.empty
  let reset_sets () = used := StringMap.empty; defined := StringSet.empty

  let rec gen_ctyp : ctyp -> expr option = function
    | TyId (_loc, id) 
    | TyApp (_loc, TyId(_, id), _) when is_no_visit_ident id -> None
    | TyId (loc, id) -> 
        if not (StringMap.mem (label_of_path id) !used) then
          used := StringMap.add (label_of_path id) 0 !used;
        Some <:expr@loc< self # $label_of_path id$ >>
    | (TyQuo (loc, _) as tv) -> Some <:expr@loc< $ expr_of_tvar tv $ self >>
    | TyApp (loc, (TyId(_, id) as f), args) ->  (* (int, float) Hashtbl.t *)
        let args = list_of_ctyp args [] in
        used := StringMap.add (label_of_path id) (List.length args) !used;
        begin match gen_ctyp f with
        | None -> None
        | Some f -> 
            Some (Gen.apply loc f (List.map (fun x -> match gen_ctyp x with 
            | None -> <:expr<fun self v -> self, v >> 
            | Some f -> <:expr< fun self -> $f$ >> ) args))
        end
    | TyApp (loc, TyApp (_loc, f, args1), args2) -> 
        gen_ctyp (TyApp (loc, f, TyCom(_loc, args1, args2)))
    | TyTup (loc, ctyp) ->
        let ctyps = list_of_ctyp ctyp [] in
        let xs = mk_idents "__x" (List.length ctyps) in
        let ys = mk_idents "__y" (List.length ctyps) in
        let patt = <:patt< $ PaTup (loc, paCom_of_list (List.map patt_of_id xs)) $ as __value >> in
        
        let exp = 
          let final_modified = create_tuple (List.map expr_of_id ys) in 
          let modifiedp = 
            let preds = List.map2 (fun x y -> <:expr< $id:x$ == $id:y$ >>) xs ys in
            List.fold_right (fun p e -> <:expr< $p$ && $e$ >>) (List.tl preds) (List.hd preds)
          in
          let final = <:expr< if $modifiedp$ then __value else $ final_modified $ >> in
          let e, modified = gen_letx_seq ctyps (List.map expr_of_id xs) (List.map patt_of_id ys) <:expr< self, $final$ >> in
          if modified then e else <:expr< self, __value >>
        in
        Some (Gen.abstract loc [ patt ] exp)

    | _ -> assert false
  
  and gen_letx_seq ctyps exps pats final = match ctyps, exps, pats with
    | [], [], [] -> final, false
    | (ctyp::ctyps), (exp::exps), (pat::pats)->
        let e, modified = gen_letx_seq ctyps exps pats final in
        begin match gen_ctyp ctyp with
        | None -> 
            <:expr< let $pat$ = $exp$ in $ e $ >>, modified
        | Some f -> 
            <:expr< let self, $pat$ = $f$ $exp$ in $ e $>>, true
        end
    | _ -> assert false
  
  let alias _name _loc cty = 
    match gen_ctyp cty with
    | None -> <:expr< >>
    | Some f -> <:expr< fun __value -> $f$ __value >>
  
  let is_just_self_case = function
    | <:match_case< $_$ -> self, __value >> -> true
    | _ -> false
  
  let sum _name _loc ctyp = 
    let constrs = list_of_ctyp ctyp [] in (* decompose TyOr *)
    let case locOf locId id ctyp =
      let ctyps = list_of_ctyp ctyp [] in (* decompose TyAnd *)
      let xs = mk_idents "__x" (List.length ctyps) in
      let ys = mk_idents "__y" (List.length ctyps) in
      let patt = create_patt_app (PaId(locId, id)) (List.map patt_of_id xs) in
      let exp = match xs with
        | [] -> <:expr< self, __value >>
        | _ -> 
            let final_modified = create_expr_app (ExId(locId, id)) (List.map expr_of_id ys) in
            let modifiedp = 
              let preds = List.map2 (fun x y -> <:expr< $id:x$ == $id:y$ >>) xs ys in
              List.fold_right (fun p e -> <:expr< $p$ && $e$ >>) (List.tl preds) (List.hd preds)
            in
            let final = <:expr< if $modifiedp$ then __value else $ final_modified $ >> in
            let e, modified =gen_letx_seq ctyps (List.map expr_of_id xs) (List.map patt_of_id ys) <:expr< self, $final$ >> in
            if modified then e else <:expr< self, __value >> 
      in
      <:match_case@locOf< $ patt $ -> $ exp $ >>
    in
    let cases = 
      List.map (function
        | TyOf (locOf, TyId(locId, id), ctyp) -> case locOf locId id ctyp
        | TyId (locId, id) -> case locId locId id (TyNil _loc)
        | _ -> assert false
      ) constrs 
    in
    if List.for_all is_just_self_case cases then
      <:expr< fun __value -> self, __value >>
    else
      <:expr< fun __value -> match __value with $mcOr_of_list cases$ >>
  
  let record _name _loc ctyp = 
    let get_lab cty = match strip_field_flags cty with
      | TyId(_, id) -> id
      | _ -> assert false
    in
    let ctyps = list_of_ctyp ctyp [] in (* decomp TySems *)
    let labs, ctyps = List.split (List.map (function
      | TyCol (_, l, ctyp) -> get_lab l, strip_field_flags ctyp
      | _ -> assert false) ctyps)
    in
    let exp = 
      let final_modified = create_record (List.map (fun l -> l, <:expr< $id:l$ >>) labs)  in
      let modifiedp = 
        let preds = List.map (fun l -> <:expr< __value.$id:l$ == $id:l$ >>) labs in
        List.fold_right (fun p e -> <:expr< $p$ && $e$ >>) (List.tl preds) (List.hd preds)
      in
      let final = <:expr< if $modifiedp$ then __value else $ final_modified $ >> in
      <:expr< self, $final$ >>
    in
    let e, modified = 
      gen_letx_seq ctyps (List.map (fun l -> <:expr< __value.$id:l$ >>) labs)
                          (List.map (fun l -> <:patt< $id:l$ >>) labs) exp 
    in
    <:expr< fun __value -> $ if modified then e else <:expr< self, __value >> $ >>
    
  (** for [X; Y; .. ] and BASE, build ('self -> X -> 'self * X) -> ('self -> Y -> 'self * Y) -> ... -> BASE *)
  let dispatch_type params base = 
    List.fold_right (fun ctyp st -> <:ctyp< ('self -> $ctyp$ -> 'self * $ctyp$) -> $st$ >>) params base
  
  let method_type params name = 
    create_for_all params (dispatch_type params 
                      <:ctyp< $ create_param_type params name $ 
                              -> 'self * $ create_param_type params name $ >>)
  
  
  (******************* kind of template *)
  
  let def name cty =
    let variants _ = assert false in
    let mani     _ = assert false in
    let nil      _ = assert false in
    let alias  = alias name in
    let sum    = sum name in
    let record = record name in
    Gen.switch_tp_def ~alias ~sum ~record ~variants ~mani ~nil cty
  
  
  let dcl _loc name (params : ctyp list) d =
    if is_no_visit_ident (IdLid (Loc.ghost, name)) then <:class_str_item<>>
    else begin
      defined := StringSet.add name !defined;
      <:class_str_item<
         method $name$ : $method_type params name$ = $Gen.abstract _loc (List.map patt_of_tvar params) (def name d)$
      >>
    end
  
  (* Add "of_sexp" and "sexp_of" as "sexp" to the set of generators *)
  let () = 
    Pa_type_conv.add_generator "omap" (fun _bool tds ->
      reset_sets ();
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in (* CR jfuruse: mutual *)
      let methods = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> 
            dcl loc name params def
        | _ -> assert false) decls
      in
      let vmethods = 
        let vmethods = StringSet.fold StringMap.remove !defined !used in
        if StringMap.is_empty vmethods then [] 
        else 
          StringMap.fold (fun name nargs st ->
            let params = 
              let ns = 1--nargs in
              List.map (fun n -> TyQuo (_loc, "a" ^ string_of_int n)) ns
            in
            <:class_str_item< method virtual $name$ : $method_type params name$ >> :: st) vmethods []
      in
      let methods = concat_class_str_items (vmethods @ methods) in
      if vmethods <> [] then
        <:str_item< class virtual omap = object (self:'self) $methods$ end >>
      else
        <:str_item< class omap = object (self:'self) $methods$ end >>
    )
  ;;
end



open Syntax

let comma_idents = Gram.Entry.mk "comma_idents"

EXTEND Gram
  GLOBAL: str_item sig_item comma_idents;

  str_item:
    [[
      "NO_VISIT"; "("; idents = comma_idents; ")" ->
        no_visit_idents := !no_visit_idents @ idents;
        <:str_item< >>
    ]];

  sig_item:
    [[
      "NO_VISIT"; "("; idents = comma_idents; ")"  ->
        no_visit_idents := !no_visit_idents @ idents;
        <:sig_item< >>
    ]];

  comma_idents:
    [ LEFTA
        [ ids1 = SELF; ","; ids2 = SELF -> ids1 @ ids2
        | id = ident -> [ strip_ident_loc id ]
        ]
    ];

END

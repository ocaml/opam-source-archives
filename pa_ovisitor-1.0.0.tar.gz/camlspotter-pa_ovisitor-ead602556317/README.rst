======================
pa_ovisitor
======================

CamlP4 type_conv module to auto-generate visitor, folder, mapper from type definitions.

This introduces 3 type_conv ``with`` extensions: ``ovisit``, ``ofold`` and ``omap``.

All the 3 extensions create a class definition for a set of *type definitions grouped with ``and`` keyword*. The class name is ``ovisit``, ``ofold`` and ``omap``, respectively. 

* ``ovisit`` provides visitor pattern, iterates over nodes. You can use it for generic folding, adding a mutable state from the inheritance of generated class.
* ``ofold`` provides generic fold. The methods take the accumulator argument to be pure.
* ``omap`` provides generic map. It can also have a mutable state by inheritance + adding mutable state.

These generated classes have methods with the type names which provide the "spine" algorithm for visitor, folding and mapping. Normally you must inherit the class and extend some (or all) of the methods for your purpose. See examples at ``pa/test`` directory.

The methods for data types not listed in the set of type definition grouped with ``and`` keyword is left virtual. You can later define them by inheriting the generated class, or combining generated classes by multiple inheritance. You can also ignore some of data types by using ``NO_VISIT(typename1, typename2, ..., typenamen)`` directive.

struct S * x;
void f() { x.f = 0; }

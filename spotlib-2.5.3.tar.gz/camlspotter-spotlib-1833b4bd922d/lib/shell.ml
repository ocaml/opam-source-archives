(* some shell commands via shell *)

open Unix
open Xunix
open Command

let com name tokens = execvp (name :: tokens) |> print

let cp = com "/bin/cp"
let mv = com "/bin/mv"
let rm = com "/bin/rm"
let cat = com "/bin/cat"

let cmp p1 p2 = 
  match execvp ["cmp"; p1; p2] |> ignore_output |> fst with
  | WEXITED 0 -> `Same
  | WEXITED 1 -> `Different
  | WEXITED 2 -> `Error
  | _ -> `Error (* something extremely wrong happened *)

let file path = 
  match 
    execvp ["/usr/bin/file"; path] |> fold ~init:[] ~f:(fun revls -> function
      | `Out, `Read s -> s::revls
      | _ -> revls)
  with
  | WEXITED 0, [] -> `Ok None
  | WEXITED 0, lines -> `Ok (Some (Xlist.last lines))
  | st, _ -> `Error st

let grep args ~init ~f = execvp ("/bin/grep" :: args) |> fold ~init ~f

let grep_ = grep ~init:() ~f:(fun _st _ -> ())
  


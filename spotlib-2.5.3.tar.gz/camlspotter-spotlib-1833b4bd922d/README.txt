1. set PREFIX env var
2. yes no | omake --install
3. omake


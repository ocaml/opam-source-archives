Launch tests (directly from the zephyrus main directory) like that:
"./zephyrus.native -settings benchmarks/settings/appropriate-settings-file.settings"

Results are always overwriting two files:
- benchmarks/results/json/result.json
- benchmarks/results/dot/result.dot

More info in readme files in subdirectories.
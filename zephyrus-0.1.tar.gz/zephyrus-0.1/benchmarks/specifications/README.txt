Prepared specifications:

m1 : We require exactly one Master component.
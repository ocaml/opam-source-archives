How the setting files names are formed:
(substrings like "[X]" are references, other characters should be treated literally)

u_[X].c_[Y].s_[Z].spec

"u" means "universe", [X] is the universe file used
"c" means "configuration", [Y] is the initial configuration file used
"s" means "specification", [Z] is the specification file used
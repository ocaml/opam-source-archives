#!/bin/bash
atdgen -t             json.atd
atdgen -j -j-defaults json.atd

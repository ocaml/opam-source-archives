#!/bin/bash

../zephyrus.native -u u_1.json -spec spec_1.spec -ic ic_1.json -print-all -repo empty repo_1.json -repo small repo_2.json -repo wheezy ../repositories/repo-debian-wheezy.json

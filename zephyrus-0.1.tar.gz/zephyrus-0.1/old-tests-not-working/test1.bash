#!/bin/bash

../zephyrus.native -u u_1.json -spec spec_1.spec -ic ic_1.json -print-all

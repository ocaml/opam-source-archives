#!/bin/bash

../zephyrus.native\
 -u u_2.json\
 -spec spec_2.spec\
 -ic ic_1.json\
 -repo ubuntu ../repositories/repo-ubuntu-precise.json -print-u -print-tu

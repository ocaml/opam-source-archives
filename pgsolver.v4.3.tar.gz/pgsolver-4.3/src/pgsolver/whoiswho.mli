val someone : unit -> string

All the examples except converter-external can be built without
installing camlimages. Therefore, Makefiles and OMakefiles in these
directories are bit ad-hoc and not quite useful as examples to use
camlimages.

converter-external serves an example of actual use of camlimages,
installed in `ocamlc -where`.

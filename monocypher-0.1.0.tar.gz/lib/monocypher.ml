(*
 * SPDX-FileCopyrightText: 2021 petites singularités <ps-dream@lesoiseaux.io>
 * SPDX-FileCopyrightText: 2021, 2022 pukkamustard <pukkamustard@posteo.net>
 *
 * SPDX-License-Identifier: BSD-2-Clause OR CC0-1.0
 *)

open Ctypes
module T = C.Type
module M = C.Function

module Hashing = struct
  module Blake2b = struct
    let digest ?key ?(size = 64) msg =
      assert (0 < size && size <= 64);

      let hash_ptr = allocate_n char ~count:size in

      let key_size = Option.(key |> map String.length |> value ~default:0) in
      assert (0 <= key_size && key_size <= 64);

      let () =
        M.crypto_blake2b_general hash_ptr
          (Unsigned.Size_t.of_int size)
          key
          (Unsigned.Size_t.of_int key_size)
          msg
          (Unsigned.Size_t.of_int (String.length msg))
      in

      string_from_ptr hash_ptr ~length:size

    type ctx = int * T.Crypto_blake2b_ctx.t

    let init ?key ?(size = 64) () =
      assert (0 < size && size <= 64);
      let ctx = make T.Crypto_blake2b_ctx.s in

      let key_size = Option.(key |> map String.length |> value ~default:0) in
      assert (0 <= key_size && key_size <= 64);

      M.crypto_blake2b_general_init (addr ctx)
        (Unsigned.Size_t.of_int size)
        key
        (Unsigned.Size_t.of_int key_size);
      (size, ctx)

    let update (_, ctx) message =
      M.crypto_blake2b_update (addr ctx) message
        (Unsigned.Size_t.of_int (String.length message))

    let final (size, ctx) =
      let hash_ptr = allocate_n char ~count:size in
      M.crypto_blake2b_final (addr ctx) hash_ptr;

      string_from_ptr hash_ptr ~length:size
  end
end

module Advanced = struct
  module IETF_ChaCha20 = struct
    let crypt ~key ~nonce ?(ctr = 0) msg =
      assert (ctr >= 0);
      let cipher_ptr = allocate_n char ~count:(String.length msg) in
      let msg_size = String.length msg in
      let _next_ctr =
        M.crypto_ietf_chacha20_ctr cipher_ptr msg
          (Unsigned.Size_t.of_int msg_size)
          key nonce
          (Unsigned.UInt32.of_int ctr)
      in
      string_from_ptr cipher_ptr ~length:msg_size
  end
end

module Optional = struct
  module Ed25519 = struct
    let public_key ~secret_key =
      let public_key_ptr = allocate_n char ~count:32 in
      assert (String.length secret_key = 32);
      M.crypto_ed25519_public_key public_key_ptr secret_key;
      string_from_ptr public_key_ptr ~length:32

    let sign ~secret_key ?(public_key = public_key ~secret_key) message =
      let signature_ptr = allocate_n char ~count:64 in
      assert (String.length secret_key = 32);
      assert (String.length public_key = 32);
      M.crypto_ed25519_sign signature_ptr secret_key public_key message
        (Unsigned.Size_t.of_int @@ String.length message);
      string_from_ptr signature_ptr ~length:64

    let check ~signature ~public_key message =
      assert (String.length signature = 64);
      assert (String.length public_key = 32);
      let result =
        M.crypto_ed25519_check signature public_key message
          (Unsigned.Size_t.of_int @@ String.length message)
      in
      if result = 0 then true else false
  end
end

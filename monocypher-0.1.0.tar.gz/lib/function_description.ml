(*
 * SPDX-FileCopyrightText: 2022 pukkamustard <pukkamustard@posteo.net>
 *
 * SPDX-License-Identifier: BSD-2-Clause OR CC0-1.0
 *)

open Ctypes
module Types = Types_generated

module Functions (F : Ctypes.FOREIGN) = struct
  open F

  (* Hashing *)

  let crypto_blake2b_general =
    foreign "crypto_blake2b_general"
      (ptr char @-> size_t @-> string_opt @-> size_t @-> string @-> size_t
     @-> returning void)

  let crypto_blake2b_general_init =
    foreign "crypto_blake2b_general_init"
      (Types.Crypto_blake2b_ctx.t @-> size_t @-> string_opt @-> size_t
     @-> returning void)

  let crypto_blake2b_update =
    foreign "crypto_blake2b_update"
      (Types.Crypto_blake2b_ctx.t @-> string @-> size_t @-> returning void)

  let crypto_blake2b_final =
    foreign "crypto_blake2b_final"
      (Types.Crypto_blake2b_ctx.t @-> ptr char @-> returning void)

  (* Advanced  - ChaCha20 *)

  let crypto_ietf_chacha20_ctr =
    foreign "crypto_ietf_chacha20_ctr"
      (ptr char @-> string @-> size_t @-> string @-> string @-> uint32_t
     @-> returning uint32_t)

  (* Optional - Ed25519 *)

  let crypto_ed25519_public_key =
    foreign "crypto_ed25519_public_key" (ptr char @-> string @-> returning void)

  let crypto_ed25519_sign =
    foreign "crypto_ed25519_sign"
      (ptr char @-> string @-> string @-> string @-> size_t @-> returning void)

  let crypto_ed25519_check =
    foreign "crypto_ed25519_check"
      (string @-> string @-> string @-> size_t @-> returning int)
end

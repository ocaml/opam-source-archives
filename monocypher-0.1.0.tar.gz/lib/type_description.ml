(*
 * SPDX-FileCopyrightText: 2022 pukkamustard <pukkamustard@posteo.net>
 *
 * SPDX-License-Identifier: BSD-2-Clause OR CC0-1.0
 *)

open Ctypes

module Types (F : Ctypes.TYPE) = struct
  open F

  module Crypto_blake2b_ctx = struct
    type s
    type t = (s, [ `Struct ]) structured

    let s : s structure typ =
      typedef (structure "crypto_blake2b_ctx") "crypto_blake2b_ctx"

    let () = seal s
    let t = ptr s
  end
end

(* some shell commands via shell *)
(* new version which can work in MinGW *)

open Unix
open Command

module V1 = struct
  
  let swap (x,y) = (y,x)
    
  let com name tokens = exec (name :: tokens) |> print |> void |> wait |> swap
  
  let cp = com "/bin/cp"
  let mv = com "/bin/mv"
  let rm = com "/bin/rm"
  let cat = com "/bin/cat"
  
  let file path = 
    match 
      exec ["/usr/bin/file"; path] |> stdout |> wait
    with
    | [], WEXITED 0 -> `Ok None
    | lines, WEXITED 0 -> `Ok (Some (Xlist.last lines))
    | _, st -> `Error st
  
  let grep args ~init ~f =
    let f' a st = match a with
      | `Err (`Error exn) -> raise exn
      | `Out (`Error exn) -> raise exn
      | `Err `EOF -> f st (`Err, `EOF)
      | `Err (`Read s) -> f st (`Err, `Read s)
      | `Out `EOF -> f st (`Out, `EOF)
      | `Out (`Read s) -> f st (`Out, `Read s)
    in
    exec ("/bin/grep" :: args) |> Command.fold f' init |> wait |> swap
  
  let grep_ = grep ~init:() ~f:(fun _st _ -> ())
  
  let cmp p1 p2 =
    match exec ["/bin/cmp"; p1; p2] |> void |> wait |> snd with
    | WEXITED 0 -> `Same
    | WEXITED 1 -> `Different
    | WEXITED 2 -> `Error
    | _ -> `Error (* something extremely wrong happened *)

end

module V2 = struct

  let com name tokens = exec (name :: tokens) |> print |> void |> wait |> fst
  
  let cp = com "/bin/cp"
  let mv = com "/bin/mv"
  let rm = com "/bin/rm"
  let cat = com "/bin/cat"
  
  let file path = 
    match 
      exec ["/usr/bin/file"; path] |> stdout |> wait
    with
    | [], WEXITED 0 -> `Ok None
    | lines, WEXITED 0 -> `Ok (Some (Xlist.last lines))
    | _, st -> `Error st
  
  let grep args init f =
    exec ("/bin/grep" :: args) |> Command.fold f init |> wait
  
  let grep_ args = grep args () (fun _ _ -> ())
  
  let cmp p1 p2 =
    match exec ["/bin/cmp"; p1; p2] |> void |> wait |> snd with
    | WEXITED 0 -> `Same
    | WEXITED 1 -> `Different
    | WEXITED 2 -> `Error
    | _ -> `Error (* something extremely wrong happened *)
    
end

include V1
  


# Squeue

A thread-safe queue, implemented using locks.

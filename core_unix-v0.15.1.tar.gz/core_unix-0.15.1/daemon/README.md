# Daemon

A single-module library with support for daemonizing a process.

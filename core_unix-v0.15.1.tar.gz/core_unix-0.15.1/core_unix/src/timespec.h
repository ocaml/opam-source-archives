#include <time.h>

struct timespec timespec_of_double(double seconds);
double timespec_to_double(struct timespec ts);

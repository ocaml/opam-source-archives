# Signal_unix

`Signal_unix` is a single-module library with Unix functionality for
dealing with `Core.Signal`.

Prior to 2020-04, `Signal_unix` was `Core.Signal`.

# Filename_unix

`Filename_unix` is a single-module library with Unix functionality for
dealing with `Core.Filename`.

Idiomatic usage is to refer explicitly to `Filename_unix`,
e.g. `Filename_unix.arg_type`.

Prior to 2021-04, `Filename_unix` was `Core.Filename`.

# Command_unix

`Command_unix` is a standalone library that has functionality related
to `Core.Command` and depends on depends on `Core_unix` -- including
`Command_unix.run`.

Prior to 2020-03, `Command_unix` was `Core.Command`.

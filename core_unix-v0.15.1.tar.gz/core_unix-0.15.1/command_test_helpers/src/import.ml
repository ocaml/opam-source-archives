open! Core
include Composition_infix

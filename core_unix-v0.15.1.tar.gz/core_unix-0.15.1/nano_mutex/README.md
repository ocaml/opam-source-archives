# Nano_mutex

A nano-mutex is a lightweight mutex that can be used only within a
single OCaml runtime.  Nano-mutexes are intended to be significantly
cheaper than OS-level mutexes.

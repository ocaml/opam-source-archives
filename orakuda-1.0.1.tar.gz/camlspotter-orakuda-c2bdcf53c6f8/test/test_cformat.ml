(*
  Pre-compiled printf format $%"....." and its use by Cformat

  Cformat.sprintf $%"..." is actually equivalent with $"...".
*)

open Orakuda.Std

let _ = 
  assert (Cformat.sprintf $%"hello%dworld" 2 = "hello2world");

  let x = 1 and y = 2 in 
  assert (Cformat.sprintf $%"%d %${x}d %d %${y}d %d" 3 4 5 = "3 1 4 2 5");

  assert (Cformat.sprintf $%"%1.F" 123.456 = "123.");
;;

(* people who cannot use the p4 patch *)
let _ = 
  assert (Cformat.sprintf <:fmt<hello%dworld>> 2 = "hello2world");

  let x = 1 and y = 2 in 
  assert (Cformat.sprintf <:fmt<%d %${x}d %d %${y}d %d>> 3 4 5 = "3 1 4 2 5")
;;

let _ = $%"%*.*d"

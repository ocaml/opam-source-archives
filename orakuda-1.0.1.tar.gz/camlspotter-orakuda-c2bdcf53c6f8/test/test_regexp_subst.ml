(*
  Regexp substitution $s/.../.../
*)

let s = $s/l+/x/g "hello world";;
let _ = assert (s = "hexo worxd");;

let s = $s/l+/$&$0/g "hello world";;
let _ = assert (s = "hellllo worlld");;

let s = <:s<l+/$&$0>> "hello world";;
let _ = assert (s = "hellllo world");;

let s = <:s<l+/$&$0/g>> "hello world";;
let _ = assert (s = "hellllo worlld");;

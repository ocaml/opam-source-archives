open Plebeia.Blake2B28
open Result
open Test_helper
open Cursor

module MP = Merkle_proof

module RS = Random.State

let root_hash cursor =
  let Cursor (_, node, context, _) = from_Ok @@ Cursor.go_top cursor in
  Node.compute_hash context node
  |> snd

let show_hash lh =
  Hash.prefix lh |> Hash.Prefix.to_hex_string

let show_path path =
  String.concat " / " @@ List.map Segment.to_string path


let check_found_or_not_found keys expected_nodes nodes =
  if List.length keys = List.length expected_nodes &&
       List.length keys = List.length nodes then
    let list = List.combine keys (List.combine expected_nodes nodes) in
    let check (key, (expected, node)) =
      match expected, node with
      | None, None -> ()
      | Some expected, Some node ->
         let node_hash node =
           match Node_hash.compute_without_context node with
           | Some nh -> nh
           | None -> failwith ("node_hash cannot computed: " ^ string_of_node node 2)
         in
         let nh1 = node_hash expected in
         let nh2 = node_hash node in
         if nh1 = nh2 then ()
         else
           let _ =
             Printf.printf "hash is not equals: (%s <> %s) '%s'\n"
               (Hash.to_hex_string nh1)
               (Hash.to_hex_string nh2)
               (show_path key);
             Printf.printf "--- expected:\n%s\n--- actual:\n%s\n"
               (Debug.string_of_node expected 2)
               (Debug.string_of_node node 2);
           in
           failwith ("hash is not equals: " ^ show_path key)
      | Some _, None ->
         failwith ("The indicated node of path by proof should be found, but not found: " ^ show_path key)
      | None, Some _ ->
         failwith ("The indicated node of path by proof should be not found, but found: " ^ show_path key)
    in
    List.iter check list
  else
    failwith "length are not equals"


let check_soundness keys cursor expected_nodes =
  match
    MP.generate cursor keys >>= fun mproof ->
    MP.validate keys mproof >>= fun (hash, node_opts) ->
    Ok (hash, node_opts)
  with
  | Ok (hash, node_opts) ->
     check_found_or_not_found keys expected_nodes node_opts;
     let expected = root_hash cursor in
     if expected <> hash then begin
         let Cursor (_, node, _, _) = cursor in
         (Format.sprintf "!!! Merkle Proof Test Failed !!!\n Expected hash: %s\n but Exact: %s\nnode:\n%s" (show_hash expected) (show_hash hash) (Debug.string_of_node node 2))
         |> prerr_endline;
         assert false
       end
  | Error err ->
     let show_cur (Cursor (_, node, _, _)) = Debug.string_of_node node 2 in
     Printf.printf "Merkleproof error: \n%s\n(%s)" (show_cur cursor) (Error.show err);
     Error.raise err

let check_encoding keys cursor =
  let open Data_encoding in
  match MP.generate cursor keys with
  | Ok mproof ->
     let bson = Bson.construct MP.encoding mproof in
     let mproof' = Bson.destruct MP.encoding bson in
     if List.of_seq mproof' <> List.of_seq mproof then
       Format.printf "Merkle Proof Encoding Test Failed.\nThe Bson\n"
  | Error err ->
     failwith (Error.show err)

let check segs cursor expected_node_opt =
  check_soundness [segs] cursor [expected_node_opt];
  check_encoding [segs] cursor

let segment s = from_Some @@ Segment.of_string s

let commit cur =
  let cur, _, _ = Cursor_storage.commit_top_cursor cur in
  cur

let test_encoding ctx =
  let open Data_encoding in
  let expected =
    `A [
      `String "budsome";
      `O [("segment", `String "20")];
      `O [("value", `String "484f4745")];
    ]
  in
  let leaf = Node.new_leaf (Value.of_string "HOGE") in
  let seg = segment "LL" in
  let ext = Node.new_extender seg leaf in
  let node = Node.new_bud (Some ext) in
  let cursor = _Cursor (_Top, node, ctx, Info.empty) |> commit in
  let keys = [[seg]] in
  match MP.generate cursor keys with
  | Ok mproof ->
     let json = Data_encoding.Json.construct MP.encoding mproof in
  if expected <> json then begin
      Format.printf "== expected: %a\n" Json.pp expected;
      Format.printf "== actual: %a\n" Json.pp json;
      failwith "json encoding error"
    end
  | Error e ->
     Error.raise e


let get_node (Cursor (_, node, _, _)) = node

let go_down cur seg =
  Cursor.access_gen cur seg >>= function
  | Cursor.Reached (c, (Node.Bud _)) -> return c
  | Reached (c, (Node.Leaf _)) -> return c
  | res -> Cursor.error_access res

let find path cur =
  Result.fold_leftM (fun cur seg ->
      go_down cur seg
      |> Result.map_error (fun e ->
             Printf.printf "[Go Down ERROR]: '%s' '%s'\n%s\n" (Segment.to_string seg)
               (Error.show e)
               (Debug.string_of_node (get_node cur) 2);
             e)
    ) cur path
  |> Result.map_error (fun e ->
         Printf.printf "[FIND ERROR]: %s\n%s\n" (show_path path) (Debug.string_of_node (get_node cur) 2);
         e)

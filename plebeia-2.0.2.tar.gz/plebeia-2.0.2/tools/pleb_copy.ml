open Plebeia
open Lwt.Syntax
open Utils

let () = Lwt_main.run @@
  let path1 = Sys.argv.(1) in
  let* vc1 = from_Ok_lwt @@ Vc.open_ ~mode:Storage.Reader path1 in

  let path2 = Sys.argv.(2) in
  let* vc2 = from_Ok_lwt @@ Vc.create ~node_cache:Node_cache.(create config_enabled) path2 in

  let* commits = Commit_db.to_list @@ Vc.commit_db vc1 in

  let* res = Copy.copy vc1 commits vc2 in
  match res with
  | Error e ->
      Log.fatal "Error: %a" Error.pp e;
      Error.raise e
  | Ok _ ->
      Log.notice "done";
      Lwt.return_unit

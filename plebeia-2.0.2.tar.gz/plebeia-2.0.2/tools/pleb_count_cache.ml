(*

   Show the hashcons cache status

   count_cache ~/.tezos-node/plebeia.context
*)

open Plebeia
open Lwt.Syntax
open Utils

let () = Lwt_main.run @@
  let path = Sys.argv.(1) in
  let* vc = from_Ok_lwt @@ Vc.open_ ~mode:Storage.Reader path in
  let ctxt = Vc.context vc in
  let hashcons = ctxt.Context.hashcons in
  Hashcons.stat Format.err_formatter hashcons;
  Lwt.return_unit

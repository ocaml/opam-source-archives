open Plebeia
open Test_utils
open Node_cache

(* guess how much bytes are used for 1 entry of node cache

   answer = 140bytes/entry
*)

let test () =
  let cache =
    create { threshold_at_shrink= max_int
           ; threshold_absolute= max_int
           ; shrink_ratio= 0.5
           }
  in
  let report i =
    let ebs = estimated_size_in_bytes cache in
    let ws = Obj.reachable_words (Obj.repr cache) in
    let bs = ws * Sys.word_size / 8 in
    Format.eprintf "nelems= %d words= %d bytes= %d bytes/nelems=%.2f estimated_bytes= %d ratio= %.2f@."
      i
      ws
      bs
      (float bs /. float i)
      ebs
      (float ebs /. float bs)
  in
  for i = 0 to 200000 do
    if i mod 10000 = 0 then report i;
    let h =
      Hash.of_prefix
        (Hash.Prefix.of_string
           (let s = Printf.sprintf "%d" i in
            String.make (28 (* fixed *) - String.length s) '0'
            ^ s))
    in
    add cache h Index.zero
  done

let () =
  let open Alcotest in
  run "node_cache_size"
    [ "node_cache_size", ["test", `Quick, test]
    ]

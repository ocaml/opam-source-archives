(* Reader root catchup test *)
open Plebeia
open Lwt.Syntax
open Test_utils

let test () =
  run_lwt @@
  with_tempdir @@ fun d ->
  Format.eprintf "Using directory %s@." d;
  let tempfile = d ^/ "plebeia" in
  let* vc_writer = from_Ok_lwt @@ Vc.create tempfile in
  let* vc_reader = from_Ok_lwt @@ Vc.open_ ~mode:Storage.Reader tempfile in
  Vc.enable_process_sync vc_reader;
  let c_writer = Vc.empty vc_writer in
  let c_writer = from_Ok @@ Deep.insert c_writer [Segment.StringEnc.encode "file1"] (Value.of_string "file1") in
  let* c_writer, _hp1, commit = from_Ok_lwt @@ Vc.commit vc_writer ~parent: None c_writer ~hash_override:None in
  let rhash1 = commit.hash in
  prerr_endline "rhash1";

  let* cur = Vc.checkout vc_writer rhash1 in
  let _c_writer = from_Some cur in
  prerr_endline "The writer knows rhash1";

  let* cur = Vc.checkout vc_reader rhash1 in
  let c_reader = from_Some cur in
  assert (snd @@ from_Ok @@ Deep.get_value c_reader [Segment.StringEnc.encode "file1"] = Value.of_string "file1");

  let c_writer = from_Ok @@ Deep.insert c_writer [Segment.StringEnc.encode "file2"] (Value.of_string "file2") in
  let* _c_writer, _hp2, commit = from_Ok_lwt @@ Vc.commit vc_writer ~parent: None c_writer ~hash_override:None in
  let rhash2 = commit.hash in
  prerr_endline "rhash2";
  let* cur = Vc.checkout vc_reader rhash2 in
  let c_reader = from_Some cur in
  assert (snd @@ from_Ok @@ Deep.get_value c_reader [Segment.StringEnc.encode "file1"] = Value.of_string "file1");
  assert (snd @@ from_Ok @@ Deep.get_value c_reader [Segment.StringEnc.encode "file2"] = Value.of_string "file2");

  (* Reader only with RDONLY fails the following ! *)
  prerr_endline "rhash1";
  let* cur = Vc.checkout vc_reader rhash1 in
  let c_reader = from_Some cur in
  assert (snd @@ from_Ok @@ Deep.get_value c_reader [Segment.StringEnc.encode "file1"] = Value.of_string "file1");

  let rec f n parent c_writer =
    if n = 100 then Lwt.return (parent, c_writer)
    else
      let rec g c_writer = function
        | 0 -> c_writer
        | m ->
            let c_writer =
              from_Ok @@ Deep.insert c_writer
                [Segment.StringEnc.encode @@ string_of_int n ;
                 Segment.StringEnc.encode @@ string_of_int m]
                (Value.of_string (string_of_int m))
            in
            g c_writer (m-1)
      in
      let c_writer = g c_writer 10000 in
      let* c_writer, _hp, commit = from_Ok_lwt @@ Vc.commit vc_writer ~parent: (Some parent) c_writer ~hash_override:None in
      let rhash = commit.hash in
      f (n+1) rhash c_writer
  in
  let* rhash_final, _c_writer = f 0 rhash2 c_writer in

  Format.eprintf "rhash_final: %a@." Commit_hash.pp rhash_final;
  let* c_reader = Lwt.map from_Some @@ Vc.checkout vc_reader rhash_final in
  prerr_endline "checked out";
  assert (snd @@ from_Ok @@ Deep.get_value c_reader [Segment.StringEnc.encode "file1"] = Value.of_string "file1");
  Lwt.return_unit

let () =
  let open Alcotest in
  run "reader"
    ["reader", ["test", `Quick, test ]]

(*****************************************************************************)
(*                                                                           *)
(* Open Source License                                                       *)
(* Copyright (c) 2019,2020 DaiLambda, Inc. <contact@dailambda.jp>            *)
(*                                                                           *)
(* Permission is hereby granted, free of charge, to any person obtaining a   *)
(* copy of this software and associated documentation files (the "Software"),*)
(* to deal in the Software without restriction, including without limitation *)
(* the rights to use, copy, modify, merge, publish, distribute, sublicense,  *)
(* and/or sell copies of the Software, and to permit persons to whom the     *)
(* Software is furnished to do so, subject to the following conditions:      *)
(*                                                                           *)
(* The above copyright notice and this permission notice shall be included   *)
(* in all copies or substantial portions of the Software.                    *)
(*                                                                           *)
(* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR*)
(* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,  *)
(* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL   *)
(* THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER*)
(* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING   *)
(* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER       *)
(* DEALINGS IN THE SOFTWARE.                                                 *)
(*                                                                           *)
(*****************************************************************************)

open Utils

type t =
  { parent : Commit_hash.t option
  ; index  : Index.t
  ; hash   : Commit_hash.t
  ; info   : Index.t
  }

let is_genesis ent = ent.parent = None

let compare e1 e2 = compare e1.index e2.index

let pp ppf { index ; parent ; hash ; info } =
  let f fmt = Format.fprintf ppf fmt in
  f "%a at %a parent=%a info=%a"
    Commit_hash.pp hash
    Index.pp index
    (Format.option Commit_hash.pp) parent
    Index.pp info

let compute_hash (module H : Hashfunc_intf.S) ~parent hash_prefix =
  let parent = Option.default Commit_hash.zero parent in
  Commit_hash.of_string
  @@ H.hash_strings [ Hash.Prefix.to_string hash_prefix;
                      Commit_hash.to_string parent ]

let make hf ~parent ~index ~info ?hash_override hash_prefix =
  let hash =
    match hash_override with
    | None -> compute_hash hf ~parent hash_prefix
    | Some h -> h
  in
  { parent; index; info; hash }

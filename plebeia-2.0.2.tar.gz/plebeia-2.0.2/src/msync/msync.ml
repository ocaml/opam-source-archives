external msync : ('a, 'b, 'c) Bigarray.Genarray.t -> unit = "caml_ba_msync"
external madvise_random : ('a, 'b, 'c) Bigarray.Genarray.t -> unit = "caml_madvise_random"

module Lwt = struct
  open Lwt_unix

  external msync_job : ('a, 'b, 'c) Bigarray.Genarray.t -> unit job = "caml_ba_msync_job"

  let msync a = Lwt_unix.run_job (msync_job a)
end

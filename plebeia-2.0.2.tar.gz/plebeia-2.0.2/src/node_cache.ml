include Memory_cache

include Memory_cache.Make(struct
    type t = Hash.t
    let equal = (=)
    let hash = Hashtbl.hash
  end)

(* obtained from tests/test_node_cache_size.ml *)
let bytes_per_item = 142

let config_enabled =
  { threshold_at_shrink = 50_000_000 / bytes_per_item
  ; threshold_absolute = 100_000_000 / bytes_per_item
  ; shrink_ratio = 0.8
  }

let config_disabled =
  { threshold_at_shrink=0;
    threshold_absolute=0;
    shrink_ratio=0.0 }

let estimated_size_in_bytes t = size t * bytes_per_item

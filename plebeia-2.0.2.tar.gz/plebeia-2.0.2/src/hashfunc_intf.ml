module type S = sig
  val hash_bytes : bytes -> bytes

  val hash_string : string -> string

  val hash_strings : string list -> string
end

module type MAKER = functor (A : sig
    (** Hash size in bytes *)
    val bytes : int
  end) -> S

(* This is not needed but with this you can make the module compilable without -ppx ppx_test *)
let _module_path_ = Ppx_test.Longident.Lident "use ppx_test"

let mp1 = _module_path_

module M = struct
  let mp2 = _module_path_

  module N = struct
    let mp3 = _module_path_
  end

  module Make(A : sig end)(B : sig end)() = struct
    let mp4 = _module_path_
  end
end

module X = M.Make(struct end)(struct end)()

let () = Format.eprintf "mp1= %s@." (Ppx_test.Longident.to_string mp1)
let () = Format.eprintf "mp2= %s@." (Ppx_test.Longident.to_string M.mp2)
let () = Format.eprintf "mp3= %s@." (Ppx_test.Longident.to_string M.N.mp3)
let () = Format.eprintf "mp4= %s@." (Ppx_test.Longident.to_string X.mp4)
 

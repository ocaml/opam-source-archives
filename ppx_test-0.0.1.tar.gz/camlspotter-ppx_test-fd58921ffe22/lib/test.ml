external (&) : ('a -> 'b) -> 'a -> 'b = "%apply"
let (!!%) = Format.eprintf

(** test type *)

type t =
  | Test    of (unit -> unit)
  | Labeled of Longident.t * t
  | List    of t list
  | Location of Location.t * t

let fun_ f = Test f
let label lid t = Labeled (lid, t)
let label_opt lidopt t = match lidopt with
  | None -> t
  | Some lid -> label lid t
let _list ts = List ts

module Config = struct
  type arg =
    | Do of Pcre.regexp
    | Dont of Pcre.regexp

  type t = {
    args : arg list;
    show_tests : bool;
    default_go : bool;
  }

  let rev_args = ref []
  let show_tests = ref false

  let from_args default_go = 
    { args = List.rev !rev_args;
      show_tests = !show_tests;
      default_go = default_go;
    }

  let is_go conf label =
    let s = Longident.to_string label in
    match 
      let rec find_map_opt f = function
        | [] -> None
        | x::xs ->
            match f x with
            | Some v -> Some v
            | None -> find_map_opt f xs
      in
      find_map_opt (function
        | Do rex when Pcre.pmatch ~rex s -> Some true
        | Dont rex when Pcre.pmatch ~rex s -> Some false
        | _ -> None) conf.args
    with
    | Some b -> b
    | None -> conf.default_go
end
  
let (+::=) r x = r := x :: !r

let arg_specs = 
  let open Arg in
  let open Config in      
  [ "--test", String (fun s -> rev_args +::= Do (Pcre.regexp s)), "<string>: Perform tests match with the string";
    "--no-test", String (fun s -> rev_args +::= Dont (Pcre.regexp s)), "<string>: Skip tests match with the string";
    "--show-tests", Set show_tests, ": List all the tests";
  ]

module State = struct
  type t = {
    label : Longident.t option;
    location : Location.t option;
    config : Config.t; (** We should test this or not *)
  }

  let add_label l st = 
    match st.label with
    | None -> { st with label = Some l }
    | Some pl -> { st with label = Some (Longident.concat pl l) }

  let set_location l st = { st with location = Some l }

  let label st = match st.label with
    | None -> assert false
    | Some l -> l

  let is_go t = Config.is_go t.config (label t)

  let from_args default_go =
    { label = None;
      location = None;
      config = Config.from_args default_go;
    }

end

let rec iter st go prim = function
  | Test t -> prim st t
  | Labeled (l, t) ->
      let st = State.add_label l st in
      go st (fun () -> iter st go prim t)
  | Location (loc, t) ->
      let st = State.set_location loc st in
      go st (fun () -> iter st go prim t)
  | List ts -> List.iter (iter st go prim) ts

let show st t = 
  let go _st f = f () in
  let prim st _ = 
    !!% "%s: %s@." 
      (Longident.to_string (State.label st))
      (if State.is_go st then "go" else "skip")
  in
  iter st go prim t

let run' st = 
  let go _st f = f () in
  let prim st t = 
    if State.is_go st then begin 
      let name = Longident.to_string (State.label st) in
      !!% "Testing %s...@." name;
      begin try t () with
      | e -> 
          !!% "Error: %s: %a: %s@." 
            (Longident.to_string (State.label st))
            (fun ppf -> function
              | None -> Format.fprintf ppf "<no location>"
              | Some l -> Location.format ppf l) st.location
            (Printexc.to_string e); 
          raise e 
      end;
      !!% "Done %s@." name;
    end
  in
  iter st go prim

let run default_go t = 
  let st = State.from_args default_go in
  if st.State.config.Config.show_tests then
    show st t
  else
    run' st t

(** Global test table *)

let tests = ref []

let _add t = tests := t :: !tests

let location loc t = Location (loc, t)

(* TEST_UNIT *)
let test_unit loc l f = tests := (location loc & label_opt l & fun_ f) :: !tests; prerr_endline "+"

(* TEST *)
let test loc l f =
  tests := (location loc & label_opt l & fun_ & fun () -> 
    if not & f () then raise Exit) :: !tests

let collect () = 
  Arg.parse arg_specs (fun _ -> ()) "test";

  (* Running tests can add more tests, therefore we must loop things.
     Not sophisticated :-( *)
  let rec loop () =
    match !tests with
    | [] -> ()
    | t::ts ->
        tests := ts;
        run true t;
        loop ()
  in
  loop ()

open Parsetree
open Asttypes
open Ast_mapper
open Longident
open Ast_helper

(* (&) is too strong *)
external ( & ) : ('a -> 'b) -> 'a -> 'b = "%apply"

let ($.) l s = Ldot (l, s)

let make_loc ?(loc = Location.none) txt = { txt; loc }
let ghost l = { l with Location.loc_ghost = true }

let string_of_lident = 
  let rec to_string = function
    | Lident s -> s
    | Ldot (t, s) -> to_string t ^ "." ^ s
    | Lapply (t1, Lident "()") -> to_string t1 ^ "()"
    | Lapply (t1, t2) -> to_string t1 ^ "(" ^ to_string t2 ^ ")"
  in
  to_string

let split_by_char c s =
  let open String in
  let rec loop s =
    match index s c with
    | exception Not_found -> [s]
    | n -> sub s 0 n :: loop (sub s (n+1) (length s - n - 1))
  in
  loop s

(* Very simple way of parsing a string as Longident.t *)
let parse_as_lident s =
  let tokens = split_by_char '.' s in
  match tokens with
  | [] -> assert false (* impos *)
  | _ ->
      let rec loop = function
        | [] -> assert false (* impos *)
        | [x] -> Lident x
        | x::xs -> Ldot (loop xs, x)
      in
      loop (List.rev tokens)

module Exp = struct
  include Exp 

  let unit = construct (make_loc & Lident "()") None 
  let string s = constant & Const_string (s, None)
  let int n = constant & Const_int n
  let bool b = construct (make_loc (Lident (if b then "true" else "false"))) None

  let option f = function
    | None -> construct (make_loc (Lident "None")) None
    | Some v -> construct (make_loc (Lident "Some")) & Some (f v)

end

module Pat = struct
  include Pat
  let unit = Pat.construct (make_loc & Lident "()") None 
end

let exp_of_position p =
  let open Lexing in
  let mklid s = make_loc (Lident "Lexing" $. s)
  in
  let open Exp in
  record [
    mklid "pos_fname", string p.pos_fname;
    mklid "pos_lnum",  int p.pos_lnum;
    mklid "pos_bol",   int p.pos_bol;
    mklid "pos_cnum",  int p.pos_cnum
  ] None

let exp_of_location l =
  let open Location in
  let mklid s = make_loc ~loc:(ghost l) (Lident "Ppx_test" $. "Location" $. s) in
  let open Exp in
  record ~loc:l [
    mklid "loc_start", exp_of_position l.loc_start;
    mklid "loc_end",   exp_of_position l.loc_end;
    mklid "loc_ghost", bool l.loc_ghost
  ] None

let rec exp_of_longident = 
  let open Exp in
  let mklid s = make_loc (Lident "Ppx_test" $. "Longident" $. s) in
  function 
    | Lident s -> 
        construct (mklid "Lident") (Some (string s))
    | Ldot (t, s) ->
        construct (mklid "Ldot") (Some (tuple [exp_of_longident t; string s]))
    | Lapply (t1, t2) ->
        construct (mklid "Lapply") (Some (tuple [exp_of_longident t1; exp_of_longident t2]))

(** [with_location e] *)

let extend_at super =
  let expr self = function
    | { pexp_desc = 
          Pexp_apply ({ pexp_desc = 
                          Pexp_ident { txt= Lident "_with_location_" } },
                      [ "", e ]) } ->
        Exp.tuple ~loc:(ghost e.pexp_loc)
          [ self.expr self e
          ; exp_of_location e.pexp_loc 
          ]
    | e -> super.expr self e
  in
  { super with expr }

(** [module_path] *)

(* It lacks the top module name, which should be obtained from Location *) 
let current_module_path = ref (Lident "*top*") (* dummy *)

let get_current_module_path loc = 
  let top_module =
    let fname = loc.Location.loc_start.Lexing.pos_fname in
    match fname with
    | "//toplevel//" -> fname
    | _ ->
        let base = Filename.basename fname in
        let chopped = try Filename.chop_extension base with _ -> base in
        String.capitalize chopped
  in
  let rec fix = function
    | Lident "*top*" -> Lident top_module
    | Lident _ -> assert false
    | Ldot (t, s) -> Ldot (fix t, s)
    | Lapply (t1, t2) -> Lapply (fix t1, t2)
  in
  fix !current_module_path

let with_module_path mp f =
  let cur = !current_module_path in
  current_module_path := mp;
  let res = f () in
  current_module_path := cur;
  res

let module_name_tracking super =
  let module_binding self ({ pmb_name = {txt=name} } as x) =
    with_module_path (Ldot (!current_module_path, name)) & fun () ->
      super.module_binding self x
  in
  let module_expr self me = match me with
    | { pmod_desc = Pmod_functor ({txt=name}, _, _) } ->
        with_module_path (Lapply(!current_module_path, Lident name)) & fun () ->
          super.module_expr self me
    | _ -> super.module_expr self me
  in

  let expr self e = match e with
    | { pexp_desc = Pexp_letmodule ({txt=name}, _, _) } ->
        with_module_path (Ldot (!current_module_path, name)) & fun () ->
          super.expr self e
    | { pexp_desc = Pexp_ident { txt= Lident "_module_path_" } } ->
        exp_of_longident (get_current_module_path e.pexp_loc)
      | _ -> super.expr self e
  in
  { super with module_binding; module_expr; expr }

(** [let %TEST name = e] *)

type test_type = Unit | Bool

let drop_tests = ref false
let top_name = ref None

let rec lident_concat l1 = function
  | Lident s -> Ldot (l1, s)
  | Ldot (t, s) -> Ldot (lident_concat l1 t, s)
  | Lapply (t1, t2) -> Lapply (lident_concat l1 t1, t2)

let unit_name = function
  | Lident "" | Lapply _ -> false (* impossible *)
  | Lident s | Ldot (_, s) -> s.[String.length s - 1] = '_'

let add_top_name lid =
  match !top_name with
  | None -> lid
  | Some top_lid -> lident_concat top_lid lid

let extend_let_test super =
  let structure_item self = function
    | { pstr_desc= 
          Pstr_extension (
            ( { txt = ("TEST" | "TEST_UNIT") }, 
              PStr [ { pstr_desc= Pstr_value (Nonrecursive, _vbs) } ]),
            _) } as sitem when !drop_tests ->
        { sitem with pstr_desc= Pstr_eval (Exp.unit, []) }

    | { pstr_desc= 
          Pstr_extension (
            ( { txt = ("TEST" | "TEST_UNIT" as test) }, 
              PStr [ { pstr_desc= Pstr_value (Nonrecursive, vbs) } ]),
            _) } ->
        let f vb =
          let loc = vb.pvb_loc in
          let name = 
            match vb.pvb_pat with
            | { ppat_desc = Ppat_any } -> None
            | { ppat_desc = Ppat_constant (Const_string (name, _)) } -> 
                Some (add_top_name & Lident name)
            | { ppat_desc = Ppat_var {txt=name} } -> 
                let mpath = Ldot (get_current_module_path loc, name) in
                Some (add_top_name & mpath)
            | { ppat_desc = Ppat_construct ({ txt= lid }, None) } ->
                let mpath = get_current_module_path loc in
                Some (add_top_name & lident_concat mpath lid)
            | _ -> assert false
          in
          let return_type = match test, name with
            | "TEST_UNIT", _ -> Unit
            | "TEST", None -> Unit
            | "TEST", Some lid -> if unit_name lid then Unit else Bool
            | _ -> assert false
          in
          let test = match return_type with
            | Unit -> "test_unit"
            | Bool -> "test"
          in
          (* Build [Ppx_test.test/test_ ~loc name (fun () -> e)] *)
          let open Exp in
          Vb.mk Pat.unit           
            (apply 
               (ident & make_loc & Lident "PTest" $. test)
               [ "", exp_of_location loc;
                 "", option exp_of_longident name;
                 "", fun_ "" None Pat.unit (self.expr self vb.pvb_expr) ])
        in
        Str.value Nonrecursive (List.map f vbs)

    | x -> super.structure_item self x
  in
  { super with structure_item }

let mapper = extend_at & extend_let_test & module_name_tracking default_mapper

let () = 
  let rev_files = ref [] in 
  Arg.parse 
    [ "-drop-tests", Arg.Set drop_tests, "Drop unit tests"
    ; "-top-name", Arg.String (fun s -> top_name := Some (parse_as_lident s)), "Set the top module name" 
    ]
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    "ppx_test";
  match List.rev !rev_files with
  | [infile; outfile] ->
      Ast_mapper.apply ~source:infile ~target:outfile mapper
  | _ -> 
      failwith "ppx_test infile outfile"

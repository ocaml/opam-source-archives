open Parsetree
open Asttypes
open Ast_mapper
open Ast_helper
open Location

(* (@@) is too strong *)
external ( & ) : ('a -> 'b) -> 'a -> 'b = "%apply"

let (!!%) = Format.eprintf

module Option = struct
  let map f = function
    | None -> None
    | Some v -> Some (f v)
end

(*
let ($.) l s = Ldot (l, s)
let (!$) s = Lident s
let (!..) xs = 
  let rec f = function
    | [] -> assert false
    | [x] -> Lident x
    | x::xs -> Ldot (f xs, x)
  in
  f (List.rev xs)
*)

let at ?loc txt = 
  let loc = match loc with 
      | None -> !Ast_helper.default_loc
      | Some loc -> loc
  in
  { txt; loc }

let lid ?loc s = at ?loc & Longident.parse s

let partition p = List.partition (fun ({txt}, _payload) -> p txt)

let with_default_loc loc f = 
  let back = !Ast_helper.default_loc in
  Ast_helper.default_loc := loc;
  let res = f () in
  Ast_helper.default_loc := back;
  res

module Typ = struct
  include Typ
  let new_var =
    let cntr = ref 0 in
    fun () -> 
      incr cntr;
      var & "tvar_" ^ string_of_int !cntr
  let ref_ ?loc ?attrs ty = 
    constr ?loc ?attrs (at ?loc & Longident.Lident "ref") [ty]
end

module Exp = struct
  include Exp
  let string ?loc ?attrs s = constant ?loc ?attrs & Const_string (s, None)
  let int ?loc ?attrs i = constant ?loc ?attrs & Const_int i
  let bool ?loc ?attrs b = construct ?loc ?attrs (lid ?loc (if b then "true" else "false")) None
  let var ?loc ?attrs s = ident ?loc ?attrs & at ?loc & Longident.Lident s
  let id ?loc ?attrs s = ident ?loc ?attrs & at ?loc & Longident.parse s
  let option ?loc ?attrs = function
    | None -> construct ?loc ?attrs (lid ?loc "None") None
    | Some e -> construct ?loc ?attrs (lid ?loc "Some") (Some e)
  let parse s =
    try
      Parser.parse_expression Lexer.token (Lexing.from_string s)
    with
    | _e -> failwith (Printf.sprintf "parse fail: %s" s)

  let object_ ?loc ?attrs flds = object_ ?loc ?attrs (Cstr.mk (Pat.any ()) flds)
  let seqs = function
    | [] -> assert false
    | x::xs -> List.fold_right (fun x st -> sequence x st) xs x
  let ignore_ e = apply (id "Pervasives.ignore") ["", e]
  let assert_false () = assert_ & bool false
end

module Pat = struct
  include Pat
  let var ?loc ?attrs s = var ?loc ?attrs (at ?loc s)

  exception Not_supported of expression

  let of_expr e = 
    let rec f e = 
      let loc = e.pexp_loc in
      let attrs = e.pexp_attributes in
      match e.pexp_desc with
      | Pexp_ident {txt=Lident s; loc=loc'} -> 
          Pat.var ~loc ~attrs {txt=s; loc=loc'} 
      | Pexp_constant c -> Pat.constant ~loc ~attrs c
      | Pexp_tuple es -> Pat.tuple ~loc ~attrs & List.map f es
      | Pexp_construct (lid, eopt) ->
          Pat.construct ~loc ~attrs lid & Option.map f eopt
      | Pexp_variant (l, eopt) ->
          Pat.variant ~loc ~attrs l & Option.map f eopt
      | Pexp_record (fields , None) ->
          Pat.record ~loc ~attrs (List.map (fun (lid, e) -> lid, f e) fields) Closed
      | Pexp_array es -> Pat.array ~loc ~attrs & List.map f es
      | Pexp_constraint (e, ty) -> Pat.constraint_ ~loc ~attrs (f e) ty
      | Pexp_lazy e -> Pat.lazy_ ~loc ~attrs & f e
      | Pexp_extension ({txt="p"}, PPat (p, None)) -> p
      | _ -> raise (Not_supported e)
    in
    try
      `Ok (f e)
    with
    | Not_supported e -> `Error e
end

module ExpPat = struct
  let var ?loc ?attrs s = (Exp.var ?loc ?attrs s, Pat.var ?loc ?attrs s)
end

module Cf = struct
  include Cf

  let method_concrete ?loc ?attrs name ?(priv=false) ?(override=false) e = 
    Cf.method_ ?loc ?attrs name (if priv then Private else Public)
      (Cfk_concrete ((if override then Override else Fresh), e))
  let method_virtual ?loc ?attrs name ?(priv=false) cty = 
    Cf.method_ ?loc ?attrs name (if priv then Private else Public)
      (Cfk_virtual cty)
end

module Cstr = struct
  let mk ?(self= Pat.any ()) fields = Cstr.mk self fields
end

module Monadic = struct

  (* Monadic bind syntax sugar can be reusable
     also for pattern guards and comprehensions *)
       
  let is_bind e = 
    match e.pexp_desc with
    | Pexp_apply({ pexp_desc= Pexp_ident({txt=Lident "<--"}) }, [("",p); ("",e)]) ->
        begin match Pat.of_expr p with
        | `Ok p -> Some (p, e)
        | `Error e ->
            raise_errorf ~loc:e.pexp_loc "The left hand side of <-- must be a pattern"
        end
    | Pexp_apply({ pexp_desc= Pexp_ident({txt=Lident "<--"}) }, _) ->
        raise_errorf ~loc:e.pexp_loc "Syntax error of <--. It must have the form p <-- e"
    | _ -> None

  let is_unit e = match e.pexp_desc with
    | Pexp_construct ({txt=Lident "()"}, None) -> true
    | _ -> false

  let rec parse_do e = match e.pexp_desc with
    | Pexp_sequence ( u, { pexp_desc= Pexp_sequence( e1, e2 ) } ) when is_unit u ->
        (* <(); e1; e2> => e1; <e2> *) 
        `Expr (e1, Some (parse_do e2))

    | Pexp_sequence ( u, e ) when is_unit u -> 
        (* <(); e> => e *) 
        `Expr (e, None)

    | Pexp_sequence ({ pexp_desc = Pexp_sequence _; pexp_loc=loc }, _) ->
        (* <do_; ..; (e1; e2); ..> => error *) 
        raise_errorf ~loc "The clause cannot take a nested sequence. It must be flattened"
      
    | Pexp_sequence (e1, e2) ->
        begin match is_bind e1 with
        | Some (p, e') ->
            (* <p <-- e1; e2> => bind e1 (fun p -> <e2>)  *)
            `Bind (e.pexp_loc, p, e', Some (parse_do e2))
        | None ->
            (* <e1; e2> => bind e1 (fun () -> <e2>) *)
            `BindUnit (e.pexp_loc, e1, parse_do e2)
        end

    | Pexp_let(_, _, e') 
    | Pexp_letmodule(_, _, e')
    | Pexp_open(_, _, e') ->
        (* <let p = e1 in e2> => let p = e1 in <e2> *)
        (* <let module M = mexp in e2> => let module M = mexp in <e2> *)
        (* <let open M in e2> => let open M in <e2> *)
        `Let (e, parse_do e')
      
    | Pexp_extension ( _ext,
                       PStr [({ pstr_desc= Pstr_eval (exp, _attr) })]) ->
        (* <let%m p = e1 in e2> => let%m p = e1 in <e2> 
         
           If you do not want ppx_monadic invades in your extension,
           use (); [%your_ext ..];
        *)
        `Ext (e, parse_do exp)

    | _ ->
        begin match is_bind e with
        | Some (p, e') -> `Bind (e.pexp_loc, p, e', None) (* `do` must reject this *)
        | None -> `Expr (e, None)
        end

end 

let ppx_name = ref "ppx name is not set"

let ppx_errorf ?(loc = Location.none) ?(sub = []) ?(if_highlight = "") =
  Printf.ksprintf (fun msg ->
    let e = { Location.loc; msg; sub; if_highlight } in
    Format.eprintf "Error at %s: %a@." !ppx_name Location.report_error e;
    exit 1)

let test mapper fname = 
  try
    if Filename.check_suffix fname ".ml" then (* .mlt ? *)
      let str = Pparse.parse_implementation ~tool_name:"ppx" Format.err_formatter fname in
      let str = mapper.structure mapper str in
      Pprintast.structure Format.std_formatter str
    else if Filename.check_suffix fname ".mli" then 
      let sg = Pparse.parse_interface ~tool_name:"ppx" Format.err_formatter fname in
      let sg = mapper.signature mapper sg in
      Pprintast.signature Format.std_formatter sg
    else assert false;
    Format.fprintf Format.std_formatter "@."
  with
  | Syntaxerr.Error e ->
      !!% "%a@." Syntaxerr.report_error e

let run name mapper = 
  ppx_name := name;
  let debug = ref false in
  let rev_files = ref [] in 
  Arg.parse 
    [ "-debug", Arg.Set debug, "debug mode which can take .ml/.mli then print the result"
    ]
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    name;
  try
    match !debug, List.rev !rev_files with
    | true, files ->
        List.iter (test mapper) files
    | false, [infile; outfile] ->
        Ast_mapper.apply ~source:infile ~target:outfile mapper
    | _ -> 
        failwith @@ name ^ " infile outfile"
  with
  | Location.Error e -> Location.report_error Format.err_formatter e
  

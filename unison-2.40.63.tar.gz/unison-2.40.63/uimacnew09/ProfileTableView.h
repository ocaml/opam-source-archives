/* ProfileTableView */

#import <Cocoa/Cocoa.h>

@class MyController;

@interface ProfileTableView : NSTableView
{
    IBOutlet MyController *myController;
}
@end

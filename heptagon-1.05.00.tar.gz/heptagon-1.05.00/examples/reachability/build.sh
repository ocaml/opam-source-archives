heptc -target ctrln reachability.ept
reax -a 'sB:r' reachability_ctrln/reach_verif.ctrln

open Spotlib.Spot
(* open List *)

module Filename = struct
  include Filename
    
  let split_dir path =        
    let rec split_dir ds p =
      let d = dirname p in
      if d = p then d::ds
      else split_dir (basename p::ds) d 
    in
    split_dir [] path
end

module File = struct
  include File

  let get_inode p = try Some (Unix.stat p).st_ino with _ -> None

  (* Seems working in MinGW, too *)
  let equal p1 p2 =
    p1 = p2
    || let i1 = get_inode p1 in
       i1 <> None && i1 = get_inode p2

  (** [contains p1 p2] return [Some compos] when [p2] is equal to [p1]
      or under [p1].  [p1] must really exist.
  *)
  let contains p1 =
    let i1 = get_inode p1 in
    fun p2 ->
      if p1 = p2 then Some []
      else
        let rec f st p2 =
          if p1 = p2 then Some st
          else
            let i2 = get_inode p2 in
            if i1 <> None && i1 = i2 then Some st
            else
              let d = Filename.dirname p2 in
              if d = p2 then None
              else f (Filename.basename p2 :: st) d
        in
        f [] p2
end
  
module Result = struct
  include Result
  let to_option = function
    | `Ok v -> Some v
    | `Error _ -> None
end

module ParseError = struct
  open Lexing

  let string_of_position p =
    !% "%S, line %d, characters %d"
      p.pos_fname
      p.pos_lnum
      (p.pos_cnum - p.pos_bol)

  let catch f lexbuf =
    try f lexbuf with
    | Lexer.Error _ ->
        `Error (string_of_position (Lexing.lexeme_start_p lexbuf) ^ ": Lexer error") 
    | Parsing.Parse_error ->
        `Error (string_of_position (Lexing.lexeme_start_p lexbuf) ^ ": Parse error") 
    | Syntaxerr.Escape_error ->
        `Error (string_of_position (Lexing.lexeme_start_p lexbuf) ^ ": Escape error") 
    | Syntaxerr.Error e ->
        `Error (Format.to_string Syntaxerr.report_error e)
end

module String = struct
  include String

  let words = split (function ' ' -> true | _ -> false)
end

module Option = struct
  include Option

  let to_list = function
    | None -> []
    | Some x -> [x]
end

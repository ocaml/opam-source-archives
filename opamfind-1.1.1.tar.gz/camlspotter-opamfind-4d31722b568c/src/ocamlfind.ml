open Spotlib.Spot
open Utils
open List

let debug = ref false

module Regexp = Ppx_orakuda.Regexp.Re_pcre
open Regexp.Literal
open Regexp.Infix

module Scanner = Fl_metascanner

module Package = struct

  type raw = Fl_package_base.package = 
      { package_name : string;
        package_dir  : string;
        package_meta : string;
        package_defs : Scanner.pkg_definition list;
        package_priv : Fl_package_base.package_priv
      }

  type t = { 
    name : string;
    dir  : string;
    defs : (string * string) list
  } [@@deriving conv{ocaml}]

  let t_of_raw t = 
    { name = t.package_name;
      dir  = t.package_dir;
      defs = map (fun def -> def.Scanner.def_var, def.Scanner.def_value) t.package_defs }

  let name p = p.name

  let find_var v p = assoc_opt v p.defs

  let version = find_var "version"

  let requires p = 
    flip Option.fmap (find_var "requires" p) & Regexp.split {m|[\s,]+|m}

  let requires_transitive pks p =
    let find_named n =
      match find_opt (fun p -> name p = n) pks with
      | None ->
          !!% "Warning: requires_transitive: ocamlfind package %s is not found. Ignored@." n;
          None
      | (Some _ as x) -> x
    in
    let stdlib = from_Some & find_named "stdlib" in
    let rec f st = function
      | [] -> st
      | p::ps ->
          let rpks = filter_map find_named & requires p // [] in
          let rpks = filter (fun rpk -> not & mem rpk st) rpks in
          f (rpks @ st) (rpks @ ps)
    in
    f [stdlib] [p]

  let includes pks p =
    unique & map (fun p -> p.dir) & p :: requires_transitive pks p
      
  let top_name p = 
    match String.split1 (function '.' -> true | _ -> false) p.name with
    | Some (x,_) -> x
    | None -> p.name

  let is_distributed_with_ocaml p =
    match version p with
    | None -> false
    | Some s -> s =~ {m|\[distributed with OCaml\]/i|m} <> None

  let is_base p = is_distributed_with_ocaml p && top_name p <> "camlp4"

  let is_top p = not & String.contains p.name '.'

  let archives p = unique & match p.name with
    | "stdlib" ->
        (* stdlib does not list stdlib.cma *)
        [p.dir ^/ "stdlib.cma"]
    | _ ->
        concat & flip filter_map p.defs & function
          | ("archive",v) ->
              Some (map (fun x -> p.dir ^/ x) & String.words v)
          | _ -> None
end

module Group = struct
  type t = {
    name : string;
    packages : Package.t list
  } [@@deriving conv{ocaml}]

  let top t = match t.packages with
    | [] -> assert false
    | t::_ -> t

  let top_dir t = (top t).Package.dir

  let dirs t = unique & map (fun p -> p.Package.dir) t.packages
end

let group ps = 
  let open Package in
  map (fun ps ->
    let n = top_name & hd ps in
    let ps1, ps2 = partition (fun p -> top_name p = n) ps in
    let ps = ps1 @ ps2 in (* [hd ps]'s name is n *)
    { Group.name = n; packages = ps })
  & sort_then_group_by (fun p1 p2 -> compare (top_name p1) (top_name p2)) ps
  
let init () = Findlib.init ()

let get_packages () =
  map (Fl_package_base.query *> Package.t_of_raw) 
  & Fl_package_base.list_packages ()

let get_stdlib_dir () = Findlib.ocaml_stdlib ()

let get () =
  init ();
  let stdlib_dir = get_stdlib_dir () in
  let pkgs = get_packages () in
  stdlib_dir, pkgs

let choose_best_package_name = function 
  | [] -> assert false
  | pack_names ->
      pack_names
      |> map (fun s -> String.length s, s)
      |> sort_then_group (fun (l1, _) (l2, _) -> compare l1 l2) 
      |> hd
      |> map snd
      |> sort compare 
      |> hd 

module Analyzed = struct
  type t = {
    package: Package.t;
    archives : string list;
    compilation_units : string list;
    cmis : string list;
  } [@@deriving conv{ocaml}]

  let name t = Package.name t.package
  let is_base t = Package.is_base t.package
end

let analyze =
  fun p ->
    let open Analyzed in
    if !debug then !!% "%a@." (Ocaml.format_with Package.ocaml_of_t) p;
    let arcs, non_exist = partition (fun a -> File.Test._f a) & Package.archives p in
    flip iter non_exist (fun a ->
      !!% "Warning: Ocamlfind.analyze: archive %s does not exist, even though it is declared in the META file@." a);
    if !debug then !!% "@[<2>archives=@ %a@]@." (Ocaml.format_with [%derive.ocaml_of: string list]) arcs;
    let cus = unique & concat_map (fun a -> Cmfile.get_compilation_units a // []) arcs in
    if !debug then !!% "@[<2>units=@ %a@]@." (Ocaml.format_with [%derive.ocaml_of: string list]) cus;
    let cmis = filter_map (Cmfile.check_compilation_unit p.dir) cus in
    if !debug then !!% "@[<2>cmis=@ %a@]@." (Ocaml.format_with [%derive.ocaml_of: string list]) cmis;
    (* XXX It only reports warning when cmis is completely empty *)
    if cus <> [] && cmis = [] then begin
      !!% "@[<2>WARNING: Ocamlfind.analyze: no cmis found at all %s!  Units are:@ @[%a@]@]@." p.dir Format.(list "@ " string) cus;
    end;
    if !debug then !!% "@.@.";
    { package = p;
      archives = arcs;
      compilation_units = cus;
      cmis = cmis;
    }


module Analyzed_group = struct
  type t = {
    name : string;
    packages : Analyzed.t list;
    not_linked_cmis : string list;
  } [@@deriving conv{ocaml}]

  let top_dir ag = match ag.packages with
    | [] -> assert false
    | ap::_ -> ap.Analyzed.package.Package.dir

  let dirs ag = unique & map (fun p -> p.Analyzed.package.Package.dir) ag.packages
end

let analyze_group ~stdlib_dir g =
  let open Analyzed in
  let open Analyzed_group in
  let aps = map analyze g.Group.packages in
  let linked_cmis = unique & concat_map (fun x -> x.cmis) aps in
  let not_linked_cmis = 
    let dir = (hd aps).package.dir in
    if dir = stdlib_dir then []
    else
      (* Filenames by fold_dir may differ from those in linked_cmis
         in case insensitive file systems. Therefore we need the following
         stupid hack.
      *)
      let same_file f1 f2 =
        let normalize f =
          (* Keep dirname as is, since it may be non-ascii *)
          Filename.(dirname f ^/ String.lowercase_ascii (basename f))
        in
        let inode f =
          try (Unix.stat f).st_ino with _ -> assert false
        in
        normalize f1 = normalize f2
        && inode f1 = inode f2
      in
      Unix.fold_dir dir [] (fun xs f ->
        match Filename.split_extension f with
        | _, ".cmi" ->
            let f = dir ^/ f in
            if exists (same_file f) linked_cmis then xs else f::xs
        | _ -> xs)
  in
  { name = g.Group.name;
    packages = aps;
    not_linked_cmis;
  }

let group_and_analyze ~stdlib_dir pks =
  let gs = group pks in
  map (analyze_group ~stdlib_dir) gs

let accessible_cmis apg ap =
  unique & ap.Analyzed.cmis @ apg.Analyzed_group.not_linked_cmis

let test () =
  let oc = init () in
  let stdlib_dir = get_stdlib_dir oc in
  !!% "STDLIB DIR: %s@." stdlib_dir;
  let gs = group & get_packages oc in
  let gaps = map (analyze_group ~stdlib_dir) gs in
  !!% "@[<2>%a@]@."
    (Ocaml.format_with [%derive.ocaml_of: Analyzed_group.t list])
    gaps;
    
  ()

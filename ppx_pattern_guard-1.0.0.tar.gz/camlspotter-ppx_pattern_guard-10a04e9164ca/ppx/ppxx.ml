open Parsetree
open Asttypes
open Ast_mapper
open Longident
open Ast_helper

(* (@@) is too strong *)
external ( & ) : ('a -> 'b) -> 'a -> 'b = "%apply"

let (!!%) = Format.eprintf

let ($.) l s = Ldot (l, s)
let (!$) s = Lident s
let (!..) xs = 
  let rec f = function
    | [] -> assert false
    | [x] -> Lident x
    | x::xs -> Ldot (f xs, x)
  in
  f (List.rev xs)

let make_loc ?(loc = !Ast_helper.default_loc) txt = { txt; loc }

let partition p = List.partition (fun ({txt}, _payload) -> p txt)

let with_default_loc loc f = 
  let back = !Ast_helper.default_loc in
  Ast_helper.default_loc := loc;
  let res = f () in
  Ast_helper.default_loc := back;
  res

module Exp = struct
  include Exp
  let string ?loc s = constant ?loc & Const_string (s, None)
  let int ?loc i = constant ?loc & Const_int i
  let var ?loc s = ident ?loc & make_loc ?loc (Longident.Lident s)

  let parse s =
    try
      Parser.parse_expression Lexer.token (Lexing.from_string s)
    with
    | _e -> failwith (Printf.sprintf "parse fail: %s" s)
        
end

module Pat = struct
  include Pat
  let var ?loc ?attrs s = var ?loc ?attrs (make_loc ?loc s)
end

module Cf = struct
  include Cf

  let method_concrete ?loc ?attrs name ?(priv=false) ?(override=false) e = 
    Cf.method_ ?loc ?attrs name (if priv then Private else Public)
      (Cfk_concrete ((if override then Override else Fresh), e))
  let method_virtual ?loc ?attrs name ?(priv=false) cty = 
    Cf.method_ ?loc ?attrs name (if priv then Private else Public)
      (Cfk_virtual cty)
end

let test mapper name = 
  try
    if Filename.check_suffix name ".ml" then (* .mlt ? *)
      let str = Pparse.parse_implementation ~tool_name:"ppx" Format.err_formatter name in
      let str = mapper.structure mapper str in
      Pprintast.structure Format.std_formatter str
    else if Filename.check_suffix name ".mli" then 
      let sg = Pparse.parse_interface ~tool_name:"ppx" Format.err_formatter name in
      let sg = mapper.signature mapper sg in
      Pprintast.signature Format.std_formatter sg
    else assert false;
    Format.fprintf Format.std_formatter "@."
  with
  | Syntaxerr.Error e ->
      !!% "%a@." Syntaxerr.report_error e

let run name mapper = 
  let debug = ref false in
  let rev_files = ref [] in 
  Arg.parse 
    [ "-debug", Arg.Set debug, "debug mode which can take .ml/.mli then print the result"
    ]
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    name;
  match !debug, List.rev !rev_files with
  | true, files ->
      List.iter (test mapper) files
  | false, [infile; outfile] ->
      Ast_mapper.apply ~source:infile ~target:outfile mapper
  | _ -> 
      failwith @@ name ^ " infile outfile"

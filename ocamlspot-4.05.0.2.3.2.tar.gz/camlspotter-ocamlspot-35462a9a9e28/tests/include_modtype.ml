include Capital_idents

module N : E (* ? modtype E *) = M (* ? module M *)

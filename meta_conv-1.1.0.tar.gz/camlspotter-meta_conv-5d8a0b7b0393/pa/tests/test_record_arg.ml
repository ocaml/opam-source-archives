type t = { foo as "Foo" : int; 
           mutable bar as "Bar" : float } 
with conv(json)


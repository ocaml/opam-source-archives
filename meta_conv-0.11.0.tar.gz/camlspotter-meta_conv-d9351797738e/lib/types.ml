module Error = struct

  type 'target desc =
    | Deconstruction_error of 
        exn (** exception of the Decode.tuple, variant or record *)
    | Unknown_fields of 
        string (** type name *) 
        * (string * 'target) list (** unknown fields *)
    | Required_fields_not_found of 
        string (** type name *)
        * string list (** missing fields *)
        * (string * 'target) list (** the input *)
    | Wrong_arity of 
        int (** expected *) 
        * int (** actual *) 
        * (string * string) option (** type name and tag, if tuple, None *) 
    | Primitive_decoding_failure of 
        string (** message *)
  
  type 'target t = 'target desc * 'target

  open Format

  let rec format_list sep f ppf = function
    | [] -> ()
    | [x] -> f ppf x
    | x::xs -> f ppf x; fprintf ppf sep; format_list sep f ppf xs

  let format_desc f ppf = 
    function
      | Deconstruction_error exn -> 
          fprintf ppf "Deconstruction error(%s)" (Printexc.to_string exn)
      | Unknown_fields (tyname, fields) ->
          fprintf ppf "@[<v2>Unknown fields of type %s:@ [ @[%a@] ]@]"
            tyname
            (format_list ";@ " (fun ppf (s, v) ->
              fprintf ppf "@[<v2>%s=@ @[%a@]@]" s f v)) fields
      | Required_fields_not_found (tyname, fields, _) ->
          fprintf ppf "@[<v2>Required fields not found of type %s:@ [ @[%a@] ]@]"
            tyname
            (format_list ";@ " (fun ppf s -> fprintf ppf "%s" s)) fields
      | Wrong_arity (exp, act, None) ->
          fprintf ppf "Wrong arity of tuple %d (expected=%d)" act exp
      | Wrong_arity (exp, act, Some (tyname, tag)) ->
          fprintf ppf "Wrong arity of type %s of tag %s, %d (expected=%d)" tyname tag act exp
      | Primitive_decoding_failure mes ->
          fprintf ppf "Primitive decoding failure: %s" mes

  let format f ppf (desc, _target : 'target t) = format_desc f ppf desc
  
end

module Result = struct

  (** Result monad *)
  type ('a, 'error) t =
    [ `Ok of 'a 
    | `Error of 'error
    ]

  let bind t f = match t with
    | `Ok v -> f v
    | `Error err -> `Error err

  let (>>=) = bind

  let fmap f t = match t with
    | `Ok v -> `Ok (f v)
    | `Error err -> `Error err

  let map dec ts =
    let rec map st = function
      | [] -> `Ok (List.rev st)
      | t::ts -> 
          match dec t with
          | `Ok h -> map (h::st) ts
          | `Error err -> `Error err
    in
    map [] ts

  module Open = struct
    let (>>=) = (>>=)
  end
end

module Decoder = struct
  type ('host, 'target) t = 'target -> ('host, 'target Error.t) Result.t
  type ('host, 'target) t_exn = 'target -> 'host
end

type ('host, 'target) mc_lazy_t = ('host, 'target Error.t) Result.t lazy_t

type 'target mc_fields = (string * 'target) list
(** Not-yet-decoded fields *)

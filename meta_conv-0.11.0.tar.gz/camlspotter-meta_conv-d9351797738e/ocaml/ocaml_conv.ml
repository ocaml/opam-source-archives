open Meta_conv.Types
open Meta_conv.Types.Error
open Meta_conv.Internal
open Ocaml

module Encode = struct
  let tuple ts = Tuple ts
  let variant tag ts = Variant (tag, ts)
  let poly_variant tag ts = Poly_variant (tag, ts)
  let record fields = Record fields
  let object_ fields = Object fields
end

let ocaml_of_unit () = Unit
let ocaml_of_bool b = Bool b
let ocaml_of_int32 n = Int32 n
let ocaml_of_int64 n = Int64 n
let ocaml_of_float n = Float n
let ocaml_of_char c = Char c
let ocaml_of_string s = String s
let ocaml_of_list f xs = List (List.map f xs)
let ocaml_of_array f xs = Array (List.map f (Array.to_list xs))
let ocaml_of_option f = function
  | None -> Variant ("None", [])
  | Some v -> Variant ("Some", [f v])
let ocaml_of_lazy_t f z = f (Lazy.force z)

exception Error of t Error.t
type 'a decoder = ('a, t) Decoder.t

let errorf v fmt = 
  Printf.kprintf (fun s -> `Error (Primitive_decoding_failure s, v)) fmt

module Decode = struct
  let tuple = function 
    | Tuple ts -> ts
    | _ -> failwith "Tuple expected for tuple"

  (* Variants and poly variants, and records and objects 
     are compatible each other, resp.ly. *)

  let variant = function 
    | Variant (tag, ts) -> tag, ts
    | Poly_variant (tag, ts) -> tag, ts
    | _ -> failwith "Variant expected for variant"

  let poly_variant = function 
    | Variant (tag, ts) -> tag, ts
    | Poly_variant (tag, ts) -> tag, ts
    | _ -> failwith "Poly_variant expected for poly_variant"

  let record = function
    | Record alist -> alist
    | Object alist -> alist
    | _ -> failwith "Record expected for record"

  let object_ = function 
    | Object alist -> alist
    | Object alist -> alist
    | _ -> failwith "Object expected for object"

end

let unit_of_ocaml = function
  | Unit -> `Ok ()
  | v -> errorf v "unit_of_ocaml: Unit expected"
      
let bool_of_ocaml = function
  | Bool b -> `Ok b
  | v -> errorf v "bool_of_ocaml: Bool expected"

let string_of_ocaml = function
  | String s -> `Ok s
  | v -> errorf v "string_of_ocaml: String expected"

let char_of_ocaml = function
  | Char c -> `Ok c
  | v -> errorf v "char_of_ocaml: a char expected"

let int32_of_ocaml = function
  | Int32 n -> `Ok n
  | v -> errorf v "int32_of_ocaml: int32 expected"

let int64_of_ocaml = function
  | Int64 n -> `Ok n
  | v -> errorf v "int64_of_ocaml: int64 expected"

let float_of_ocaml = function
  | Float n -> `Ok n
  | v -> errorf v "float_of_ocaml: float expected"

let list_of_ocaml f = 
  generic_list_of (function List xs -> Some xs | _ -> None) f

let array_of_ocaml f = 
  generic_array_of (function Array xs -> Some xs | _ -> None) f
  
let option_of_ocaml f = 
  generic_option_of (function
    | Variant ("None", []) -> Some None 
    | Variant ("Some", [v]) -> Some (Some v)
    | _ -> None) f

let lazy_t_of_ocaml d = generic_lazy_t_of (fun e -> raise (Error e)) d
let mc_lazy_t_of_json = generic_mc_lazy_t_of

(** Arch dependent enc/decoders *)
  
module type SArch = sig
  val ocaml_of_int : int -> t
  val ocaml_of_nativeint : nativeint -> t
  val int_of_ocaml : int decoder
  val nativeint_of_ocaml : nativeint decoder
end
  
module Arch32 = struct
  let ocaml_of_int n = Int31 n
  let ocaml_of_nativeint n = Nativeint32 (Nativeint.to_int32 n)

  let int_of_ocaml  = function
    | Int31 n -> `Ok n
    | (Int63 n as v) ->
        let n' = Int64.to_int n in
        if n <> Int64.of_int n' then errorf v "int_of_ocaml: overflow"
        else `Ok n'
    | v -> errorf v "int_of_ocaml: int expected"

  let nativeint_of_ocaml  = function
    | Nativeint32 n -> `Ok (Nativeint.of_int32 n)
    | (Nativeint64 n as v) ->
        let n' = Int64.to_nativeint n in
        if n <> Int64.of_nativeint n' then errorf v "nativeint_of_ocaml: overflow"
        else `Ok n'
    | v -> errorf v "int_of_ocaml: nativeint expected"
end

module Arch64 = struct
  let ocaml_of_int n = Int63 (Int64.of_int n)
  let ocaml_of_nativeint n = Nativeint64 (Int64.of_nativeint n)

  let int_of_ocaml = function
    | Int31 n -> `Ok n
    | Int63 n -> `Ok (Int64.to_int n)
    | v -> errorf v "int_of_ocaml: int expected"

  let nativeint_of_ocaml = function
    | Nativeint32 n -> `Ok (Nativeint.of_int32 n)
    | Nativeint64 n -> `Ok (Int64.to_nativeint n)
    | v -> errorf v "int_of_ocaml: nativeint expected"

end

let arch = 
  match Sys.word_size with
  | 32 -> (module Arch32 : SArch)
  | 64 -> (module Arch64 : SArch)
  | _ -> assert false

include (val arch)


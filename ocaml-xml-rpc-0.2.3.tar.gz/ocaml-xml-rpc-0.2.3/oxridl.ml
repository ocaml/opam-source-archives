(* Ocaml XML-RPC IDL Compiler 
   Copyright (C) 2004 Shawn Wagner

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*)

(* It's very stupid right now. *)

let version = "0.0.1"

let strip_ws_re = Pcre.regexp ~study:true "(?:^\\s+)|(?:\\s+$)"
let strip_ws = Pcre.substitute ~rex:strip_ws_re ~subst:(function s -> "")

let match_remote =
  Pcre.regexp ~study:true
    "^remote\\s+(\\w+)\\s*:((?:\\s+\\w+(?: array)?\\s+->)+)\\s+(\\w+(?: array)?)\\s+=\\s+\"([^\"]+)\"\\s+\"([^\"]+)\"$"

let match_local = 
  Pcre.regexp ~study:true
    "^handle\\s+(\\w+)\\s*:((?:\\s+\\w+(?: array)?\\s+->)+)\\s+(\\w+(?: array)?)\\s+=\\s+\"([^\"]+)\"$"

let check_ident = Pcre.regexp ~study:true "^\\w+$"

type error = Bad_keyword | Bad_type | Generic_error
exception Parse_error of error * string

type 'a remote = 
    { ident: string;
      host: string;
      name: string;
      ret_type: 'a;
      args: 'a list
    }

type 'a local =
    { l_ident: string;
      l_name: string;
      l_args: 'a list;
      l_ret_type: 'a;
    }

let check_type = function
  | "unit" -> `Unit
  | "raw" -> `Raw
  | "int" -> `Int
  | "int32" -> `Int32
  | "float" -> `Float
  | "bool" -> `Bool
  | "string" -> `String
  | "struct" -> `Struct
  | "datetime" -> `DateTime
  | "base64" -> `Base64
  | "rawbase64" -> `RawBase64
  | "raw array" ->  `Array `Raw
  | "int array" -> `Array `Int
  | "int32 array" -> `Array `Int
  | "float array" -> `Array `Float
  | "bool array" -> `Array `Bool
  | "base64 array" -> `Array `Base64
  | "rawbase64 array" -> `Array `RawBase64
  | "string array" -> `Array `String
  | "struct array" -> `Array `Struct
  | t -> raise (Parse_error (Bad_type, t))

let rec to_string = function
  | `Unit -> "unit"
  | `Int -> "int"
  | `Int32 -> "int32"
  | `Float -> "float"
  | `Bool -> "bool"
  | `String |`DateTime | `Base64 | `RawBase64 -> "string"
  | `Struct -> "XmlRPCTypes.xrs"
  | `Raw -> "XmlRPCTypes.t"
  | `Array t -> (to_string t) ^ " array"
      
let rec convert_to_xr ia = function
  | (_, `Unit) -> "`Unit"
  | (name, `Raw) -> (if ia then "xr_of_array " else "") ^ name
  | (name, `Int) -> if ia 
    then  "Array.map (function x -> `Int (Int32.of_int x)) " ^ name
    else  "`Int (Int32.of_int " ^ name ^ ")"
  | (name, `Int32) -> (if ia then "Array.map (function x -> `Int x) "
		       else "`Int ") ^ name
  | (name, `Float) -> (if ia then "Array.map (function x -> `Double x) "
		       else "`Double ") ^ name
  | (name, `Bool) -> (if ia then "Array.map (function x -> `Boolean x) " 
		      else "`Boolean ") ^ name
  | (name, `String) -> (if ia then "Array.map (function x -> `String x) "
			else "`String ") ^ name
  | (name, `Base64) ->
      (if ia then "Array.map " else "") ^ "xr_of_base64 " ^ name
  | (name, `RawBase64) -> (if ia then "Array.map (function x -> `RawBase64 x) "
			   else "`RawBase64 ") ^ name
  | (name, `DateTime) -> (if ia then "Array.map (function x -> `DateTime x) "
			  else "`DateTime ") ^ name
  | (name, `Struct) -> (if ia then "Array.map (function x -> `Struct x) "
			else "`Struct ") ^ name
  | (name, `Array at) -> 
      "`Array " ^ "(" ^ (convert_to_xr true (name, at)) ^ ")"

let convert_to_ml t name =
  let rec conv_type t = match t with
  | `Unit -> "()"
  | `Raw -> "ml_of_"
  | `Int -> "ml_of_int"
  | `Int32 -> "ml_of_int32"
  | `Float -> "ml_of_float" 
  | `Bool -> "ml_of_bool" 
  | `String -> "ml_of_string" 
  | `Base64 -> "ml_of_base64"
  | `RawBase64 -> "ml_of_rawbase64"
  | `DateTime -> "ml_of_datetime"
  | `Struct -> "ml_of_struct"
  | `Array at -> (conv_type at) ^ "array"
 in
      if t = `Unit then 
	"()"
      else if t = `Raw then
	name
      else
	(conv_type t) ^ " " ^ name
let split_params_re = Pcre.regexp ~study:true "\\s+->\\s*"

let split_params params = 
  let bits = Pcre.split ~rex:split_params_re params in
    List.map (function t -> check_type (strip_ws t)) bits

let parse_remote remote = 
  try
    let subs = Pcre.extract ~full_match:false ~rex:match_remote remote in
      {
	ident = subs.(0);
	args = split_params subs.(1);
	ret_type = check_type (strip_ws subs.(2));
	host = subs.(3);
	name = subs.(4)
      }
  with Not_found -> raise (Parse_error (Generic_error, "Parse Error: Invalid line"))

let parse_local local =
  try
    let subs = Pcre.extract ~full_match:false ~rex:match_local local in
      {
	l_ident = subs.(0);
	l_name = subs.(3);
	l_args = split_params subs.(1);
	l_ret_type = check_type (strip_ws subs.(2));	
      }
  with Not_found -> raise (Parse_error (Generic_error, "Parse Error: Invalid line"))

let first = function (a,_) -> a
let second = function (_, b) -> b

let process_remote outfi outfs line = 
  let rem = parse_remote line in
    (* Write the .mli signature *)
    Printf.fprintf outfi "val %s: %s -> %s\n"
      rem.ident
      (String.concat " -> " (List.map to_string rem.args))
      (to_string rem.ret_type);
    (* Write the .ml implementation *)
    let count = ref 0 in
    let argnames = List.map (function t -> incr count;
			       if t = `Unit then
				 ("()", t)
			       else
				 ("a" ^ (string_of_int !count), t)) rem.args in
    Printf.fprintf outfs "let %s_stub = new remote \"%s\" \"%s\"\n"
      rem.ident rem.host rem.name;
    Printf.fprintf outfs "let %s %s = \n"
      rem.ident
      (String.concat " " (List.map first argnames));
    Printf.fprintf outfs " let retval = %s_stub#call [%s] in\n"
      rem.ident (String.concat ";\n "
		   (List.map (convert_to_xr false) argnames));
    output_string outfs (convert_to_ml rem.ret_type "retval");
    output_string outfs "\n\n"

let process_local outfi outfs line =
  let loc = parse_local line in
  let nargs = List.length loc.l_args in
    (* Write the .mli signature *)
    Printf.fprintf outfi "type %s_t = %s -> %s\n" loc.l_ident 
      (String.concat " -> " (List.map to_string loc.l_args))
      (to_string loc.l_ret_type);
    Printf.fprintf outfi "val %s: XmlRPCServer.t -> %s_t -> unit\n" loc.l_ident  loc.l_ident;
    (* Write the .ml implementation *)
    Printf.fprintf outfs "type %s_t = %s -> %s\n" loc.l_ident 
      (String.concat " -> " (List.map to_string loc.l_args))
      (to_string loc.l_ret_type);
    Printf.fprintf outfs "let %s_stub callback args = " loc.l_ident;
    Printf.fprintf outfs "if Array.length args <> %d then raise (Error (\"Bad Argument Count\", Array.length args))\nelse " nargs ;
    Printf.fprintf outfs "let retval = callback ";
    let idx = ref 0 in
    List.iter (function arg ->
		  Printf.fprintf outfs "(%s) "
		 (convert_to_ml arg (Printf.sprintf "args.(%d)" !idx)); incr idx)
      loc.l_args;
    Printf.fprintf outfs "\nin %s\n" (convert_to_xr false ("retval", loc.l_ret_type));
    Printf.fprintf outfs "let %s handler callback = \n" loc.l_ident;
    Printf.fprintf outfs "register_callback handler \"%s\" (%s_stub callback)\n"
      loc.l_name loc.l_ident

let process_line outfi outfs raw =
  let line = strip_ws raw in
  if String.length line > 0 && String.get line 0 != '#' then 
    match StrExtras.first_word line with
      | "remote" -> ignore (process_remote outfi outfs line)
      | "handle" -> ignore (process_local outfi outfs line)
      | keyword -> raise (Parse_error (Bad_keyword, keyword))
  else ()
      	       
let process_file file ~outfi ~outfs = 
  let ic = open_in file in
    try
      let now = Time.time_string (Time.time ()) in
      Printf.fprintf outfi "(* Created by oxridl from '%s' on %s *)\n"
	file now;
      Printf.fprintf outfs "(* Created by oxridl from '%s' on %s *)\n"
	file now;
      output_string outfs "open XmlRPCTypes\n";
      output_string outfs "open XmlRPCClient\n";
      output_string outfs "open XmlRPCServer\n";
      Pcre.foreach_line ~ic (process_line outfi outfs);
      close_in ic
    with
	any -> close_in ic; raise any
    
let main () =
  let output_file_set = ref false 
  and output_file_name = ref "" 
  and idl_files = ref [] in
    Arg.parse [("-o",
		 Arg.String (function n -> output_file_set := true;
				output_file_name := n),
		 "Use FOO.ml and FOO.mli as the output files");
	      ("--version",
	       Arg.Unit (function () -> 
			   Format.printf
			   "oxridl version %s@.@.Copyright (C) 2002 Shawn Wagner@.@[There@ is@ NO@ warranty.@ You@ may@ redistribute@ this@ software@ under@ the@ terms@ of the@ GNU@ General@ Public@ License.@ For@ more@ information@ about@ these@ matters,@ see@ the@ file@ named@ COPYING.@]@." version;
			   exit 0),
	       "Display version information")
	      ]
	(function file -> idl_files := file :: !idl_files)
	"Usage: oxridl [-o module_name] file.idl ...";
    if !output_file_set then      
	let o1 = !output_file_name ^ ".mli"
	and o2 = !output_file_name ^ ".ml" in
	  Printf.printf
	    "Writing interface to %s and stubs to %s for all idl files\n" o1 o2;
	  let outfi = open_out o1
	  and outfs = open_out o2 in
	  try 
	    List.iter (process_file ~outfi ~outfs) !idl_files;
	    close_out outfi; close_out outfs
	  with any ->
	    close_out outfi; close_out outfs;
	    Sys.remove o1; Sys.remove o2;
	    raise any
    else
      List.iter (function file ->
		   try begin
		     let basename = Filename.basename file in
		     let modname = Filename.chop_extension basename in
		     let o1 = modname ^ ".mli" 
		     and o2 = modname ^ ".ml" in
		     let outfi = open_out o1
		     and outfs = open_out o2 in
		       Printf.printf
			 "Writing interface to %s and stubs to %s for %s\n"
			 o1 o2 file;
		       try
			 process_file file ~outfi ~outfs;
			 close_out outfi; close_out outfs
		       with any ->
			 close_out outfi; close_out outfs;
			 Sys.remove o1; Sys.remove o2;		   
			 raise any
		   end with Sys_error s ->
		     Printf.printf
		     "Error while processing file %s: %s\n" file s) !idl_files

let _ =
  try
    main () 
  with
    | Parse_error (Bad_type, s) ->
	Printf.printf "Error: Invalid type: %s\n" s
    | Parse_error (Bad_keyword, s) ->
	Printf.printf "Error: Unknown keyword: %s\n" s
    | Parse_error (_, s) ->
	Printf.printf "Error: %s\n" s
    | Sys_error s -> Printf.printf "Error; %s\n" s
		     

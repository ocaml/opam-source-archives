(* Created by oxridl from 'add.idl' on Fri Mar 12 16:09:05 2004 *)
open XmlRPCTypes
open XmlRPCClient
open XmlRPCServer
type add_two_t = int -> int -> int
let add_two_stub callback args = if Array.length args <> 2 then raise (Error ("Bad Argument Count", Array.length args))
else let retval = callback (ml_of_int args.(0)) (ml_of_int args.(1)) 
in `Int (Int32.of_int retval)
let add_two handler callback = 
register_callback handler "add.two" (add_two_stub callback)
let addcgi_stub = new remote "http://localhost/cgi-bin/add.cgi" "add.two"
let addcgi a1 a2 = 
 let retval = addcgi_stub#call [`Int (Int32.of_int a1);
 `Int (Int32.of_int a2)] in
ml_of_int retval

let addhttp_stub = new remote "http://localhost:8000" "add.two"
let addhttp a1 a2 = 
 let retval = addhttp_stub#call [`Int (Int32.of_int a1);
 `Int (Int32.of_int a2)] in
ml_of_int retval


(* Created by oxridl from 'div.idl' on Fri Mar 12 11:28:00 2004 *)
open XmlRPCTypes
let div_stub = new XmlRPCClient.remote "http://xmlrpc-c.sourceforge.net/api/sample.php" "sample.sumAndDifference"
let div a1 a2 = 
 let retval = div_stub#call [`Int (Int32.of_int a1);
 `Int (Int32.of_int a2)] in
ml_of_struct retval




let _ =
  try
    let server = HttpdSource.make ~port:8000 () in
      Add.add_two server (+);
      XmlRPCServer.run server
  with
    | CgiSource.Done -> exit 0





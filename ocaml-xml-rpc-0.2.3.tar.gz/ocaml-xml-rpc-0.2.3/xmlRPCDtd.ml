(*
    Ocaml XML-RPC support.
    Copyright (C) 2004 Shawn Wagner <raevnos@pennmush.org>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*)

open Pxp_yacc

(*
     XML-RPC DTD
     Richard Moore 1999, rich@kde.org 
     DTD Version: 0.1 
     Draft:  $Date: Fri, 12 Mar 2004 12:12:05 -0800 $ 
    
     This DTD is based on the XML-RPC specification document which can
     be found at <http://www.xmlrpc.com/spec>.  There is no version number
     in the document, but the version used stated it was last updated on
     1/21/99 by DW.
  
     The root element in an XML-RPC document must be either a methodCall or
     a methodResponse element.

     Typical usage:

     <!DOCTYPE methodCall SYSTEM "xml-rpc.dtd">
     <?xml version="1.0"?>
     <methodCall>
       <methodName>examples.getStateName</methodName>
       ...
     </methodCall>

     Typical usage, enabling version 2 extensions:

     <!DOCTYPE methodCall SYSTEM "xml-rpc.dtd" [
       <!ENTITY % XMLRPC.version2 "INCLUDE">
     ]>
     <?xml version="1.0"?>
     <methodCall>
       <methodName>examples.getStateName</methodName>
       <params><param><value><nil/></value></param></params>
     </methodCall>

  -->    

<!--
     1999-10-28  Fred Yankowski  <fred@ontosys.com>
	Make params optional in methodCall.
	Allow zero members in struct.
        Remove #PCDATA from value content model.
        Add version 2 extension:  nil element.
  -->
*)

let dtd = "
<!ENTITY % XMLRPC.version2 'IGNORE'>

<![ %XMLRPC.version2; [
<!ELEMENT nil
	  EMPTY
  >
<!ENTITY % v2values \"| nil\" >
]]>

<!ENTITY % v2values \"\">

<!ELEMENT i4
          (#PCDATA)>

<!ELEMENT int
          (#PCDATA)>

<!ELEMENT boolean
          (#PCDATA)>

<!ELEMENT string
          (#PCDATA)>

<!ELEMENT double
          (#PCDATA)>

<!ELEMENT dateTime.iso8601
          (#PCDATA)>

<!ELEMENT base64
          (#PCDATA)>

<!ELEMENT data
          (value*)>

<!ELEMENT array
          (data)>

<!ELEMENT name
          (#PCDATA)>

<!ELEMENT member
          (name, value)>

<!ELEMENT struct
          (member*)>

<!ELEMENT value
          ( i4 | int | boolean | string | dateTime.iso8601
            | double | base64 | struct | array
            %v2values;
          )
  >

<!ELEMENT param
          (value)>
<!ELEMENT params
          (param*)>

<!ELEMENT methodName
          (#PCDATA)>

<!ELEMENT methodCall
          (methodName, params?)>

<!ELEMENT fault
          (value)>

<!ELEMENT methodResponse
          (params|fault)>

"

let parsed_dtd_internal = 
  lazy (let p = parse_dtd_entity default_config (from_string dtd) in
	  p#set_root "methodResponse";
	  p)
	  

let parsed_dtd () = Lazy.force parsed_dtd_internal

let parsed_server_dtd_internal = 
  lazy (let p = parse_dtd_entity default_config (from_string dtd) in
	  p#set_root "methodCall";
	  p)
	  

let parsed_server_dtd () = Lazy.force parsed_server_dtd_internal

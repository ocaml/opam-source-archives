(* Ocaml XML-RPC IDL Compiler 
   Copyright (C) 2004 Shawn Wagner

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*)


exception Done

class cgi_source = object

  method get_request () =
    let buf = Buffer.create (try
			       int_of_string (Sys.getenv "CONTENT_LENGTH")
			     with
			       | Not_found | Failure _ -> 512) in
      try
	while true do
	  let line = read_line () in
	    Buffer.add_string buf line
	done;
	Buffer.contents buf
      with End_of_file -> Buffer.contents buf
    

  method send_reply str = 
    print_string "Content-Length: ";
    print_int (String.length str);
    print_string "\r\nContent-Type: text/xml\r\n";
    print_string "Date: ";
    print_string (Time.time_string (Time.time ()));
    print_string "\r\nServer: ";
    print_string XmlRPCServer.server;
    print_string "\r\n\r\n";
    print_string str;    
    raise Done;
    ()

end

let make () = XmlRPCServer.make (new cgi_source)

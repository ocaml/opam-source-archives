(*
    Ocaml XML-RPC support.
    Copyright (C) 2002 Shawn Wagner <raevnos@pennmush.org>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*)
open Netencoding
open Pxp_yacc
open Pxp_document
open Pxp_types

exception Request_failed of string
exception Request_fault of XmlRPCTypes.fault

let xml_version = "<?xml version=\"1.0\"?>"
let client_version = "0.0.2"

let agent="Ocaml-XML-RPC/" ^ client_version ^ " (" ^ Sys.os_type ^ ")"

let format_params buf args =
  let rec format_one =
    function
      | car :: cdr ->
	  Buffer.add_string buf "<param>\n";
	  Buffer.add_string buf (XmlRPCTypes.print_type car);
	  Buffer.add_string buf "</param>\n";
	  format_one cdr
      | [] -> () in
    format_one args

let format_request f args = 
  let buf = Buffer.create 512 in
    Buffer.add_string buf xml_version;
    Buffer.add_string buf "\n<methodCall>\n<methodName>";
    Buffer.add_string buf f;
    Buffer.add_string buf "</methodName>\n<params>\n";
    format_params buf args;
    Buffer.add_string buf "</params>\n</methodCall>\n";
    Buffer.contents buf
      
let parse_params = function
  | p::[] -> XmlRPCTypes.parse_value p
  | _ -> raise (Request_failed "Malformed response")

let transform_dtd d = XmlRPCDtd.parsed_dtd ()

(* Warning here is okay *)
let nodename n = match n#node_type with
  | T_element name -> name

let handle_response xml =
  try
    let methresp =
      parse_document_entity ~transform_dtd default_config
	(from_string xml) default_spec in
    let repval = List.hd methresp#root#sub_nodes in
    let repname =nodename repval in
    let body = repval#sub_nodes in
      if repname = "fault" then
	let fault_struct = XmlRPCTypes.parse_value (List.hd body) in
	  raise (Request_fault (XmlRPCTypes.ml_of_fault fault_struct))
      else (* params *)
	parse_params (List.hd body)#sub_nodes
  with
    | Validation_error e | WF_error e ->
	raise (Request_failed ("Malformed response: " ^ e))
    | At (where, e) -> begin
	let msg = match e with
	  | Validation_error e | WF_error e -> e
	  | _ -> "PXP error" in
	raise (Request_failed ("Malformed response: " ^ msg))
      end
    
let make_request m trials =
  XmlRPCNet.handler#add m;
  let rec next_trial todo e =
    if todo > 0 then begin
      try
	XmlRPCNet.handler # run()
      with
	| Http_client.Http_error(n,s) as e' ->
	    if List.mem n [408; 413; 500; 502; 503; 504 ] then
	      next_trial (todo-1) e'
	    else
	      raise e'
	| e' -> next_trial (todo-1) e'
    end
    else
      raise e
  in
    next_trial trials (Failure "bad number of http_trials")

let do_request server f args =
  let methodcall = format_request f args in
  let req = new Http_client.post_raw server methodcall in
    req#set_req_header "Content-Type" "text/xml";
    req#set_req_header "User-Agent" agent;
    req#set_req_header "Content-length"
      (string_of_int (String.length methodcall));
    make_request req 5;
    if not req#is_served then 
      raise (Request_failed "Couldn't get valid response from server")
    else
      handle_response (req#get_resp_body())

class remote host func =
object
  method zero_call () = do_request host func []
  method simple_call arg = do_request host func [arg]		
  method call = do_request host func
end
    

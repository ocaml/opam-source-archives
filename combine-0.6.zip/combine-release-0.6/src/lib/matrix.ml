
type 'a matrix = 'a array array

let copy m = Array.map Array.copy m



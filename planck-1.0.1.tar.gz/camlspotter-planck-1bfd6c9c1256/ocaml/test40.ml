let _ = { a = !b.c } (* CORRECT <!b>.c *)



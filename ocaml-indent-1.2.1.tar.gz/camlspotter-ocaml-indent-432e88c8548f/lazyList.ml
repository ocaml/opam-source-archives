type 'a desc = 
  | Cons of 'a * 'a t
  | Null

and 'a t = 'a desc lazy_t

let peek = function
  | lazy Null -> None
  | lazy (Cons (car, cdr)) -> Some (car, cdr)

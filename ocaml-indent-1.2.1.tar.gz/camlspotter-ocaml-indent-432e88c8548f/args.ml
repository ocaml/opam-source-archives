let paths, debug, lines, showstate, cursor =
  let rev_paths = ref [] in
  let debug = ref false in
  let lines = ref None in
  let showstate = ref false in
  let cursor = ref None in
  Arg.parse [
    ("-debug", Arg.Set debug, "debugging");
    ("-lines", Arg.String (fun s ->
      try
        let pos = String.index s '-' in
        let (start,end_) = (int_of_string (String.sub s 0 pos),
                            int_of_string (String.sub s (pos+1) (String.length s - pos - 1))) in
        if start <= 0 || end_ <= 0 || start > end_ then
          failwith (Printf.sprintf "Wrong -lines specification: %s" s);
        lines := Some (start, end_)
      with
      | _ -> failwith (Printf.sprintf "Wrong -lines specification: %s" s)),
     "lines, ex. 10-12") ;
    ("-cursor", Arg.String (fun s ->
      try
        let pos = String.index s ':' in
        let (lines,cols) = (int_of_string (String.sub s 0 pos),
                           int_of_string (String.sub s (pos+1) (String.length s - pos - 1))) in
        if lines <= 0 || cols < 0 then
          failwith (Printf.sprintf "Wrong -cursor specification: %s" s);
        cursor := Some (lines, cols)
      with
      | _ -> failwith (Printf.sprintf "Wrong -cursor specification: %s" s)),
     "cursor position, ex. 10:12") ;
    ("-show-state", Arg.Set showstate, "show state at the last");
  ] (fun s -> rev_paths := s :: !rev_paths) "indent paths";
  let paths = List.rev !rev_paths in
  let paths = if paths = [] then [""] else paths in (* CR jfuruse: ugly *)
  begin match paths, !lines with
  | [], _ -> assert false
  | [_], _ -> ()
  | _, Some _ -> failwith "Region can be specified with at most one file"
  | _ -> ()
  end;
  paths, !debug, !lines, !showstate, !cursor

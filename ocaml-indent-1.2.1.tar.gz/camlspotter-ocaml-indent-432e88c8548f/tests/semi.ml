let x =
  if true then
    1;
  2;
  3
;;


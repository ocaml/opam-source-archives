let token state region str at_the_head (t : Parser.token) : State.t * State.t = 
  let line = Region.lnum region in
  let columns = Region.columns region in
  let indent = state.last_indent in
  let bases0 = state.bases in

  let pre_bases, post_bases = match t with
    | SEMISEMI ->
        (* unwind the top *)
        let bases = unwind_top bases0 in
        bases, bases

    | OPEN -> 
        let bases = unwind_top bases0 in
        bases, { k = KOpen; indent = Indent.Set (columns + 2); line } :: bases


let token state region str at_the_head (t : Parser.token) : State.t * State.t = 
  let pre_bases, post_bases = match t with
    | EQUAL ->
        (* CR jfuruse: TODO
           - pre bases
           - for non definition equals *)
        let rec f = function
          | ({k = (KLet (_,columns) | KType columns | KModule columns) } :: bs as bases) -> 
              bases, bases
          | { k = (KBrace _ | KBracket _ | KParen _) } :: _ -> bases0, bases0
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0
  in
  ()


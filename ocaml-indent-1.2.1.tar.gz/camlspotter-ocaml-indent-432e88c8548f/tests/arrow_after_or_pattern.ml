let rec is_top_let = function
  | None -> true
  | Some t ->
      match t with
      | COMMENT -> assert false (* COMMENT must be skipped *)
      | COLON | CLASS | BARRBRACKET
        -> true
      | COLON | CLASS | BARRBRACKET
        -> 
          true
      | _ -> 
          false

let f = fun x y z 
  -> 3

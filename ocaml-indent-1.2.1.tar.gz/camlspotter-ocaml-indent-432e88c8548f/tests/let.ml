let f x 
  = 1

let
  f 
    x 
  = 
  1

and 
  g
    y
  =
  2

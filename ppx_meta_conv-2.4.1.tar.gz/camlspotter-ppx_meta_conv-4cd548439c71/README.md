Meta_conv for ppx
==============================

`ppx_meta_conv` is a plugin/wrapper for `ppx_deriving` to provide data conversion between OCaml values and tree formed data structures such as JSON, Sexp, pseudo OCaml value code and so on.

`ppx_meta_conv` is a PPX port of `meta_conv` for CamlP4, which is a generalization of `type_conv`. The first objective of `meta_conv` and `ppx_meta_conv` is to provide an easy way to implement conversions of data formats as possible. If you get performance problems probably you should check other ppx based data converters specific to one data format. 

Typical usage of `ppx_meta_conv` is like `type ty = ... [@@deriving conv{xxx}]`.
`xxx` is called target, and `ppx_meta_conv` creates `xxx_of_ty`, `ty_of_xxx`
and `ty_of_xxx_exn` functions.  `ppx_meta_conv` itself knows nothing about
the target `xxx` except its name, and generate code which composes primitives
defined in module `Xxx_conv`.  The primitives of `Xxx_conv` must be given
externally. Currently `ppx_meta_conv_ocaml`, `ppx_meta_conv_tiny_json`
and `ppx_meta_conv_sexp` packages are provided.

Basic
==========

```
type 'a t = <definition> [@@deriving conv{name}]
```

Multiple targets
==================

```
type t = <definition> [@@deriving conv{ocaml; json}]
```

Only one direction
==================

```
(* Only defines ocaml_of_t. t_of_ocaml is skipped *)
type t = <definition> [@@deriving conv{ocaml_of}]
```

Inlined
==================

```
[%ocaml_of: type] (* type to Ocaml.t *)
```

```
[%of_ocaml: type] (* Ocaml.t to type, `Ok or `Error *)
```

```
[%of_ocaml_exn: type] (* Ocaml.t to type, failure is reported as an exceptin *)
```

Using special name
=====================

```
type 'a t = Zee                          (* The default name "Zee" is used *)
          | Foo [@conv.as foo]           (* "foo" *)
          | Bar [@conv.as "bar"]         (* "bar" *)
          | Boo [@conv.as {ocaml="boo"}] (* only for 'ocaml' target *)
          [@@deriving conv{name}]
```

```
type t = { x : int [@conv.as X] ;
           y : float [@conv.as {ocaml="Y"}] } 
         [@@deriving conv{name}]
```

Field for Leftovers
======================

`t mc_leftovers` is a special type. 

```
type 'a mc_leftovers = (string * 'a) list
type t = { x : int;
           y : float;
           rest : Ocaml.t mc_leftovers;
         [@@deriving conv{name}]
```

Ignore unknown fields
===========================

```
type t = {
    foo: int;
    bar: float;
  } [@conv.ignore_unknown_fields] (* t_of_ocaml does not fail even if the source contains fields other than foo and bar *)
    [@@deriving conv{ocaml}]
```

Optional field 
============================

`t mc_option` is a special type.

```
type t = { x : int;
           y : float mc_option  (* the source may have a field y of type float,
                                   or may not have it at all. *)
         } 
         [@@deriving conv{name}]
```

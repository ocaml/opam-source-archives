type 'a t = 
  | PCData of string
  | Element of (string * ((string * string) list) * ('a list))

let escape_attr_value s =
  let buf = Buffer.create (String.length s * 2) in
  String.iteri (fun _ c ->
    match c with
    | '"' -> Buffer.add_string buf "\\\""
    | '\\' -> Buffer.add_string buf "\\\\"
    | c -> Buffer.add_char buf c) s;
  Buffer.contents buf

let escape_pcdata s =
  let len = String.length s in
  let buf = Buffer.create (len * 2) in
  (* CR jfuruse: this is far from perfect *)
  String.iteri (fun i c ->
    match c with
    | '>' -> Buffer.add_string buf "&gt;"
    | '<' -> Buffer.add_string buf "&lt;"
    | '&' ->
	if i < len-1 && s.[i+1] = '#' then
	  Buffer.add_char buf '&'
	else
	  Buffer.add_string buf "&amp;"
    | '\'' -> Buffer.add_string buf "&apos;"
    | '"' -> Buffer.add_string buf "&quot;"
    | c -> Buffer.add_char buf c) s;
  Buffer.contents buf

open Format

let rec list (sep : (unit, formatter, unit) format)  f ppf = function
  | [] -> ()
  | [x] -> f ppf x
  | x::xs -> 
      fprintf ppf "@[%a@]%t%a" 
	f x
	(fun ppf -> fprintf ppf sep)
	(list sep f) xs

let rec format f ppf = function
  | PCData s -> Format.pp_print_string ppf @@ escape_pcdata s (* CR jfuruse: consecutive PCData's are simply printed without separators *)
  | Element (tag, [], []) ->
      fprintf ppf "@[<0><%s/>@]"
        tag 
  | Element (tag, attrs, []) ->
      fprintf ppf "@[<0><%s @[%a@]/>@]"
        tag 
        format_attrs attrs
  | Element (tag, [], xmls) ->
      fprintf ppf "@[<2><%s>@,%a@,</%s>@]"
        tag
        (list "@," f) xmls
        tag
  | Element (tag, attrs, xmls) ->
      fprintf ppf "@[<2><%s @[%a@]>@,%a@,</%s>@]"
        tag
        format_attrs attrs
        (list "@," f) xmls
        tag
and format_attrs ppf = list "@ " (fun ppf (k,v) -> fprintf ppf "%s=\"%s\"" k (escape_attr_value v)) ppf

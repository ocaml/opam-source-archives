open Printf
open Std_xml

(** The names of type and modules

    If you want to auto generate of conversion functions [conv(xxx)] 
    of your target data type,

    * Your target data must have a name [Xxx.t] (here [Json.t]).
      (You can put it in another module [Aaa.Bbb.Xxx.t], but the data type must
       be accessible by [Xxx.t]: you need to [open Aaa.Bbb].

    * You must write a convesion module named [Xxx_conv] (here [Json_conv], this file.),
      and make it accessible as [Xxx_conv]. (Same again, you can put the module inside
      another module, but then, you need [open]. 

*)

(** Basic requirement: [include Meta_conv.Coder.Make(...)]

   You must define a module with

   * The target type [target], here [Json.t]
   * [format], a printer for [target], useful for debugging
   * And the basic constructor and deconstructor modules of [target], 
     [Constr] and [Deconstr] respectively.

   and apply [Meta_conv.Coder.Make] to it, and include the result.
*)

module Make(Xml : sig
  type t
  val format : Format.formatter -> t -> unit
  val pcdata : string -> t
  val element : string -> (string * string) list -> t list -> t
  val deconstr : t -> t Std_xml.t
end) = struct

  include Meta_conv.Coder.Make(struct 
    open Xml
  
    type target = Xml.t  (** This is the target type! *)
  
    (** [format]: printer of [target] *)
    let format = Xml.format
  
    (** [Constr]: Constructors.
  
        This module implements how to construct a [target] value from other [target] values.
        It must have: 
  
          val tuple        : target list -> target
          val variant      : string -> target list -> target
          val poly_variant : string -> target list -> target
          val record       : (string * target) list -> target
          val object_      : (string * target) list -> target
  
        It is often the case that you do not really distinguish records and objects,
        and variants and polymorphic variants. In that case, you can write simply
        [let poly_variant = variant and object_ = record].
    *)
    module Constr = struct
      let tuple ts = element "elements" [] @@ List.map (fun t -> element "elem" [] [t]) ts
      let variant _tyname tag = function
        | [] -> element tag [] []
        | ts -> element tag [] ts
      let record _tyname tag_ts  = element "record" [] @@ List.map (fun (tag,t) -> element tag [] [t]) tag_ts
      let poly_variant = variant (* We use the same construction as variants *)
      let object_ = record (* We use the same construction as records *)
    end
  
    (** [Deconstr]: Deconstructors.
  
        This module implements how to deconstruct a [target] value to sub [target] values.
        It must have: 
  
          val tuple        : target -> target list
          val variant      : target -> string * target list
          val poly_variant : target -> string * target list
          val record       : target -> (string * target) list
          val object_      : target -> (string * target) list
  
        If deconstruction is impossible, the functions can raise exceptions. The exceptions
        are caught and result into decoding failure errors. For example, if [tuple] takes
        a target value which is not interpretable as a tuple, it should raise an exception.
  
        It is often the case that you do not really distinguish records and objects,
        and variants and polymorphic variants. In that case, you can write simply
        [let poly_variant = variant and object_ = record].
    *)
    module Deconstr = struct
    
      let tuple t = match deconstr t with
        | Element ("elements", _, es) -> 
            List.map (fun t -> match deconstr t with
              | Element ("elem", _, [t]) -> t
              | _ -> failwith "<elem>x</elem> expected for tuple element") es
        | _ -> 
            failwith "<elements> expected for tuple" 
    
      let variant _tyname t = match deconstr t with
        | Element (tag, _, ts) -> tag, ts
        | _ -> failwith "Element expected for variant"
    
      let record _tyname t = match deconstr t with
        | Element ("record", _, es) ->
            List.map (fun t -> match deconstr t with
              | Element (tag, _, [t]) -> tag, t
              | _ -> failwith "<x>y</x> for some x expected for record field") es
        | _ -> failwith "<record> expected for record"
    
      let poly_variant = variant
      let object_ = record
    end
  
  end)

  (** Auxiliary: encoders and decoders for primitive types: [xxx_of_<type>] and [<type>_of_xxx] 
  
      Conversion functions for derived types which are defined using 
      [type t = ... with conv(xxx)] are created by [pa_meta_conv] CamlP4 extension,
      but those for primitive types are not. You need to define them by yourself.
  
      Primitive types are types without definitinons. Popular primitive types are:
      int, int32, int64, nativeint, char, string, float, list, array, bool, lazy_t,
      unit, option and Hashtbl.t.
  
      You should define encoders and decoders for those types in [Xxx_conv] module.
      You do not need to define en/decoders of all the primitive types, but 
      of course Meta_conv cannot auto-generate coders of derived types whose definitions
      depend on primitive types without coders.
  
      The names of coders for a primitive type <type> is [xxx_of_<type>] and
      [<type>_of_xxx]. Here, we are defining things for [conv(json)], so 
      they are [json_of_<type>] and [<type>_of_json].
  *)
  
  (** Encoders for primitive types *)
  
  let xml_of_int n       = Xml.pcdata (string_of_int n)
  let xml_of_int32 n     = Xml.pcdata (Int32.to_string n)
  let xml_of_int64 n     = Xml.pcdata (Int64.to_string n)
  let xml_of_nativeint n = Xml.pcdata (Nativeint.to_string n)
  let xml_of_char c      = Xml.pcdata (String.make 1 c)
  let xml_of_string s    = Xml.pcdata s
  let xml_of_float n     = Xml.pcdata (Printf.sprintf "%.20G" n) (* CR jfuruse: not sure... *)
  let xml_of_list f xs   = Xml.element "elements" [] @@ List.map f xs
  let xml_of_array f xs  = Xml.element "elements" [] @@ List.map f (Array.to_list xs)
  let xml_of_bool = function
    | true -> Xml.element "true" [] []
    | false -> Xml.element "false" [] []
  let xml_of_lazy_t f v  = f (Lazy.force v)
  let xml_of_unit ()     = Xml.element "unit" [] []
  let xml_of_option f    = function
    | None -> Xml.element "none" [] []
    | Some v -> Xml.element "some" [] [f v]
    
  (** Decoders for primitive types 
  
      Usually decoders are harder to imlement compared to encoders.
      There is a module [Helper] available, which is created by the above
      [Meta_conv.Coder.Make(...)]. [Helper] provides some useful functions
      for decoders. See the module type [Types.S] to know about [Helper].
  
      Note that [<type>_of_xxx] must report the decoding errors using
      the Result monad (See [Meta_conv.Result]). You should not raise
      an exception inside a decoder, or, use [result] to wrap a function
      of type [decoder_exn]. (They are available via the above 
      [include Meta_conv.Coder.Make(...)]. See [Types.S] for details.)
  *)
  
  let failwithf fmt = kprintf (fun s -> raise (Failure s)) fmt

  let of_deconstr f = Helper.of_deconstr (fun t -> f (Xml.deconstr t))

  let string_of_xml = of_deconstr (function
    | PCData s -> s
    | _ -> failwith "string_of_xml: PCData expected")
  
  let char_of_xml = of_deconstr (function
    | PCData s when String.length s = 1 -> s.[0]
    | _ -> failwith "char_of_xml: a char expected")
  
  let int_check name _min _max conv = of_deconstr (function 
    | PCData n -> conv n
    | _ -> failwithf "%s_of_xml: PCData expected" name)
  
  let int_of_xml =
    int_check "int" (float min_int) (float max_int) int_of_string
  
  let int64_of_xml =
    let open Int64 in
    int_check "int64" (to_float min_int) (to_float max_int) Int64.of_string
        
  let int32_of_xml =
    let open Int32 in
    int_check "int32" (to_float min_int) (to_float max_int) Int32.of_string
        
  let nativeint_of_xml = 
    let open Nativeint in
    int_check "nativeint" (to_float min_int) (to_float max_int) Nativeint.of_string
        
  let float_of_xml = of_deconstr (function
    | PCData n -> float_of_string n
    | _ -> failwith "float_of_xml: PCData expected")
  
  let bool_of_xml = of_deconstr (function
    | Element ("true", _, []) -> true
    | Element ("false", _, []) -> false
    | _ -> failwith "bool_of_xml: <true/> or <false/> expected")
  
  let unit_of_xml = of_deconstr (function
    | Element ("unit", _, []) -> ()
    | _ -> failwith "unit_of_xml: <unit/> expected")
    
  let list_of_xml f = 
    Helper.list_of (fun t -> match Xml.deconstr t with
    | Element ("elements", _, xs) -> 
        begin try Some (List.map (fun t -> match Xml.deconstr t with Element("elem", _, [x]) -> x | _ -> raise Exit) xs) with _ -> None end
    | _ -> None) f
  
  let array_of_xml f = 
    Helper.array_of (fun t -> match Xml.deconstr t with
    | Element ("elements", _, xs) -> 
        begin try Some (List.map (fun t -> match Xml.deconstr t with Element("elem", _, [x]) -> x | _ -> raise Exit) xs) with _ -> None end
    | _ -> None) f
  
  let option_of_xml f = Helper.option_of (fun t -> match Xml.deconstr t with
      | Element("none", _, []) -> Some None
      | Element("some", _, [x]) -> Some (Some x)
      | _ -> None) f
  
  let lazy_t_of_xml d = Helper.lazy_t_of (fun e -> raise (Error e)) d
  
  (** Auxiliary: encoders and decoders of Meta_conv special types.
  
      Special types such as [mc_lazy_t] and [mc_fields] require their own special
      en/decoders. If you want to use those special types, you must define those
      coders.
   *)
  
  let xml_of_mc_lazy_t = Helper.of_mc_lazy_t
  let mc_lazy_t_of_xml = Helper.mc_lazy_t_of
  
  let xml_of_mc_fields enc xs = 
    Constr.record "mc_fields" (List.map (fun (name, a) -> (name, enc a)) xs)
  
  let mc_fields_of_xml dec = 
    Helper.mc_fields_of (fun t -> match Xml.deconstr t with
      | Element ("record", _, xs) -> 
          begin try
            Some (List.map (fun t -> match Xml.deconstr t with
              | Element (k, _, [v]) -> k,v
              | _ -> raise Exit) xs)
          with
          | Exit -> None
          end
      | _ -> None) dec
end

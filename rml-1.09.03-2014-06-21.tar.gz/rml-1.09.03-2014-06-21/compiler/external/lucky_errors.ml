(**********************************************************************)
(*                                                                    *)
(*                           ReactiveML                               *)
(*                    http://reactiveML.org                           *)
(*                    http://rml.inria.fr                             *)
(*                                                                    *)
(*                          Louis Mandel                              *)
(*                                                                    *)
(*  Copyright 2002, 2007 Louis Mandel.  All rights reserved.          *)
(*  This file is distributed under the terms of the Q Public License  *)
(*  version 1.0.                                                      *)
(*                                                                    *)
(*  ReactiveML has been done in the following labs:                   *)
(*  - theme SPI, Laboratoire d'Informatique de Paris 6 (2002-2005)    *)
(*  - Verimag, CNRS Grenoble (2005-2006)                              *)
(*  - projet Moscova, INRIA Rocquencourt (2006-2007)                  *)
(*                                                                    *)
(**********************************************************************)

(* file: lucky_errors.ml *)
(* created: 2005-03-22  *)
(* author: Louis Mandel *)

(* $Id$ *)

open Misc
open Parse_ast

(* Printing of error messages about Lucky import *)

let not_implemented_type ty =
  Format.fprintf !err_fmt
    "%aThis type cannot be used in a Lucky process."
    Location.print ty.pte_loc;
  raise Error

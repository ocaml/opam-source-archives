let x,y as z, w = ((1,2),3)     (* wrongly parsed as x,<y as z> *)

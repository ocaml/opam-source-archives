(* char stream from a file *)

module type S = sig
  include Stream_intf.S with type Elem.t = char
                        and  type Pos.t  = Position.File.t
                        and  type Attr.t = Sbuffer.buf

  include Sbuffer.X with type t := t
end

module Base = struct
  
  module Elem = Elem.Char
  module Pos  = Position.File
  
  module Attr = struct
    type t = Sbuffer.buf
    let position attr = Sbuffer.position_of_buf attr
  end
  
end

module NonBuffered = Stream.Make(Base)

include NonBuffered

include Sbuffer.Extend(struct
  include NonBuffered
  let create_attr buf = buf
  let buf st = attr st
end)


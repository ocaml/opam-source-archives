open Spotlib.Spot

module Stream = Sfile
type 'a t = Stream.t -> ('a * Stream.t, Stream.Pos.t * string (* error *)) Result.t
module Parser = Pbuffer.Make(Stream)

module type S = sig
  include Stream_intf.S with type Elem.t = char
                        and  type Pos.t = Position.File.t
                        and  type Attr.t = Sbuffer.buf
  include Sbuffer.X with type t := t
end

module Base = struct

  module Elem = Elem.Char     (* Stream elements *)
  module Pos = Position.File  (* Stream positions *)

  module Attr = struct
    (* Stream attributes *)
    type t = Sbuffer.buf (* Stream elements carry internal buffers *)
    let position attr = Sbuffer.position_of_buf attr (* How to obtain the position from attr *)
  end

end

module Str = Stream.Make(Base)
include Str

(* Extend Str with buffering *)
include Sbuffer.Extend(struct
  include Str
  let create_attr buf = buf (* How to create an attribute from a buffer *)
  let buf st = attr st (* How to obtain the buffer of a stream *)
end)

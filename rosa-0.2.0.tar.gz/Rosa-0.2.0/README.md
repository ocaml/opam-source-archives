# Rosa
String manipulation library 

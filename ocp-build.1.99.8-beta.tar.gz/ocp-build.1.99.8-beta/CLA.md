# Contributing to OCamlPro Free Software

In order to clarify the intellectual property license granted with
Contributions from any person or entity, OCamlPro SAS ("OCamlPro")
must have a Contributor License Agreement (CLA) on file that has been
signed (electronically) by each Contributor, indicating agreement to
the license terms below. This license is for your protection as a
Contributor as well as the protection of OCamlPro and its users; it
does not change your rights to use your own Contributions for any
other purpose.

* [Individual CLA](http://www.ocamlpro.com/files/CLA-OCamlPro-individual.txt) 
  You should fill the internal part and send it by email.
* [Corporate CLA](http://www.ocamlpro.com/files/CLA-OCamlPro-corporate.txt)
  You should print it, sign it and send us a scanned copy.

CLAs should be sent to contact@ocamlpro.com.

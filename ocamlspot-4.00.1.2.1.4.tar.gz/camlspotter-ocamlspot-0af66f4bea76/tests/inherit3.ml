class x = object
  inherit Inherit.c (* ? c *)
end


callbacks_file "test2cb.c"

let f () = ()

c_wrapper fcb for f : unit -> unit


module M = struct
  type enum = A | B 

  let enum_of_int = function 0 -> A | 1 -> B | _ -> failwith "Bad int in enum_of_int"
  let enum_to_int = function A -> 0 | B -> 1
end

let g x = x

open M

c_wrapper gcb for g : enum -> enum

c_code "
int f(int n, int m) { return n + m; }
"

ocaml_wrapper f : int -> int -> int = "f"

c_code "
value idt(value x) { return x; }
"

ocaml_wrapper idt : 'a mlval -> 'a mlval = "idt"

c_code "
typedef struct {
  double x;
  double y;
} complex_cell;

typedef complex_cell* complex;

complex malloc_complex(double x, double y) {
  complex c = (complex) malloc(sizeof(complex_cell));
  
  if (!c) exit(1);

  c->x = x;
  c->y = y;

  return(c);
}
"

type complex 

ocaml_wrapper c_malloc_complex : float -> float -> complex cval = "malloc_complex"

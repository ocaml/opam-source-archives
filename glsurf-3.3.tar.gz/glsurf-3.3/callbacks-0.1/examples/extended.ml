
type extended

c_code "
#include <mlvalues.h>
#include <alloc.h>
#include <stdio.h>
#include <stdlib.h>

#define Extended_wosize ((sizeof(long double) / sizeof(value)))

value add_extended(value x, value y) {
  CAMLparam2(x,y);
  CAMLlocal1(res);
  res = alloc_small(Extended_wosize, Abstract_tag);
   *(long double *) res = *(long double *) x + *(long double *) y;
  CAMLreturn(res);
}

value extended_of_int(value x) {
  CAMLparam1(x);
  CAMLlocal1(res);
  res = alloc_small(Extended_wosize, Abstract_tag);
   *(long double *) res = (long double) (Long_val(x));
  CAMLreturn(res);
}

value extended_of_string(value x) {
  CAMLparam1(x);
  CAMLlocal1(res);
  res = alloc_small(Extended_wosize, Abstract_tag);
  sscanf(String_val(x),\"%Le\",(long double *) res);
  CAMLreturn(res);
}

value string_of_extended(value x) {
  CAMLparam1(x);
  CAMLlocal1(res);
  char str[48];
  sprintf(str,\"%.22Le\",*(long double *)x);
  res = caml_copy_string(str);
  CAMLreturn(res);
}
"

ocaml_wrapper add_extended : extended mlval -> extended mlval -> extended mlval = "add_extended"

let ( +. ) = add_extended

ocaml_wrapper extended_of_int : int mlval -> extended mlval = "extended_of_int"

ocaml_wrapper extended_of_string : string mlval -> extended mlval = "extended_of_string"

ocaml_wrapper string_of_extended : extended mlval -> string mlval = "string_of_extended"


(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format

let print_vector vector =
  let dim = Array.length vector in

  print_string "[|";
  for i = 0 to dim - 1 do
    print_float vector.(i);
    if i < dim - 1 then print_string ";" else print_string "|]"
  done

let print_matrix mat =
  let dim = Array.length mat in

  print_string "[|";
  for i = 0 to dim - 1 do
    print_vector mat.(i);
    if i < dim - 1 then print_string ";" else print_string "|]"
  done

let vector_add a b =
  let size = Array.length a in
  assert (size = Array.length b);
  Array.init size (fun i -> a.(i) +. b.(i))

let vector_sub a b =
  let size = Array.length a in
  assert (size = Array.length b);
  Array.init size (fun i -> a.(i) -. b.(i))

let vector_madd a alpha b =
  let size = Array.length a in
  assert (size = Array.length b);
  Array.init size (fun i -> a.(i) +. alpha *. b.(i))

let set_vector_madd a alpha b r =
  let size = Array.length a in
  assert (size = Array.length b);
  Array.iteri (fun i _ -> r.(i) <- a.(i) +. alpha *. b.(i)) r

let vector_cl alpha a beta b =
  let size = Array.length a in
  assert (size = Array.length b);
  Array.init size (fun i -> alpha *. a.(i) +. beta *. b.(i))

let vector_msub a alpha b =
  let size = Array.length a in
  assert (size = Array.length b);
  Array.init size (fun i -> a.(i) -. alpha *. b.(i))

let mat_mat_product a b =
  let size1 = Array.length a in
  let size2 = Array.length a.(0) in
  assert (size2 = Array.length b);
  let size3 = Array.length b.(0) in
  let r = Array.make_matrix size1 size3 0.0 in
  for i = 0 to size1 - 1 do
    for j = 0 to size3 - 1 do
      for k = 0 to size2 - 1 do
	r.(i).(j) <- r.(i).(j) +. a.(i).(k) *. b.(k).(j)
      done
    done
  done;
  r

let tmat_mat_product a b =
  let size1 = Array.length a.(0) in
  let size2 = Array.length a in
  assert (size2 = Array.length b);
  let size3 = Array.length b.(0) in
  let r = Array.make_matrix size1 size3 0.0 in
  for i = 0 to size1 - 1 do
    for j = 0 to size3 - 1 do
      for k = 0 to size2 - 1 do
	r.(i).(j) <- r.(i).(j) +. a.(k).(i) *. b.(k).(j)
      done
    done
  done;
  r

let mat_tmat_product a b =
  let size1 = Array.length a in
  let size2 = Array.length a.(0) in
  assert (size2 = Array.length b.(0));
  let size3 = Array.length b in
  let r = Array.make_matrix size1 size3 0.0 in
  for i = 0 to size1 - 1 do
    for j = 0 to size3 - 1 do
      for k = 0 to size2 - 1 do
	r.(i).(j) <- r.(i).(j) +. a.(i).(k) *. b.(j).(k)
      done
    done
  done;
  r

let mat_vector_product a v =
  let size1 = Array.length a in
  let size2 = Array.length a.(0) in
  assert (size2 = Array.length v);

  Array.init size1 (fun i ->
    let r = ref 0.0 in
    for j = 0 to size2 - 1 do
      r := !r +. a.(i).(j) *. v.(j)
    done;
    !r)

let tmat_vector_product a v =
  let size1 = Array.length a.(0) in
  let size2 = Array.length a in
  assert (size2 = Array.length v);

  Array.init size1 (fun i ->
    let r = ref 0.0 in
    for j = 0 to size2 - 1 do
      r := !r +. a.(j).(i) *. v.(j)
    done;
    !r)

let vector_vector_product v1 v2 =
  let size1 = Array.length v1 in
  assert (size1 = Array.length v2);
  let r = ref 0.0 in
  for i= 0 to size1 - 1 do
    r := !r +. v1.(i) *. v2.(i)
  done;
  !r

let solve mat0 vector0 =
  let mat = Array.map Array.copy mat0 in
  let vector = Array.copy vector0 in
  let dim = Array.length vector in

  for i = 0 to dim - 2 do
    let pivot_i, pivot_val =
      let r = ref (-1, 0.0) in
      for i' = i to dim - 1 do
	let v = mat.(i').(i) in
	let (_,t) = !r in
	if abs_float v > abs_float t then r := (i', v)
      done;
      !r
    in
    if pivot_i < 0 then raise Not_found;
    for j = i to dim-1 do
      let v = mat.(pivot_i).(j) in
      mat.(pivot_i).(j) <- mat.(i).(j);
      mat.(i).(j) <- v
    done;
    let v = vector.(pivot_i) in
    vector.(pivot_i) <- vector.(i);
    vector.(i) <- v;

    for j = i+1 to dim-1 do
      let v = mat.(j).(i) in
      mat.(j).(i) <- 0.0;
      for k = i+1 to dim-1 do
	mat.(j).(k) <- mat.(j).(k) -. v *. mat.(i).(k) /. pivot_val
      done;
      vector.(j) <- vector.(j) -. v *. vector.(i) /. pivot_val
    done;
  done;

  let r = vector in

  for i = dim - 1 downto 0 do
    for j = i + 1 to dim - 1 do
      r.(i) <- r.(i) -. r.(j) *. mat.(i).(j)
    done;
    r.(i) <- r.(i) /. mat.(i).(i)
  done;
  r

let solve_seidel mat0 vector0 =
  let mat = Array.map Array.copy mat0 in
  let vector = Array.copy vector0 in
  let dim = Array.length vector in

  for i = 0 to dim - 2 do
    let pivot_i, pivot_val =
      let r = ref (-1, 0.0) in
      for i' = i to dim - 1 do
	let v = mat.(i').(i) in
	let (_,t) = !r in
	if abs_float v > abs_float t then r := (i', v)
      done;
      !r
    in
    if pivot_i < 0 then raise Not_found;
    for j = i to dim-1 do
      let v = mat.(pivot_i).(j) in
      mat.(pivot_i).(j) <- mat.(i).(j);
      mat.(i).(j) <- v
    done;
    let v = vector.(pivot_i) in
    vector.(pivot_i) <- vector.(i);
    vector.(i) <- v;

    for j = i+1 to dim-1 do
      let v = mat.(j).(i) in
      mat.(j).(i) <- 0.0;
      for k = i+1 to dim-1 do
	mat.(j).(k) <- mat.(j).(k) -. v *. mat.(i).(k) /. pivot_val
      done;
      vector.(j) <- vector.(j) -. v *. vector.(i) /. pivot_val
    done;
  done;

  let r = vector in

  for i = dim - 1 downto 0 do
    for j = i + 1 to dim - 1 do
      r.(i) <- r.(i) -. r.(j) *. mat.(i).(j)
    done;
    r.(i) <- r.(i) /. mat.(i).(i)
  done;

  let residual = vector_sub (mat_vector_product mat0 r) vector0 in
  let n2 = ref (vector_vector_product residual residual) in
(*
  let nv0 = sqrt (vector_vector_product vector0 vector0) in
  print_string "res: "; print_float (!n2 /. nv0);
  print_flush ();
*)
  begin try while true do
    for i = 0 to dim-1 do
      let denom = mat0.(i).(i) in
      r.(i) <- vector0.(i) /. denom;
      for j = 0 to dim-1 do
	if i <> j then
	  r.(i) <-  r.(i) -. r.(j) *. mat0.(i).(j) /. denom
	else ()
      done
    done;
    let residual = vector_sub (mat_vector_product mat0 r) vector0 in
    let r2 = vector_vector_product residual residual in
    if not (r2 < !n2) then raise Exit;
    n2 := r2;
  done with Exit -> ()
  end;
(*
  print_string " res: "; print_float (!n2 /. nv0);
  print_newline ();
*)
  r

let solve_gc mat b =
  let dim = Array.length b in
  let x = Array.make dim 0.0 in
  let h = Array.map (fun x -> -. x) b in
  let g = Array.copy h in
  try for k = 1 to dim do
    let ah = mat_vector_product mat h in
    let alpha = -. vector_vector_product h g /. vector_vector_product h ah in
    set_vector_madd x alpha h x;
    let g = vector_sub (mat_vector_product mat x) b  in
    let beta = -. vector_vector_product g ah /. vector_vector_product h ah in
    set_vector_madd g beta h h;
  done;
  x
  with Exit -> x

let solve_global mat0 vector0 =
  let mat = Array.map Array.copy mat0 in
  let vector = Array.copy vector0 in
  let dim = Array.length vector in
  let perm = Array.make dim (dim - 1) in

  for i = 0 to dim - 2 do
    let pivot_i, pivot_j, pivot_val =
      let r = ref (-1, -1, 0.0) in
      for i' = i to dim - 1 do
	for j = i to dim - 1 do
	  let v = mat.(i').(j) in
	  let (_,_,t) = !r in
	  if abs_float v > abs_float t then r := (i',j, v)
	done;
      done;
      !r
    in
    if pivot_i < 0 then raise Not_found;
    perm.(i) <- pivot_j;
    for i' = 0 to dim-1 do
      let v = mat.(i').(pivot_j) in
      mat.(i').(pivot_j) <- mat.(i').(i);
      mat.(i').(i) <- v
    done;
    for j = i to dim-1 do
      let v = mat.(pivot_i).(j) in
      mat.(pivot_i).(j) <- mat.(i).(j);
      mat.(i).(j) <- v
    done;
    let v = vector.(pivot_i) in
    vector.(pivot_i) <- vector.(i);
    vector.(i) <- v;

    for j = i+1 to dim-1 do
      let v = mat.(j).(i) in
      mat.(j).(i) <- 0.0;
      for k = i+1 to dim-1 do
	mat.(j).(k) <- mat.(j).(k) -. v *. mat.(i).(k) /. pivot_val
      done;
      vector.(j) <- vector.(j) -. v *. vector.(i) /. pivot_val
    done;
  done;

  let r = vector in

  for i = dim - 1 downto 0 do
    for j = i + 1 to dim - 1 do
      r.(i) <- r.(i) -. r.(j) *. mat.(i).(j)
    done;
    r.(i) <- r.(i) /. mat.(i).(i)
  done;
  for i = dim - 2 downto 0 do
    let v = r.(perm.(i)) in
    r.(perm.(i)) <- r.(i);
    r.(i) <- v
  done;

  r

let trace mat =
  let dim = Array.length mat in
  let r = ref 0.0 in
  for i = 0 to dim - 1 do
    r := !r +. mat.(i).(i)
  done;
  !r

let determinant mat  =
  let mat = Array.map Array.copy mat in
  let dim = Array.length mat in
  let det = ref 1.0 in

  for i = 0 to dim - 2 do
    let pivot, pivot_val =
      let r = ref (-1, 0.0) in
      for j = i to dim - 1 do
	let v = mat.(j).(i) in
	if abs_float v > abs_float (snd !r) then r := (j, v)
      done;
      !r
    in
    if pivot < 0 then raise Not_found;
    if pivot <> i then begin
      for j = i to dim-1 do
	let v = mat.(pivot).(j) in
	mat.(pivot).(j) <- mat.(i).(j);
	mat.(i).(j) <- v
      done;
      det := -. !det *. pivot_val;
    end else
      det := !det *. pivot_val;
    for j = i+1 to dim-1 do
      let v = mat.(j).(i) in
      mat.(j).(i) <- 0.0;
      for k = i+1 to dim-1 do
	mat.(j).(k) <- mat.(j).(k) -. v *. mat.(i).(k) /. pivot_val
      done;
    done;

  done;
  det := !det *. mat.(dim-1).(dim-1);
  !det

let tsolve mat vector =
  let vector = tmat_vector_product mat vector in
  let mat = tmat_mat_product mat mat in
  solve mat vector

let normalize_vector v =
  let n = sqrt(vector_vector_product v v) in
  for i = 0 to Array.length v - 1 do
    v.(i) <- v.(i) /. n
  done

let tvector_vector_product v v' =
  Array.init (Array.length v) (fun i ->
    Array.init (Array.length v') (fun j ->
      v.(i) *. v'.(j)))

let unit_solve mat =
  let d1 = Array.length mat in
  let d2 = Array.length mat.(0) in
  assert(d2 = d1 + 1);
  let mat' = Array.init d1 (fun i -> Array.init d1 (fun j ->
    mat.(i).(j+1))) in
  let v' = Array.init d1 (fun i -> -. mat.(i).(0)) in
  let d = solve mat' v' in
  let n = sqrt(vector_vector_product d d +. 1.0) in
  let r = Array.init d2 (fun i ->
    (if i = 0 then 1.0 else d.(i-1)) /. n) in
  r

let inverse mat =
  let dim = Array.length mat in
  assert(dim = Array.length mat.(0));
  let result = Array.init dim (fun _ -> Array.make dim 0.0) in
  for i = 0 to dim - 1 do
    let v = Array.init dim (fun k ->  if k = i then 1.0 else 0.0) in
    let w = solve mat v in
    Array.iteri (fun j x -> result.(j).(i) <- x) w
  done;
  result

(* test *)

(*

let mat = [|
  [| 1.0; 2.0; 1.0; 0.0 |];
  [| 0.0; 1.0; 2.0; 1.0 |];
  [| 1.0; 0.0; 1.0; 2.0 |];
  [| 1.0; 1.0; 0.0;1.0 |]
|]

let vec = [| 1.0; 2.0; 3.0; 4.0|]

let res = solve mat vec

let imat = inverse mat

let id = mat_mat_product mat imat
let _ =
  print_vector res;
  print_newline ();
  print_vector (mat_vector_product mat res);
  print_newline ();
  print_matrix imat;
  print_newline ();
  print_matrix id;
  print_newline ()

*)

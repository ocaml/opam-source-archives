(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Vect3
open Function
open Glarrays

type compute = (vector -> float) * (vector -> vector)  * (vector -> vector)

module type Computing_parameter =
  sig
    val compute_size : float
    val compute_origin : point
    val max_angle : float
    val adjust_angle : float
    val out_max_angle : float
    val min_size : float
    val min_depth : int
    val split_cond : (float * point * vector) list
      -> (float * point * vector) list -> bool
    val keep_split_cond : (float * point * vector) list
      -> (point * vector) list -> bool
    val max_division_diff : int
    val adjust_factor : float
    val adjust_try_newton : bool
    val nb_random_points : int
    val flip : bool
    val treatment : compute -> vector * vector * vector -> unit
  end


type surface = {
    poly : Expr.elem;
    hessian : (point -> vector -> vector);
    hessian_mat : (point -> vector);
    ihessian : float -> float -> float -> float -> float -> float ->
      (float * float) * (float * float) * (float * float) *
	(float * float) * (float * float) * (float * float);
    third : (point -> vector -> float array array);
    grad : (point -> vector);
    eval : (point -> float);
    newton : float -> float -> point -> point;
    handle : (handle * string) option;
    next_eq : surface option;
    ts : Glarrays.surface option;
    es : Glarrays.curve option;
    ps : Glarrays.points option;
    text : (point * string) list;
    mutable front_diffuse : vector4;
    mutable back_diffuse : vector4;
    mutable front_ambient : vector4;
    mutable back_ambient  : vector4;
    mutable front_shininess :   float;
    mutable back_shininess :   float;
    mutable front_specular  :   vector4;
    mutable back_specular  :   vector4;
    mutable transparent : bool;
    mutable line_width : float;
    mutable line_color  :   vector4;
    mutable text_color  :   vector4;
    mutable point_size : float;
    mutable point_color  :   vector4;
    pov_surface_texture : string;
    pov_line_texture : string;
    pov_point_texture : string;
    pov_poly : bool;
    pov_isosurface : bool;
    pov_grad_coef : float;
    sorigin : point;
    ssize : float;
    auto_hide : bool
  }

type light_parameters = {
    light_position : vector4;
    light_diffuse : vector4;
    light_ambient : vector4;
    light_specular : vector4;
  }

type gl_parameters = {
    origin : point;
    size : float;
  }

type draw_parameters = {
    lmodel_ambient  :   vector4;
    lmodel_twoside  :   bool;
    background  :   vector3;
    fog : [`fastest|`nicest|`dont_care|`off];
    perspective_correction : [`fastest|`nicest|`dont_care|`off];
    line_smooth : [`fastest|`nicest|`dont_care|`off];
    point_smooth : [`fastest|`nicest|`dont_care|`off];
    polygon_smooth : [`fastest|`nicest|`dont_care|`off];
    smooth_shade : bool;
  }

type pov_parameters = {
    pov_preambule : string option;
    pov_pixels : int;
    pov_aliasing : float;
    pov_import_gl_light : bool
  }

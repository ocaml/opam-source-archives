open Format
open Input_util
open Algebra
open Vector


(* Signature of light matrix. 
   Provide the minimum operation to implement iterative solver. *)
(* This is a subtype of Set and Mapping *)

module type Light_Matrix =
sig 
  include Set

  type scalar
  type argument
  type result

  (* direct acces to the number of columns and lines *)
  val columns : int  (* Domain.dim *)
  val lines : int    (* Image.dim  *)

  val apply : elem -> argument -> result

  (* product v * A = tranpose(A) * v *)

  val tapply : result -> elem -> argument

  (* universal creation : to use write a code like

     let init f =
       ...
       f i j x (* called if x is at position (i,j) for all non zero element *)
               (* i is the column number and j is the line number *)
       ...
     in
     let m = create init
  *) 
  val create : ((int -> int -> scalar -> unit) -> unit) -> elem 

  val copy : elem -> elem (* copy in an other matrix *)
end

(* Signature of matrix. 
   Provide everething but product (this is only for square matrix !). *)

module type Matrix =
  sig
    include Light_Matrix

    module D : Dim

    val dim : int
    val get : elem -> int -> int -> scalar
    val put : elem -> int -> int -> scalar -> unit
    val vget : elem -> int -> scalar
    val vput : elem -> int -> scalar -> unit

    val sub : elem -> elem -> unit (* substraction: m1 = m1 - m2 *)
    val add : elem -> elem -> unit (* sum: m1 = m1 + m2 *)
    val mul_scal : scalar -> elem -> unit (* m1 = a * m1 *)

    val (++) : elem -> elem -> elem (* sum *)
    val (--) : elem -> elem -> elem (* substraction *)
    val (@)  : scalar -> elem -> elem (* multiplication by a scalar *)

    val vcreate : ((int -> scalar -> unit) -> unit) -> elem 

  end

(* square matrix: this time we have a product ! *)

module type Square_Matrix =
  sig
    include Matrix (* with module Domain = Image, it is a pity we can not
                      write this in Ocaml ! *) 

    val ( ** ) : elem -> elem -> elem
    val one : elem
    val t_of_int : int -> elem
  end 

(* Product of two matrices. It is not efficient at all on sparse matrix.
   One could do much better by adding some function like iter_line *)

module Product =
  functor (R : Ring) ->
  functor (ML : Matrix with type scalar = R.elem)  ->
  functor (MR : Matrix with type scalar = R.elem
                       and  type argument = ML.result) ->
  functor (M  : Matrix with type scalar = R.elem
                       and  type argument = MR.argument
                       and  type result = ML.result) ->
  struct
    let ( ** ) m1 m2 =
      assert (ML.columns = MR.lines);
      assert (MR.columns = M.columns);
      assert (ML.lines = M.lines);
      let init fn = 
	for i = 0 to ML.lines-1 do
 	  for j = 0 to MR.columns-1 do
	    let a = ref R.zero in
	      for k = 0 to MR.lines-1 do
		Printf.printf "i: %d, k: %d, j: %d" i j k;
		print_newline ();
	        a := R.(++) (R.( ** ) (ML.get m1 k i) (MR.get m2 j k)) !a
	      done;
	      if not (R.(==) !a R.zero) then fn j i !a 
	  done
	done
      in M.create init
    
  end

module Transpose =
  functor (R : Ring) ->
  functor (M : Matrix with type scalar = R.elem)  ->
  functor (MT  : Matrix with type scalar = R.elem
                       and  type argument = M.result
                       and  type result = M.argument) ->
  struct
    let transpose m  =
      let init fn = 
	for i = 0 to M.lines-1 do
 	  for j = 0 to M.columns-1 do
	    fn i j (M.get m j i)
	  done
	done
      in 
      MT.create init
    
  end


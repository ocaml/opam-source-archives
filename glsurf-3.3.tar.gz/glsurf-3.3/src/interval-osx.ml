(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Algebra
open Expression
open Vect3
open Function
open Parameters
open Dirty
open Expr


let rec eval_power exp puis = 
  (* power function in field (time log_2(n))*)
  match puis with
    0 -> 1.0
  | 1 -> exp
  | _ when puis < 0 -> 1.0 /. (eval_power exp (-puis))
  | _ when puis mod 2 = 0 ->
      let r = eval_power exp (puis / 2) in
      r *. r
  | _ -> 
      let r = eval_power exp ((puis - 1) / 2) in
      exp *. (r *. r) 

let bound_eval expr v = 
  let rec fn = function
      Var name -> 
	(try 
	  List.assoc name v 
	with Not_found -> 
	  failwith ("Unbound variable: "^name))
    | Cst n -> n, n
    | Add (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
        x +. x',  y +. y'
    | Sub (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
	x -. y',  y -. x'
    | Mul (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
	let a = x *. x' and b = x *. y' 
	and c = y *. x' and d = y *. y' in
	min (min a b) (min c d), max (max a b) (max c d)
    | Div (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
	if x' *. y' <= 0.0 then
	  failwith "Div by zero in bound_eval"
	else
	let a = x /. x' and b = x /. y' 
	and c = y /. x' and d = y /. y' in
	min (min a b) (min c d), max (max a b) (max c d)
    | Pow (e,deg) ->  
	if deg = 0 then 1.0, 1.0 else
	let x,y = fn e in
	let a = eval_power x deg and b = eval_power y deg in
	if x *. y <= 0.0 && deg mod 2 = 0 then 0.0, max a b
	else min a b, max a b
    | Tra (trindex, e) -> 
	failwith "Tra not supported in bound_eval"
    | Tra2 (trindex, e, e') -> 
	failwith "Tra2 not supported in bound_eval"
  in
  let (x,y as r) = fn expr in
(*
  Expr.print expr;
  print_newline ();
  List.iter (fun v, (x, y) ->
    Printf.printf "%f <= %s <= %f ; " x v y) v;
  print_newline ();
  Printf.printf "gives: [%f, %f]" x y;
  print_newline ();
*)
  r
    

let is_non_zero expr v =
  let x, y = bound_eval expr v in
  x *. y > 0.0

let is_positive expr v =
  let x, _ = bound_eval expr v in
  x > 0.0

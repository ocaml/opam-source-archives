
/*@ allocates \result;
  @ ensures \fresh(\result,size) && \valid(\result+(0..size-1));
  @*/
char *malloc(unsigned int size);

typedef struct Fresh { int f; } *fresh;

/*@ allocates \result;
  @ ensures \fresh(\result,sizeof(struct Fresh)) && \valid(\result);
  @*/
fresh create() {
  fresh f = (fresh)malloc(sizeof(struct Fresh));
  return f;
}

/*@ requires \valid(f1);
  @*/
void test (fresh f1) {
  fresh f2 = create ();
  //@ assert f1 != f2;
  //@ assert \valid(f2);
  // assert \false;
}


/*
Local Variables:
compile-command: "make fresh.why3ml"
End:
*/



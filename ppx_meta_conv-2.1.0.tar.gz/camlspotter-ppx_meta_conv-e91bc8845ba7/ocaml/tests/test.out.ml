open Meta_conv.Open
  
open Ocaml_conv
  
module Test1 =
  struct
    type t = | Foo | Bar of int * string
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t =
      let __tyname = "t"
      in
        function
        | Foo -> Ocaml_conv.Constr.variant __tyname "Foo" []
        | Bar (__x1, __x2) ->
            Ocaml_conv.Constr.variant __tyname "Bar"
              [ ocaml_of_int __x1; ocaml_of_string __x2 ]
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t"
        in
          match Ocaml_conv.DeconstrDecoder.variant __name ~trace: __t __v
          with
          | `Ok v ->
              (match v with
               | ("Foo", l) ->
                   let __t = (`Field "Foo") :: (`Node __v) :: __t
                   in
                     (match l with
                      | [] -> `Ok Foo
                      | _ ->
                          Meta_conv.Internal.variant_arity_error __name "Foo"
                            0 (List.length l) ~trace: __t __v)
               | ("Bar", l) ->
                   let __t = (`Field "Bar") :: (`Node __v) :: __t
                   in
                     (match l with
                      | [ __x1; __x2 ] ->
                          (try
                             let __x1 =
                               Ocaml_conv.from_Ok
                                 (int_of_ocaml ~trace: ((`Pos 0) :: __t) __x1) in
                             let __x2 =
                               Ocaml_conv.from_Ok
                                 (string_of_ocaml ~trace: ((`Pos 1) :: __t)
                                    __x2)
                             in `Ok (Bar (__x1, __x2))
                           with | Ocaml_conv.Error e -> `Error e)
                      | _ ->
                          Meta_conv.Internal.variant_arity_error __name "Bar"
                            2 (List.length l) ~trace: __t __v)
               | (name, _l) ->
                   Meta_conv.Internal.variant_unknown_tag_error __name name
                     ~trace: __t __v)
          | `Error e -> `Error e
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
    let () =
      let x = Bar (0, "hello")
      in assert ((t_of_ocaml (ocaml_of_t x)) = (`Ok x))
      
  end
  
module Test2 =
  struct
    type t = { foo : int; bar : float option }
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t =
      fun __v ->
        Ocaml_conv.Constr.record "t"
          (List.flatten
             [ [ ("foo", (ocaml_of_int __v.foo)) ];
               [ ("bar", (ocaml_of_option ocaml_of_float __v.bar)) ] ])
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t" in
        let primary_labels = [ "foo"; "bar" ]
        in
          match Ocaml_conv.DeconstrDecoder.record __name ~trace: __t __v with
          | `Error e -> `Error e
          | `Ok fields ->
              let (primary_fields, secondary_fields) =
                Meta_conv.Internal.filter_fields primary_labels fields
              in
                (try
                   let foo =
                     Meta_conv.Internal.field_assoc_exn __name "foo"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t) __v
                   and bar =
                     Meta_conv.Internal.field_assoc_exn __name "bar"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn (option_of_ocaml float_of_ocaml))
                       ?trace: (Some __t) __v in
                   let res = { foo = foo; bar = bar; }
                   in
                     if secondary_fields <> []
                     then
                       `Error
                         ((Meta_conv.Error.Unknown_fields (__name,
                             (List.map fst secondary_fields), (Obj.repr res))),
                         __v, __t)
                     else `Ok res
                 with | Ocaml_conv.Error e -> `Error e)
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
    let () =
      let x = { foo = 3; bar = Some 1.2; }
      in assert ((t_of_ocaml (ocaml_of_t x)) = (`Ok x))
      
  end
  
module Test3 =
  struct
    open Test2
      
    type t = Test2.t
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t = fun __v -> Test2.ocaml_of_t __v
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v -> Test2.t_of_ocaml ~trace: __t __v
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
    let () =
      let x = { foo = 3; bar = Some 1.2; }
      in assert ((t_of_ocaml (ocaml_of_t x)) = (`Ok x))
      
  end
  
module Test4 =
  struct
    type t = | Foo | Bar of int * string
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t =
      let __tyname = "t"
      in
        function
        | Foo -> Ocaml_conv.Constr.variant __tyname "foo" []
        | Bar (__x1, __x2) ->
            Ocaml_conv.Constr.variant __tyname "bar"
              [ ocaml_of_int __x1; ocaml_of_string __x2 ]
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t"
        in
          match Ocaml_conv.DeconstrDecoder.variant __name ~trace: __t __v
          with
          | `Ok v ->
              (match v with
               | ("foo", l) ->
                   let __t = (`Field "foo") :: (`Node __v) :: __t
                   in
                     (match l with
                      | [] -> `Ok Foo
                      | _ ->
                          Meta_conv.Internal.variant_arity_error __name "foo"
                            0 (List.length l) ~trace: __t __v)
               | ("bar", l) ->
                   let __t = (`Field "bar") :: (`Node __v) :: __t
                   in
                     (match l with
                      | [ __x1; __x2 ] ->
                          (try
                             let __x1 =
                               Ocaml_conv.from_Ok
                                 (int_of_ocaml ~trace: ((`Pos 0) :: __t) __x1) in
                             let __x2 =
                               Ocaml_conv.from_Ok
                                 (string_of_ocaml ~trace: ((`Pos 1) :: __t)
                                    __x2)
                             in `Ok (Bar (__x1, __x2))
                           with | Ocaml_conv.Error e -> `Error e)
                      | _ ->
                          Meta_conv.Internal.variant_arity_error __name "bar"
                            2 (List.length l) ~trace: __t __v)
               | (name, _l) ->
                   Meta_conv.Internal.variant_unknown_tag_error __name name
                     ~trace: __t __v)
          | `Error e -> `Error e
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
    let () =
      let x = Bar (0, "hello")
      in assert ((t_of_ocaml (ocaml_of_t x)) = (`Ok x))
      
  end
  
module Test5 =
  struct
    type t = { x : int; y : float }
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t =
      fun __v ->
        Ocaml_conv.Constr.record "t"
          (List.flatten
             [ [ ("x", (ocaml_of_int __v.x)) ];
               [ ("y", (ocaml_of_float __v.y)) ] ])
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t" in
        let primary_labels = [ "x"; "y" ]
        in
          match Ocaml_conv.DeconstrDecoder.record __name ~trace: __t __v with
          | `Error e -> `Error e
          | `Ok fields ->
              let (primary_fields, secondary_fields) =
                Meta_conv.Internal.filter_fields primary_labels fields
              in
                (try
                   let x =
                     Meta_conv.Internal.field_assoc_exn __name "x"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t) __v
                   and y =
                     Meta_conv.Internal.field_assoc_exn __name "y"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn float_of_ocaml) ?trace: (Some __t) __v in
                   let res = { x = x; y = y; } in
                   let _ = secondary_fields in `Ok res
                 with | Ocaml_conv.Error e -> `Error e)
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
    type t' = { x' : int; y' : float; z' : unit }
    
    let _ = fun (_ : t') -> ()
      
    let ocaml_of_t' : t' -> Ocaml.t =
      fun __v ->
        Ocaml_conv.Constr.record "t'"
          (List.flatten
             [ [ ("x", (ocaml_of_int __v.x')) ];
               [ ("y", (ocaml_of_float __v.y')) ];
               [ ("z", (ocaml_of_unit __v.z')) ] ])
      
    let _ = ocaml_of_t'
      
    let t'_of_ocaml : (t', Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t'" in
        let primary_labels = [ "x"; "y"; "z" ]
        in
          match Ocaml_conv.DeconstrDecoder.record __name ~trace: __t __v with
          | `Error e -> `Error e
          | `Ok fields ->
              let (primary_fields, secondary_fields) =
                Meta_conv.Internal.filter_fields primary_labels fields
              in
                (try
                   let x' =
                     Meta_conv.Internal.field_assoc_exn __name "x"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t) __v
                   and y' =
                     Meta_conv.Internal.field_assoc_exn __name "y"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn float_of_ocaml) ?trace: (Some __t) __v
                   and z' =
                     Meta_conv.Internal.field_assoc_exn __name "z"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn unit_of_ocaml) ?trace: (Some __t) __v in
                   let res = { x' = x'; y' = y'; z' = z'; }
                   in
                     if secondary_fields <> []
                     then
                       `Error
                         ((Meta_conv.Error.Unknown_fields (__name,
                             (List.map fst secondary_fields), (Obj.repr res))),
                         __v, __t)
                     else `Ok res
                 with | Ocaml_conv.Error e -> `Error e)
      
    let _ = t'_of_ocaml
      
    let t'_of_ocaml_exn : (t', Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t'_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t'_of_ocaml_exn
      
    let () =
      let r' = { x' = 1; y' = 1.0; z' = (); }
      in assert ((t_of_ocaml (ocaml_of_t' r')) = (`Ok { x = 1; y = 1.0; }))
      
  end
  
module Test6 =
  struct
    type t = { x : int; y : float; rest : Ocaml.t mc_leftovers }
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t =
      fun __v ->
        Ocaml_conv.Constr.record "t"
          (List.flatten
             [ [ ("x", (ocaml_of_int __v.x)) ];
               [ ("y", (ocaml_of_float __v.y)) ]; __v.rest ])
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t" in
        let primary_labels = [ "x"; "y" ]
        in
          match Ocaml_conv.DeconstrDecoder.record __name ~trace: __t __v with
          | `Error e -> `Error e
          | `Ok fields ->
              let (primary_fields, secondary_fields) =
                Meta_conv.Internal.filter_fields primary_labels fields
              in
                (try
                   let x =
                     Meta_conv.Internal.field_assoc_exn __name "x"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t) __v
                   and y =
                     Meta_conv.Internal.field_assoc_exn __name "y"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn float_of_ocaml) ?trace: (Some __t) __v in
                   let (rest, secondary_fields) = (secondary_fields, []) in
                   let res = { x = x; y = y; rest = rest; }
                   in
                     if secondary_fields <> []
                     then
                       `Error
                         ((Meta_conv.Error.Unknown_fields (__name,
                             (List.map fst secondary_fields), (Obj.repr res))),
                         __v, __t)
                     else `Ok res
                 with | Ocaml_conv.Error e -> `Error e)
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
    type t' = { x' : int; y' : float; z' : unit }
    
    let _ = fun (_ : t') -> ()
      
    let ocaml_of_t' : t' -> Ocaml.t =
      fun __v ->
        Ocaml_conv.Constr.record "t'"
          (List.flatten
             [ [ ("x", (ocaml_of_int __v.x')) ];
               [ ("y", (ocaml_of_float __v.y')) ];
               [ ("z", (ocaml_of_unit __v.z')) ] ])
      
    let _ = ocaml_of_t'
      
    let t'_of_ocaml : (t', Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t'" in
        let primary_labels = [ "x"; "y"; "z" ]
        in
          match Ocaml_conv.DeconstrDecoder.record __name ~trace: __t __v with
          | `Error e -> `Error e
          | `Ok fields ->
              let (primary_fields, secondary_fields) =
                Meta_conv.Internal.filter_fields primary_labels fields
              in
                (try
                   let x' =
                     Meta_conv.Internal.field_assoc_exn __name "x"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t) __v
                   and y' =
                     Meta_conv.Internal.field_assoc_exn __name "y"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn float_of_ocaml) ?trace: (Some __t) __v
                   and z' =
                     Meta_conv.Internal.field_assoc_exn __name "z"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn unit_of_ocaml) ?trace: (Some __t) __v in
                   let res = { x' = x'; y' = y'; z' = z'; }
                   in
                     if secondary_fields <> []
                     then
                       `Error
                         ((Meta_conv.Error.Unknown_fields (__name,
                             (List.map fst secondary_fields), (Obj.repr res))),
                         __v, __t)
                     else `Ok res
                 with | Ocaml_conv.Error e -> `Error e)
      
    let _ = t'_of_ocaml
      
    let t'_of_ocaml_exn : (t', Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t'_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t'_of_ocaml_exn
      
    let format_t' = Ocaml.format_with ocaml_of_t'
      
    let () =
      let r' = { x' = 1; y' = 1.0; z' = (); }
      in
        (assert
           ((t_of_ocaml (ocaml_of_t' r')) =
              (`Ok { x = 1; y = 1.0; rest = [ ("z", Ocaml.Unit) ]; }));
         assert
           ((ocaml_of_t
               (match t_of_ocaml (ocaml_of_t' r') with
                | `Ok v -> v
                | _ -> assert false))
              = (ocaml_of_t' r'));
         Format.eprintf "r' = %a@." format_t' r')
      
  end
  
module Test7 =
  struct
    type t = { x : int; y : float; rest : Ocaml.t mc_leftovers }
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t =
      fun __v ->
        Ocaml_conv.Constr.record "t"
          (List.flatten
             [ [ ("x", (ocaml_of_int __v.x)) ];
               [ ("y", (ocaml_of_float __v.y)) ]; __v.rest ])
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t" in
        let primary_labels = [ "x"; "y" ]
        in
          match Ocaml_conv.DeconstrDecoder.record __name ~trace: __t __v with
          | `Error e -> `Error e
          | `Ok fields ->
              let (primary_fields, secondary_fields) =
                Meta_conv.Internal.filter_fields primary_labels fields
              in
                (try
                   let x =
                     Meta_conv.Internal.field_assoc_exn __name "x"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t) __v
                   and y =
                     Meta_conv.Internal.field_assoc_exn __name "y"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn float_of_ocaml) ?trace: (Some __t) __v in
                   let (rest, secondary_fields) = (secondary_fields, []) in
                   let res = { x = x; y = y; rest = rest; }
                   in
                     if secondary_fields <> []
                     then
                       `Error
                         ((Meta_conv.Error.Unknown_fields (__name,
                             (List.map fst secondary_fields), (Obj.repr res))),
                         __v, __t)
                     else `Ok res
                 with | Ocaml_conv.Error e -> `Error e)
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
    type t' = { x' : int; y' : float; z' : unit }
    
    let _ = fun (_ : t') -> ()
      
    let ocaml_of_t' : t' -> Ocaml.t =
      fun __v ->
        Ocaml_conv.Constr.record "t'"
          (List.flatten
             [ [ ("x", (ocaml_of_int __v.x')) ];
               [ ("y", (ocaml_of_float __v.y')) ];
               [ ("z", (ocaml_of_unit __v.z')) ] ])
      
    let _ = ocaml_of_t'
      
    let t'_of_ocaml : (t', Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        let __name = "t'" in
        let primary_labels = [ "x"; "y"; "z" ]
        in
          match Ocaml_conv.DeconstrDecoder.record __name ~trace: __t __v with
          | `Error e -> `Error e
          | `Ok fields ->
              let (primary_fields, secondary_fields) =
                Meta_conv.Internal.filter_fields primary_labels fields
              in
                (try
                   let x' =
                     Meta_conv.Internal.field_assoc_exn __name "x"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t) __v
                   and y' =
                     Meta_conv.Internal.field_assoc_exn __name "y"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn float_of_ocaml) ?trace: (Some __t) __v
                   and z' =
                     Meta_conv.Internal.field_assoc_exn __name "z"
                       primary_fields Ocaml_conv.throw
                       (Ocaml_conv.exn unit_of_ocaml) ?trace: (Some __t) __v in
                   let res = { x' = x'; y' = y'; z' = z'; }
                   in
                     if secondary_fields <> []
                     then
                       `Error
                         ((Meta_conv.Error.Unknown_fields (__name,
                             (List.map fst secondary_fields), (Obj.repr res))),
                         __v, __t)
                     else `Ok res
                 with | Ocaml_conv.Error e -> `Error e)
      
    let _ = t'_of_ocaml
      
    let t'_of_ocaml_exn : (t', Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t'_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t'_of_ocaml_exn
      
    let format_t = Ocaml.format_with ocaml_of_t
      
    let () =
      let r' = { x' = 1; y' = 1.0; z' = (); } in
      let format_sprintf fmt = let open Format
        in
          let buf = Buffer.create 100 in
          let ppf = formatter_of_buffer buf
          in
            kfprintf
              (fun ppf -> (pp_print_flush ppf (); Buffer.contents buf)) ppf
              fmt in
      let s = format_sprintf "%a" (fun x -> Ocaml.format x) (ocaml_of_t' r')
      in
        (prerr_endline s;
         let o =
           match Ocaml.Parser.from_string s with
           | [ x ] -> x
           | _ -> assert false
         in
           (Format.eprintf "parse done: %a@." (fun x -> Ocaml.format x) o;
            try
              let r = t_of_ocaml_exn o
              in Format.eprintf "r = %a@." format_t r
            with
            | Ocaml_conv.Error e ->
                Ocaml_conv.format_full_error Format.err_formatter e))
      
  end
  
module Test8 =
  struct
    type t = < x : int; y : string >
    
    let _ = fun (_ : t) -> ()
      
    let ocaml_of_t : t -> Ocaml.t =
      fun __v ->
        (fun __v ->
           Ocaml_conv.Constr.object_ "t"
             (List.flatten
                [ [ ("x", (ocaml_of_int __v#x)) ];
                  [ ("y", (ocaml_of_string __v#y)) ] ]))
          __v
      
    let _ = ocaml_of_t
      
    let t_of_ocaml : (t, Ocaml.t) Meta_conv.Types.Decoder.t =
      fun ?trace:(__t = []) __v ->
        (fun ?trace:(__t = []) __v ->
           let __name = "t" in
           let primary_labels = [ "x"; "y" ]
           in
             match Ocaml_conv.DeconstrDecoder.object_ __name ~trace: __t __v
             with
             | `Error e -> `Error e
             | `Ok fields ->
                 let (primary_fields, secondary_fields) =
                   Meta_conv.Internal.filter_fields primary_labels fields
                 in
                   (try
                      let x =
                        Meta_conv.Internal.field_assoc_exn __name "x"
                          primary_fields Ocaml_conv.throw
                          (Ocaml_conv.exn int_of_ocaml) ?trace: (Some __t)
                          __v
                      and y =
                        Meta_conv.Internal.field_assoc_exn __name "y"
                          primary_fields Ocaml_conv.throw
                          (Ocaml_conv.exn string_of_ocaml) ?trace: (Some __t)
                          __v in
                      let res = object method x = x method y = y end
                      in
                        if secondary_fields <> []
                        then
                          `Error
                            ((Meta_conv.Error.Unknown_fields (__name,
                                (List.map fst secondary_fields),
                                (Obj.repr res))),
                            __v, __t)
                        else `Ok res
                    with | Ocaml_conv.Error e -> `Error e))
          ~trace: __t __v
      
    let _ = t_of_ocaml
      
    let t_of_ocaml_exn : (t, Ocaml.t) Meta_conv.Types.Decoder.t_exn =
      fun ?(trace = []) v ->
        match t_of_ocaml ~trace v with
        | `Ok v -> v
        | `Error e -> raise (Ocaml_conv.Error e)
      
    let _ = t_of_ocaml_exn
      
  end
  


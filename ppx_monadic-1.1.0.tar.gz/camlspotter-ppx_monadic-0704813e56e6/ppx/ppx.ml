open Migrate_parsetree
open Ast_404

open Ppxx.Utils (* must come after Ast_helper *)
open Ast_mapper

let make_mapper () =
  Comprehension.extend & Pattern_guard.extend & Do_.extend default_mapper

let legacy_main () = Ppxx.Ppx.run [] "ppx_monadic" make_mapper

let register () = Ppxx.Ppx.register
  ~name:"ppx_monaidc"
  ~args: []
  (fun _config _cookies -> make_mapper ())


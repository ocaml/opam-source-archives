ocaml-bytes
===========

Bytes module for ocaml &lt;= 4.02

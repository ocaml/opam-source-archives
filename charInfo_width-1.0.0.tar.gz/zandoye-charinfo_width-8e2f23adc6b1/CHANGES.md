## 1.0.0 (2018-12-03)

* remove the `width\_utext` function
* add `CharInfo_width.String` functor to calculates all kind of strings compatible with `Camomile.UnicodeString.Type.t`

## 0.1.0 (2018-11-16)

initial release

let f r = [%poly_record { r with x = 2; y = 3 } ]

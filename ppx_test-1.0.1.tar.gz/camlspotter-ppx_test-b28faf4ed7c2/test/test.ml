(* module PTest must provide the following functions:

  val test_unit : ?loc: Location.t -> string option -> (unit -> unit) -> unit
  val test : ?loc: Location.t -> string option -> (unit -> bool) -> unit

*)
module PTest = Ppx_test.Test

(* %TEST is for tests of type bool.

   This replaces pa_ounit's [TEST name = e] 
 *)
let %TEST equal = 1 = 1

(* %TEST with name ends with `_` is for tests of type unit,
   following Haskell function naming convention.

   This replaces pa_ounit's [TEST_UNIT name = e] 
 *)
let %TEST equal_ = assert (1 = 1)

(* %TEST_UNIT is for tests of type unit. 

   This replaces pa_ounit's [TEST_UNIT name = e]. 
*)
let %TEST_UNIT trivial = assert true

(* Currently there is no simple way to replace pa_ounit's
   [TEST_MODULE name = struct .. end], since OCaml 4.02.0 does not allow
   extensions appear after [module]:

     [module %TEST X = struct .. end]

   But we can write an equivalent with [let %TEST_UNIT] in ppx_test:

     [let %TEST_UNIT name = let module M = struct .. end in ()]
 *)

let %TEST_UNIT module_name = 
  let module M = struct 
    let %TEST in_module = 3 = 3
  end in ()

let () = PTest.collect ()

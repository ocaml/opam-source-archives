(*  Copyright 2013 Inria  *)
Version.add "$Id: 8d3e74063353abcfefb6c4de625febcd0a10705c $";;

Extension.activate "recfun";;
Main.parse_command_line Main.argspec;;
Main.do_main ();;

# OCaml_Levenshtein

Levenshtein distance algorithm for general array (string, 'a array, etc.).


open Types
open Error
open Result

module type S = sig
  type t
  
  module Encode : sig
    val tuple : t list -> t
    val variant : string -> t list -> t
    val record : (string * t) list -> t
  end

  module Decode : sig
    val tuple : (t * Address.t) -> (t * Address.t) list
    val variant : (t * Address.t) -> string * (t * Address.t) list
    val record : (t * Address.t) -> (string * (t * Address.t)) list
  end
end

module Make_Decode_Adrs(D : sig
  type t
  val tuple : t -> t list
  val variant : t -> string * t list
  val record : t -> (string * t) list
end) = struct

  let list_mapi f xs =
    List.rev (fst (List.fold_left (fun (rev,i) x ->
      (f x i :: rev), i+1) ([],0) xs))
    
  let tuple (t, adrs) = list_mapi (fun t i -> (t, i::adrs)) (D.tuple t)
  let variant (t, adrs) = 
    let tag, ts = D.variant t in
    tag, list_mapi (fun t i -> (t, i::adrs)) ts
  let record (t, adrs) =
    list_mapi (fun (tag,t) i -> (tag, (t, i::adrs))) (D.record t)
end

let mapM : ('a, 'target) Decoder.t -> ('target * Address.t) list -> ('a list, 'target) Result.t
= fun d xs ->
    let rec f rev_st = function
      | [] -> `Ok (List.rev rev_st)
      | (x,adrs)::xs ->
          match d ?adrs:(Some adrs) x with
          | `Ok v -> f (v::rev_st) xs
          | `Error e -> `Error e
    in
    f [] xs

external (|>) : 'a -> ('a -> 'b) -> 'b = "%revapply"

let tuple_arity_error exp_len act_len v adrs = 
  `Error (Wrong_arity (exp_len, act_len, None), v, adrs)
let variant_arity_error type_name constructor_name exp_len act_len v adrs = 
  `Error (Wrong_arity (exp_len, act_len, Some (type_name, constructor_name)), v, adrs)
let variant_unknown_tag_error type_name tag_name v adrs =
  `Error (Unknown_fields (type_name, [ tag_name, v ]), v, adrs) 
(*
let record_unknown_fields_error type_name v adrs =
  `Error (Unknown_fields (type_name, v), adrs) 
*)
let primitive_decoding_failure mes v adrs = 
  `Error (Primitive_decoding_failure mes, v, adrs)

let field_assoc name v adrs key alist (decode : (_,_) Decoder.t) =
  try 
    let (v, adrs) = List.assoc key alist in
    decode ~adrs v
  with Not_found -> 
    `Error (Required_fields_not_found (name, [key], 
                                       List.map (fun (k,(t,_a)) -> k,t) alist), 
            v, adrs)

let field_assoc_optional _name _v _adrs key alist (decode : (_,_) Decoder.t) =
  try 
    let (v, adrs) = List.assoc key alist in
    match decode ~adrs v with
    | `Ok v -> `Ok (Some v)
    | `Error e -> `Error e
  with Not_found -> `Ok None

let filter_record_fields type_system actual =
  List.filter (fun (f,_) -> not (List.mem f type_system)) actual 

type ('host, 'target) field_checker =
    string (** type name *)
    -> 'target (** the input *)
    -> Address.t 
    -> (string * ('target * Address.t)) list (** unknown fields *)
    -> (unit -> ('host, 'target) Result.t) 
    -> ('host, 'target) Result.t

let record_unknown_field_check name v adrs unknowns k = match unknowns with
  | [] -> k ()
  | _ -> `Error (Unknown_fields (name, List.map (fun (k, (v,_a)) -> k,v) unknowns), v, adrs)

let record_ignore_unknown_fields _name _v _adrs _unknons k = k ()

let integer_of_float min max conv n =
  if floor n <> n then `Error "not an integer"
  else if min <= n && n <= max then `Ok (conv n)
  else `Error "overflow"

let add_addresses base xs = 
  List.fold_left (fun (i,rev_xs) x ->
    (i+1, (x, i::base) :: rev_xs)) (0, []) xs
  |> snd 
  |> List.rev

let generic_list_of gets d ?(adrs=[]) v = match gets v with
  | Some xs -> 
      let xs = add_addresses adrs xs in
      mapM d xs
  | None -> 
      primitive_decoding_failure 
        "Meta_conv.Internal.generic_list_of: listable expected" 
        v adrs

let generic_array_of gets d ?(adrs=[]) v =
  fmap Array.of_list 
  (generic_list_of gets d ~adrs v)

let generic_option_of extract f ?(adrs=([] : Address.t)) v =
  match extract v with 
  | Some None -> `Ok None
  | Some (Some v) -> f ?adrs:(Some adrs) v >>= fun x -> `Ok (Some x)
  | None -> 
      primitive_decoding_failure
        "Meta_conv.Internal.generic_option_of: option expected"
        v adrs

let generic_lazy_t_of errorf (f : ('host, 'target) Decoder.t) ?(adrs=([] : Address.t)) v = 
  `Ok (lazy (
    match f ?adrs:(Some adrs) v with
    | `Ok v -> v
    | `Error e -> errorf e
  ))

let generic_mc_lazy_t_of (f : ('host, 'target) Decoder.t) ?(adrs=([] : Address.t)) v = 
  `Ok (lazy (f ?adrs:(Some adrs) v))


type t = { a : int; b : float; c (: Leftovers :) : (string * Json.t) list  } with conv(json)

type t = { d : int; e : Json.t mc_leftovers } with conv(json)


open Camlp4
open PreCast
open Pa_type_conv
open Ast

let _loc = Loc.ghost

(** [ from_one_to n = [1; 2; ..; n] ] *)
let from_one_to n = let rec loop i = if i > n then [] else i :: loop (i+1) in loop 1

(** [mk_idents name n] creates idents from name1 to namen *) 
let mk_idents : string -> int -> ident list = fun pref n ->
  List.map (fun i -> IdLid (_loc, pref ^ string_of_int i)) (from_one_to n)

(** [patt_of_tvar tv] creates a pattern variable for a type variable [tv] *)
let patt_of_tvar : ctyp -> patt = function
  | <:ctyp<'$tv$>> -> <:patt< $lid:"__tv_" ^ tv$ >>
  | _ -> assert false

(** [expr_of_tvar tv] creates an expression variable for a type variable [tv] *)
let expr_of_tvar : ctyp -> expr = function
  | <:ctyp<'$tv$>> -> <:expr< $lid:"__tv_" ^ tv$ >>
  | _ -> assert false

(** [create_patt_app const args] creates a pattern of variant constructor like 
    const (arg1,..,argn) *)
let create_patt_app : patt -> patt list -> patt = fun f patts ->
  List.fold_left (fun st p -> PaApp (_loc, st, p)) f patts

(** [create_expr_app const args] creates an expr of variant constructor like 
    const (arg1,..,argn) 
  This is a variant of Gen.create_expr_app *)
let create_expr_app : expr -> expr list -> expr = fun f exprs ->
  List.fold_left (fun st p -> ExApp (_loc, st, p)) f exprs

let rec concat_class_str_items : class_str_item list -> class_str_item = function
  | [] -> CrNil _loc
  | [x] -> x
  | x::xs -> CrSem (_loc, x, concat_class_str_items xs)

let rec concat_let_bindings : binding list -> binding = function
  | [] -> BiNil _loc
  | [x] -> x
  | x::xs -> BiAnd (_loc, x, concat_let_bindings xs)

let rec concat_str_items : str_item list -> str_item = function
  | [] -> StNil _loc
  | [x] -> x
  | x::xs -> StSem (_loc, x, concat_str_items xs)

let rec concat_sig_items : sig_item list -> sig_item = function
  | [] -> SgNil _loc
  | [x] -> x
  | x::xs -> SgSem (_loc, x, concat_sig_items xs)

(** [expr_of_id id] and [patt_of_id id] create an expr or patt of [id] correspondingly *)
let expr_of_id : ident -> expr = fun id -> <:expr< $id:id$ >>
let patt_of_id : ident -> patt = fun id -> <:patt< $id:id$ >>

(** (p1, p2, .., pn) name *)
let create_param_type : ctyp list -> string -> ctyp = fun params name ->
  List.fold_left (fun st x -> TyApp (_loc, st, x)) <:ctyp< $lid: name$ >> params 

(** p1 ... pn . ty *)
let create_for_all : ctyp list -> ctyp -> ctyp = fun params ty -> match params with
  | [] -> ty
  | x::xs -> TyPol (_loc, List.fold_right (fun x st -> TyApp (_loc, st, x)) xs x, ty)

(** A.x => A.y where y = f x *)
let rec change_id f = function
  | IdAcc (loc, a, b) -> IdAcc (loc, a, change_id f b)
  | IdLid (loc, s) -> IdLid (loc, f s)
  | id -> id

(** Abcc.x => abc_dot_x *)
let rec label_of_path = function
  | IdAcc (_loc, a, b) -> label_of_path a ^ "_dot_" ^ label_of_path b
  | IdLid (_loc, s) -> s
  | IdUid (_loc, s) -> String.uncapitalize s
  | _id -> assert false

(** e1, e2, ..., en => (e1,...,en) 
    Do not use this for variant creations, since variants are curried in P4.
*)
let create_tuple : expr list -> expr = function
  | [] -> assert false
  | [e] -> e
  | exprs -> ExTup (_loc, exCom_of_list exprs)

let create_patt_tuple : patt list -> patt = function
  | [] -> assert false
  | [p] -> p
  | patts -> PaTup (_loc, paCom_of_list patts)

(** e1, e2, ..., en => [e1;...,en] *)
let rec create_list : expr list -> expr = function
  | [] -> <:expr< [] >>
  | e::es -> <:expr< $e$ ::$ create_list es $ >>

(** e1, e2, ..., en => [e1;...,en] *)
let rec create_patt_list : patt list -> patt = function
  | [] -> <:patt< [] >>
  | e::es -> <:patt< $e$ ::$ create_patt_list es $ >>

(** l1,e1, ... ln,en => { l1:e1; ...; ln:en } *)
let create_record : (ident * expr) list -> expr = fun label_exprs -> 
  ExRec (_loc, 
         rbSem_of_list (List.map (fun (l,e) -> RbEq(_loc, l,e)) label_exprs), 
         ExNil _loc)

let create_top_let : bool -> binding list -> str_item = fun rec_ binds ->
  let binds = 
    let rec create_binds = function
      | [] -> BiNil _loc
      | x::xs -> BiAnd (_loc, x, create_binds xs)
    in
    create_binds binds 
  in
  if rec_ then <:str_item< let rec $binds$ >>
  else <:str_item< let $binds$ >>

(** [strip_flags cty] removes mutable and private flags *)
let rec strip_field_flags = function
  | TyMut (_, cty) | TyPrv (_, cty) -> strip_field_flags cty
  | cty -> cty

(** forget the ident locations *)
let rec strip_ident_loc : ident -> ident = function
  | IdAcc(_, id1, id2) -> IdAcc(_loc, strip_ident_loc id1, strip_ident_loc id2)
  | IdApp(_, id1, id2) -> IdApp(_loc, strip_ident_loc id1, strip_ident_loc id2)
  | IdLid(_, n) -> IdLid(_loc, n)
  | IdUid(_, n) -> IdUid(_loc, n)
  | IdAnt(_, n) -> IdAnt(_loc, n)

(* CR jfuruse: bug: a.B.c.D is accepted *)    
let convert_path ss =
  let create = function
    | "" -> assert false
    | x -> match x.[0] with
      | 'a'..'z' -> <:ident< $lid:x$ >> 
      | 'A'..'Z' -> <:ident< $uid:x$ >>
      | _ -> assert false
  in
  let rec concat = function
    | [x] -> x
    | x::xs -> <:ident< $x$ . $concat xs$ >>
    | [] -> assert false
  in
  concat (List.map create ss)

let name_of_ident = function
  | IdUid (_, name) | IdLid (_, name) -> name
  | _ -> assert false

let type_definitions_are_recursive rec_ tds = 
  rec_ &&
    List.exists (function
      | TyDcl (_, name, _, _, _) -> Gen.type_is_recursive name tds
      | _ -> assert false) 
    (list_of_ctyp tds [])

open Meta_conv.Open
open Ocaml_conv

module Test1 = struct
  type t = Foo | Bar of int * string with conv(ocaml)
  
  let () = 
    let x = Bar (0, "hello") in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test2 = struct
  type t = { foo : int; bar : float option } with conv(ocaml)
  
  let () = 
    let x = { foo = 3; bar = Some 1.2 } in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test3 = struct
  open Test2
  type t = Test2.t with conv(ocaml)
  
  let () = 
    let x = { foo = 3; bar = Some 1.2 } in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test4 = struct
  type t = Foo (:"foo":) | Bar (:"bar":) of int * string with conv(ocaml)
  
  let () = 
    let x = Bar (0, "hello") in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test5 = struct
  type t (: Ignore_unknown_fields :) = { x : int; y : float } with conv (ocaml)
  type t' = { x' as "x" : int; y' as "y" : float; z' as "z" : unit  } with conv (ocaml)
  
  let () = 
    let r' = { x' = 1; y' = 1.0; z' = () }  in
    assert (t_of_ocaml (ocaml_of_t' r') = `Ok { x = 1; y = 1.0 })
end

module Test6 = struct
  type t = { x : int; y : float; rest (:Leftovers:) : Ocaml.t mc_fields; } with conv (ocaml)
  type t' = { x' as "x" : int; y' as "y" : float; z' as "z" : unit  } with conv (ocaml)

  let format_t' = Ocaml.format_with ocaml_of_t'

  let () = 
    let r' = { x' = 1; y' = 1.0; z' = () }  in
    assert (t_of_ocaml (ocaml_of_t' r') = `Ok { x = 1; y = 1.0; rest = [ "z", (Ocaml.Unit, [2]) ] });
    assert (ocaml_of_t (match t_of_ocaml (ocaml_of_t' r') with `Ok v -> v | _ -> assert false) = ocaml_of_t' r');
    Format.eprintf "r' = %a@." format_t' r'
end


type t = 
  | Bool of bool
  | Int31 of int
  | Int63 of int64
  | Int32 of int32
  | Int64 of int64
  | Nativeint32 of int32
  | Nativeint64 of int64
  | Float of float
  | Char of char
  | String of string
  | List of t list
  | Array of t list
  | Variant of string * t list
  | Record of (string * t) list
  | Tuple of t list
  | Unit

type ocaml = t

open Format

let rec format_list (sep : (unit, formatter, unit) format)  f ppf = function
  | [] -> ()
  | [x] -> f ppf x
  | x::xs -> 
      fprintf ppf "@[%a@]%t%a" 
	f x
	(fun ppf -> fprintf ppf sep)
	(format_list sep f) xs

let rec format ppf = function
  | Bool b -> fprintf ppf "%b" b
  | Int31 i -> fprintf ppf "%d" i
  | Int63 i -> fprintf ppf "%Ld" i
  | Int32 i -> fprintf ppf "%ldl" i
  | Int64 i -> fprintf ppf "%LdL" i
  | Nativeint32 i -> fprintf ppf "%ldn" i
  | Nativeint64 i -> fprintf ppf "%Ldn" i
  | Float f -> fprintf ppf "%F" f
  | Char c -> fprintf ppf "%C" c
  | String s -> fprintf ppf "%S" s
  | List ts -> fprintf ppf "[ @[%a@] ]" (format_list ";@ " format) ts
  | Array ts -> fprintf ppf "[ @[%a@] ]" (format_list ";@ " format) ts
  | Variant (tag, []) -> fprintf ppf "%s" tag
  | Variant (tag, ts) -> fprintf ppf "@[<2>%s@ (@[%a@])@]" tag (format_list ",@ " format) ts
  | Record fields -> fprintf ppf "@[<2>{ @[%a@] }@]" (format_list ";@ " (fun ppf (f, v) -> fprintf ppf "%s= %a" f format v)) fields
  | Tuple ts -> fprintf ppf "(@[<2>%a@])" (format_list ",@ " format) ts
  | Unit -> fprintf ppf "()"

let format_with f ppf v = format ppf (f v)

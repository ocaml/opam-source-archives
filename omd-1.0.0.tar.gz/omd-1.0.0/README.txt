(* OASIS_START *)
(* DO NOT EDIT (digest: 9005778ab3e46b7fe627dbd57caee4bb) *)
This is the README file for the omd distribution.

A Markdown frontend in pure OCaml.

This Markdown library is implemented using only pure OCaml (including I/O
operations provided by the standard OCaml compiler distribution). Omd is
meant to be as faithful as possible to the original Markdown. Additionally,
Omd implements a few Github markdown features, an extension mechanism, and a
few other features. Note that the opam package installs both the Omd library
and the command line tool `omd`. Note that The library interface of 1.0.0 is
not compatible with 0.9.x.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/pw374/omd


(* OASIS_STOP *)

let mapper = Desugar_pattern_guard.extend Ast_mapper.default_mapper

let () = Ppxx.run "ppx_pattern_guard" mapper

module Regexp = Regexp

(* for pa_hash *)
module Internal_hashtbl = Hashtbl

module Cformat = Cformat

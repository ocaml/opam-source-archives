(*
  Regexp creation $/.../
*)

open Orakuda.Std
open Orakuda.Regexp.Infix

(* str_item *)
$/([0-9]+)(?P<x>[a-z]+)|([A-Z]+)/;;

(* CR jfuruse: CamlP4 problem: the following is not parsable. *) 
(* $/([0-9]+)(?P<x>[a-z]+)|([A-Z]+)/, 1;; *)
($/([0-9]+)(?P<x>[a-z]+)|([A-Z]+)/, 1);;

let rex = $/([0-9]+)(?P<x>[a-z]+)|([A-Z]+)/;;

let res =
  match Regexp.exec rex "abc123def456" with
  | None -> assert false
  | Some res ->
      assert (res#_0 = "123def");
      assert (res#_1 = "123");
      assert (res#_2 = "def");
      assert (res#_2 = res#x);
      assert (res#_left = "abc");
      assert (res#_right = "456");
      assert (res#_3 = "");
      assert (res#_last = "def");
      res
;;

let rex = <:m<([0-9]+)(?P<x>[a-z]+)|([A-Z]+)>>;;

let res =
  match Regexp.exec rex "abc123def456" with
  | None -> assert false
  | Some res ->
      assert (res#_0 = "123def");
      assert (res#_1 = "123");
      assert (res#_2 = "def");
      assert (res#_2 = res#x);
      assert (res#_left = "abc");
      assert (res#_right = "456");
      assert (res#_3 = "");
      assert (res#_last = "def");
      res
;;

let _ = assert (("HeLlO" =~ $/hello/i) <> None)

let _ = assert (("HeLlO" =~ $/hello/) = None)

let _ = assert (("HeLlO" =~ <:m<hello/i>>) <> None)

let _ = assert (("HeLlO" =~ <:m<hello>>) = None)

let () =
  match "http://www.www.com" =~ <:m<http:\/\/([^.]+)\.([^.]+)\.([^.]+)>> with
  | None -> assert false
  | Some res -> 
      assert (res#_1 = "www"
           && res#_2 = "www"
           && res#_3 = "com")

(*
  Regexp case match

  string |! $/regexp/ as x -> ... | $/regexp/ as x -> ... | _ -> ...

*)

open Spotlib.Spot
open Orakuda.Std

let r = $/hello/ -> "world" | $/bye/ -> "universe" | _ -> "default"
;;

let _ = 
  assert (r "hello world" = "world");
  assert (r "bye universe" = "universe");
  assert (r "42" = "default")
;;

(* CR jfuruse: hmmm. Precedence seems glitchy *)

let _ = 
  let res = 
    "world bye universe" 
    |! $/hello/ -> "world" 
    | $/bye/ as x -> x#_left ^ x#_right
    | _ -> "default"
  in
  assert ("world  universe" = res)
;;

let _ = 
  let res = 
    "world bye universe" 
    |! $/([^ ]+) ([^ ]+) ([^ ]+)/ as x -> x#_1
    |! $/([^ ]+) ([^ ]+) ([^ ]+)/ as x -> (match x#_1opt with Some v -> v | None -> "")
    | $/(.*)/ as x -> x#_1
    | _ -> "default"
  in
  assert ("world" = res)
;;

let _ =
  "hello"
  |! $/^S_|\/S_/ -> true 
  | _ -> false
;;

let _ =
  "hello"
  |! <:m<^S_|\/S_>> -> true 
  | _ -> false

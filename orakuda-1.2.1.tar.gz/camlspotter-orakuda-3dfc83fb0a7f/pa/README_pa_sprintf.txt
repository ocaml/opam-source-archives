NAME

    pa_xprintf: sprintf a la perl

SYNOPSIS

    $"..."

        Short hand of Printf.sprintf "..." with inlined variable
	and expression embed by $-notation.

        EXAMPLE

          $"... $foo123 ..."     
	      Equivalent to Printf.sprintf "... %s ..." foo123

          $"... ${Hashtbl.find tbl k} ..."
	      Equivalent to Printf.sprintf "... %s ..." (Hashtbl.find tbl k)

          $"...%${var}02d..."
              Equivalent to Printf.sprintf "...%02d..." var

          $"...%s...%${var}02d..."
              Equivalent to 
	          fun s -> Printf.sprintf "...%s...%02d..." s var

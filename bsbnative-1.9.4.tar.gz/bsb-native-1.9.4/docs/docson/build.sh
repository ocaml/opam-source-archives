#!/bin/sh
reload



There is a lot of room to improve bb-reveal and I am welcoming any contributions from the community. 

### Contributing

Submit issues for any bugs or improvement ideas you have. Or even better, fix them and submit pull a request.

### Ownership

This is currently a side project, so if anybody want to help me maintain and own this, please let me know.


### Enhancement idea

As far as see, the following would be nice enhancements

 - Tighten up the style sheet for the current tempalte.
 - Create a style sheet inline with the corporate .ppt template with a dark background.
 - Add facitlities to easily provide more complex layouts:
    - two column layout
    - ...
 - Add functionality for simple (or complex) animations of `.svg` graphics files:
    - show / hide groups in the graphic on click
    - move graphical elements
   





let _ = 
  Js.Int.toString,
  Js.Float.isNaN
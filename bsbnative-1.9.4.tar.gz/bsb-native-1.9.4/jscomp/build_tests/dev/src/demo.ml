

let name = __FILE__ ^ Liba.Demo.name
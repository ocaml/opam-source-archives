var p  = require('child_process')

p.execSync(`bsb`)


let u = Xx.sum 3


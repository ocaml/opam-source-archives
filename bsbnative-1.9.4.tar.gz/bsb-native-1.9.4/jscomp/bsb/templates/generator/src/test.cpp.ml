
(* 
#define FS_VAL(name,ty) external name : ty = "" [@@bs.module "fs"]


FS_VAL(readdirSync, string -> string array)
 *)


 let ocaml = OCAML
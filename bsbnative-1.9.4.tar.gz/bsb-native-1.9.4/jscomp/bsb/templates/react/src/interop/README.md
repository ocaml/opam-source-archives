## Interoperate with Existing ReactJS Components

This subdirectory demonstrate the ReasonReact <-> ReactJS interop APIs.

The entry point, `interopRoot.js`, illustrates ReactJS requiring a ReasonReact component, `GreetingRe`.

`GreetingRe` itself illustrates ReasonReact requiring a ReactJS component, `myBanner.js`, through the Reason file `myBannerRe.re`.



let () = Js.log "Hello, BuckleScript"
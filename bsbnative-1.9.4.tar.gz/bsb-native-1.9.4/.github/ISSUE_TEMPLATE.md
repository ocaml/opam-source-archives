Issues are for bugs. If you have questions, ask them on a [community forum][comm]. Folks are friendly and happy to help!

[comm]: discord.gg/reasonml 

Please have a look at checklist before submitting issues:

https://github.com/BuckleScript/bucklescript/blob/master/.github/CHECK_LIST.md
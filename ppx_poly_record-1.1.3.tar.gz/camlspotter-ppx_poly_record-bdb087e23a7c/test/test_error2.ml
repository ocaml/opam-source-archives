let () = [%poly_record { x = 1; x = 1 } ]
 

ppx_test : ppx replacement of pa_ounit
========================================

# `__FOR_PACKAGE__`

`__FOR_PACKAGE__` is a pseudo value of type `string option`
which returns the package name specified by comipler's `-for-package` option. 

# Test expression `let %TEST name = e`

`let %TEST name = e` is a replacement of `pa_ounit`'s `TEST name = e`.
It has the following forms:

* `let %TEST_UNIT name = e` : test whose type is unit, which replaces `TEST_UNIT name = e`
* `let %TEST name_ = e` : test whose type is unit, which replaces `TEST_UNIT name = e`
* `let %TEST name = e` : test whose type is bool, which replaces `TEST name = e`

## Requirement

`let %TEST*` are translated to vanilla OCaml code which may use the following
functions:

* `PTest.test : Ppx_test.Location.t -> string option -> (unit -> unit) -> unit`
* `PTest.test_unit : Ppx_test.Location.t -> string option -> (unit -> unit) -> unit`

It is the client responsibility to prepare the module `Ptest` in the name space
where `let %TEST*` is used. `Ppx_test.Test` is a simple example ready to use.
`examples/wrap_pa_ounit.ml` provides a simple wrapper for `pa_ounit`.

## Test names

Test names can be one of the following:

* `_` : anonymous
* `"name"` : string
* `name` : variable
* `M.X` : "constr_longident"

If a name is a string, variable or constr_longident, it is prefixed 
by the current module path. For example, in the following code,

```ocaml
(* x.ml *)
module M = struct
  let %TEST test = ...
end
```

The test has the name `X.M.test`. If the file is compiled with `-for-package P`, then it is prefixed as `P.X.M.test`.

If a name is not anonymous and ends with `_`, it is considered 
a test of type `unit`. This follows the convention of Haskell function naming (ex. `mapM_ :: Monad m => (a -> m b) -> [a] -> m ()`.)


## `unit` tests

Struct item `let %TEST_UNIT name = e`
and struct item `let %TEST name_ = e (* when name ends with _ *)`
are translated to the following

`let () = Ptest.test_unit <location of <name = e>> <name> (fun () -> <e>)`

## `bool` tests

Struct item `let %TEST name = e`
is translated to the following

`let () = Ptest.test <location of <name = e>> <name> (fun () -> <e>)`

## `module` tests

Currently there is no direct replacement of `TEST_MODULE name = struct .. end` of `pa_ounit`, since we have no simple syntax with ppx extensions for now. 
However, you can write an equivalent as follows:

```ocaml
let %TEST name = 
  let module M = struct
    ..
  end in ()
```

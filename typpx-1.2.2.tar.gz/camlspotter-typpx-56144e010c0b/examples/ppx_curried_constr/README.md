To see how it works:

```shell
$ ./ppx_curried_constr.exe -debug tests/test.ml
```

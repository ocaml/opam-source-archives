let _ = output_char



open Extended


let x = float_of_string "0.0000000000000000001"

let y = float_of_int 1

let z = x +. y

let _ = 
  Printf.printf "%s %s %s\n" (string_of_float x) (string_of_float y) (string_of_float z)

let b = if x <= y then print_string "true";

open Camlp4.PreCast

module Id : Camlp4.Sig.Id =
    struct
      let name = "callbacks"
      let version = "0.1"
    end

module Extension (Syntax : Camlp4.Sig.Camlp4Syntax) =
	struct
include Syntax


let do_section = ref true

type ty =
    Arrow of string option * ty * ty
  | Int
  | Float
  | Char
  | String
  | CVal of Ast.ctyp
  | MLVal of Ast.ctyp
  | Atom of Ast.ctyp
  | Unit

let rec base_name' = function
    Ast.IdLid (_, s) -> s
  | Ast.IdAcc (_,t1,t2) -> base_name' t2
  | _ ->
      Printf.fprintf stderr "Type not handled by c_wrapper\n";
      exit 1

let base_name = function
    Ast.TyId(_,id) -> base_name' id 
  | _ ->
      Printf.fprintf stderr "Type not handled by c_wrapper\n";
      exit 1
let type_to_ctype arg = function
    Int | Atom _ -> "int "^arg
  | Float -> "double "^arg
  | Unit -> "void"
  | MLVal _ -> "value "^arg
  | CVal ty -> base_name ty^" "^arg
  | Char -> "unsigned char "^arg 
  | String -> "unsigned char* "^arg
  | _ ->
      Printf.fprintf stderr "Illegal higher order function\n";
      exit 1
 
let conversion_to_c x = function
    Int | Char | Atom _ -> "Int_val("^x^")"
  | Float -> "Double_val("^x^")"
  | Unit -> "void"
  | MLVal _ -> x 
  | CVal ty -> "((base_name ty) "^x^")"
  | String -> "String_val("^x^")"
  | _ ->
      Printf.fprintf stderr "Illegal higher order function\n";
      exit 1

let conversion_from_c x = function
    Int | Char  | Atom _ -> "Val_int("^x^")"
  | Float -> "Val_double("^x^")"
  | Unit -> "Val_unit"
  | MLVal _ -> x
  | CVal _ -> "((value) "^x^")"
  | String -> "caml_copy_string("^x^")"
  | _ ->
      Printf.fprintf stderr "Illegal higher order function\n";
      exit 1

let ty_to_string = function
    Atom s -> Some s
  | _ -> raise (Stream.Error "illegal label")

let c_filename = ref "callbacks.c"
 
let c_channel = ref (None : out_channel option)

let _ =
  EXTEND Gram 
    str_item:
     [ [ "callbacks_file" ; name = STRING ->
       c_filename := name;
         <:str_item<()>>
       ] ]
    ;
  END	

let rec tyAcc_to_ExAcc' suffix r = function
    Ast.IdLid(loc,s) when r -> Ast.IdLid(loc,s^suffix)
  | Ast.IdUid (loc,s) -> Ast.IdUid(loc,s)
  | Ast.IdAcc(loc,t1,t2) -> Ast.IdAcc(loc, tyAcc_to_ExAcc'  suffix false t1, 
			      tyAcc_to_ExAcc'  suffix r t2)
  | _ ->
      Printf.fprintf stderr "Type not handled by c_wrapper\n";
      exit 1

let tyAcc_to_ExAcc suffix r = function
    Ast.TyId(loc,id) -> Ast.ExId(loc,tyAcc_to_ExAcc' suffix r id)
  | _ ->
      Printf.fprintf stderr "Type not handled by c_wrapper\n";
      exit 1

let rec ctyp_to_ctype = function
    Ast.TyId (_, Ast.IdLid(_,"int")) -> Int
  | Ast.TyId (_, Ast.IdLid(_,"float")) -> Float
  | Ast.TyId (_, Ast.IdLid(_,"unit")) -> Unit
  | Ast.TyId (_, Ast.IdLid(_,"char")) -> Char
  | Ast.TyId (_, Ast.IdLid(_,"string")) -> String
  | Ast.TyId (_, _) as t -> Atom(t)
  | Ast.TyApp(_,Ast.TyId(_,Ast.IdLid(_,"cval")),t) -> CVal(t)
  | Ast.TyApp(_,Ast.TyId(_,Ast.IdLid(_,"mlval")),t) -> MLVal(t)
  | Ast.TyArr(_,Ast.TyLab(_,lbl,t),t') -> Arrow(Some lbl,ctyp_to_ctype t,ctyp_to_ctype t')
  | Ast.TyArr(_,t,t') -> Arrow(None,ctyp_to_ctype t,ctyp_to_ctype t')
  | _ ->
      Printf.fprintf stderr "Type not handled by c_wrapper\n";
      exit 1


let rec ctyp_to_cvttyp = function
    (Ast.TyId (_, Ast.IdLid(_,"int"))
  | Ast.TyId (_, Ast.IdLid(_,"float"))
  | Ast.TyId (_, Ast.IdLid(_,"unit"))
  | Ast.TyId (_, Ast.IdLid(_,"string"))
  | Ast.TyId (_, Ast.IdLid(_,"char"))) as t -> t
  | Ast.TyId (loc,s) -> Ast.TyId(loc,Ast.IdLid(loc,"int"))
  | Ast.TyApp(_,Ast.TyId(_,Ast.IdLid(_,"cval")),t) -> t
  | Ast.TyApp(_,Ast.TyId(_,Ast.IdLid(_,"mlval")),t) -> t
  | Ast.TyLab(loc,lbl,t) -> Ast.TyLab(loc,lbl,ctyp_to_cvttyp t)
  | Ast.TyArr(loc,t,t') -> Ast.TyArr(loc,ctyp_to_cvttyp t,ctyp_to_cvttyp t')
  | _ ->
      Printf.fprintf stderr "Type not handled by c_wrapper\n";
      exit 1

let open_c_file () =
  match !c_channel with
    Some cfile -> cfile
  | None ->
      let cfile = open_out !c_filename in
      c_channel := Some cfile;
      Printf.fprintf cfile "#include <caml/mlvalues.h>\n";
      Printf.fprintf cfile "#include <caml/callback.h>\n";
      Printf.fprintf cfile "#include <caml/memory.h>\n";
      Printf.fprintf cfile "#include <caml/signals.h>\n";
      Printf.fprintf cfile "\n";
      cfile
	
let write_c_code loc s =
  let cfile = open_c_file () in
  Printf.fprintf cfile "%s\n" (Camlp4.Struct.Token.Eval.string s)
    
	
let output_to_cfile bname arglist num_arg result_type =
  let cfile = open_c_file () in
	   
  let arglist = Array.map snd arglist in

  Printf.fprintf cfile "value %s_cpointer = (value) NULL; \n" bname;

  Printf.fprintf cfile "%s %s_cfun(" (type_to_ctype "" result_type) bname;
  Array.iteri (fun i arg ->
    if i > 0 then Printf.fprintf cfile ", ";
    Printf.fprintf cfile "%s" (type_to_ctype ("arg"^string_of_int (i+1)) arg)) arglist;
  Printf.fprintf cfile ")\n{\n";
   
  if !do_section then Printf.fprintf cfile "\tleave_blocking_section ();\n";
  begin match num_arg with
    1 ->      
      if result_type <> Unit then Printf.fprintf cfile "\tvalue caml_result = "
	  else Printf.fprintf cfile "\t";
      Printf.fprintf cfile "caml_callback(%s_cpointer,%s); \n"
	bname 
	(conversion_from_c "arg1" (arglist.(0)));
  | 2 ->      
      if result_type <> Unit then Printf.fprintf cfile "\tvalue caml_result = "
	  else Printf.fprintf cfile "\t";
      Printf.fprintf cfile "caml_callback2(%s_cpointer,%s,%s); \n"
	bname 
	(conversion_from_c "arg1" (arglist.(0)))
	(conversion_from_c "arg2" (arglist.(1)));
  | 3 ->            
      if result_type <> Unit then Printf.fprintf cfile "\tvalue caml_result = "
      else Printf.fprintf cfile "\t";
      Printf.fprintf cfile "caml_callback3(%s_cpointer,%s,%s,%s); \n"
	bname 
	(conversion_from_c "arg1" (arglist.(0)))
	(conversion_from_c "arg2" (arglist.(1)))
	(conversion_from_c "arg3" (arglist.(2)));
  | _ -> 
      Printf.fprintf cfile "\tvalue argv[%d] = {" num_arg;
      Array.iteri (fun i arg ->
	if i > 0 then Printf.fprintf cfile ", ";
        output_string cfile  (conversion_from_c ("arg"^string_of_int (i+1)) arg)) arglist;
      Printf.fprintf cfile "};\n";
      if result_type <> Unit then Printf.fprintf cfile "\tvalue caml_result = "
	  else Printf.fprintf cfile "\t";
      Printf.fprintf cfile "caml_callbackN(%s_cpointer,%d,argv); \n"
	bname num_arg
  end;

  if result_type <> Unit then
    Printf.fprintf cfile "%s = %s;\n" 
      (type_to_ctype "result" result_type) 
      (conversion_to_c "caml_result" result_type);

  if !do_section then Printf.fprintf cfile "\tenter_blocking_section ();\n";

  if result_type <> Unit then
    Printf.fprintf cfile "return result;";

  Printf.fprintf cfile "}\n\n";

  Printf.fprintf cfile "\
CAMLprim value %s_set_cpointer (value cb) {\n\
  \tif (%s_cpointer == cb) return Val_unit;\n\
  \tif (!%s_cpointer) caml_register_global_root(&%s_cpointer);\n\
  \t%s_cpointer=cb;\n\
  \treturn (value) &%s_cfun;\n\
}\n\n" bname bname bname bname bname bname

let output_to_cfile' fname arglist num_arg result_type =
  let cfile = open_c_file () in
	   
  let arglist = Array.map snd arglist in

  Printf.fprintf cfile "CAMLprim value %s_cfun(" fname;
  if (num_arg < 5) then
    for i = 1 to num_arg do
      if i > 1 then Printf.fprintf cfile ", ";
      Printf.fprintf cfile "value arg%d" i
    done
  else
     Printf.fprintf cfile "int argc, value* argv";
  Printf.fprintf cfile ")\n{\n";
   
  let name_arg i = 
    if num_arg < 5 then "arg"^(string_of_int i) else "argv["^(string_of_int (i-1))^"]"
  in
  
  let registered_argv  = ref false in
  Array.iteri (fun i arg ->
    match arg with
      MLVal _ ->  
	if num_arg < 5 then 
	  Printf.fprintf cfile "\tcaml_register_global_root(&%s);\n" (name_arg (i+1))
	else if !registered_argv then begin
	  Printf.fprintf cfile "\tcaml_register_global_root(&argv);\n";
	  registered_argv := true
	end
    | _ -> ()) arglist;

  if !do_section then Printf.fprintf cfile "\tenter_blocking_section ();\n";
  
  Printf.fprintf cfile "\t%s c_result = %s(" (type_to_ctype "" result_type) fname;
  Array.iteri (fun i arg ->
    if i > 0 then Printf.fprintf cfile ", ";
    Printf.fprintf cfile "%s" (conversion_to_c (name_arg (i+1)) arg)) arglist;
  Printf.fprintf cfile ");\n";

  if !do_section then Printf.fprintf cfile "\tleave_blocking_section ();\n";

  let unregistered_argv  = ref false in
  Array.iteri (fun i arg ->
    match arg with
      MLVal _ ->  
	if num_arg < 5 then 
	  Printf.fprintf cfile "\tcaml_remove_global_root(&%s);\n" (name_arg (i+1))
	else if !unregistered_argv then begin
	  Printf.fprintf cfile "\tcaml_remove_global_root(&argv);\n";
	  unregistered_argv := true
	end
    | _ -> ()) arglist;

  if result_type <> Unit then
    Printf.fprintf cfile "\treturn %s;\n}\n\n" (conversion_from_c "c_result" result_type)


let _ = 
  EXTEND Gram
    str_item:
     [ [ "c_wrapper" ; bname = LIDENT; "for"; fname = LIDENT; ":"; tyast = ctyp ->
       let ty = ctyp_to_ctype tyast in
       let cvttyast = ctyp_to_cvttyp tyast in
       let rec fn acc i = function
	   Arrow(l,t,(Arrow(_,_,_) as ty)) ->
	     fn ((l,t)::acc) (i+1) ty
	 | Arrow(l,t,ty) ->
	     ((l,t)::acc,ty,i)
	 | _ ->
	     Printf.fprintf stderr "callback %s has no arguments\n" fname;
	     exit 1
       in
       let arglist, result_type, num_arg = fn [] 1 ty in
       let arglist = Array.of_list (List.rev arglist) in
       let need_conversion =  
	 let test b = function _, Atom _ -> true | _ -> b in
	 test false ((), result_type) || Array.fold_left test false arglist
       in 
       let conversion = 
	 if need_conversion then
	   let result x = 
	     match result_type with
	       Atom s -> <:expr<($tyAcc_to_ExAcc "_to_int" true s$ $x$)>>
	     | _ -> x
	   in
	   let i, args = 
	     Array.fold_left 
	       (fun (i,p) (lbl,ty) ->
		 (i+1, 
		  let arg = match ty with
                    Atom s -> <:expr<($tyAcc_to_ExAcc "_of_int" true s$ $lid:"arg"^(string_of_int i)$)>>
                  | _ -> <:expr<$lid:"arg"^(string_of_int i)$ >>
		  in
		  match lbl with
		      None -> <:expr<$p$ $arg$>>
		    | Some lbl ->
			<:expr<$p$ $Ast.ExLab(loc,lbl,arg)$>>

	       )) (1,<:expr<$lid:fname$>>) arglist
	   in
	   let args = result args in
	   let _, exp = 
	     Array.fold_right
	       (fun (lbl,_) (i,p)  ->
		 (i-1, match lbl with
		   None -> <:expr<fun $lid:"arg"^(string_of_int i)$ -> $p$>>
		 | Some lbl -> <:expr<fun $Ast.PaLab(loc,lbl,Ast.PaId(loc,Ast.IdLid(loc,"arg"^(string_of_int i))))$ -> $p$>>

	       )) arglist (i - 1, args)
	   in
	   exp
	 else 
	   <:expr<$lid:fname$>>
       in
       output_to_cfile bname arglist num_arg result_type;
       <:str_item@loc<
                    external $bname^"_set_cpointer"$
				       : ($cvttyast$ -> Direct_callback.callback ($tyast$))  = $Ast.LCons(bname^"_set_cpointer",Ast.LNil)$;
		    value $lid:bname$ = $lid:bname^"_set_cpointer"$  $conversion$;
                   >>
        | 
     "ocaml_wrapper" ; bname = LIDENT; ":"; tyast = ctyp; "="; fname = STRING ->
       let ty = ctyp_to_ctype tyast in
       let cvttyast = ctyp_to_cvttyp tyast in

       let rec fn acc i = function
	   Arrow(l,t,(Arrow(_,_,_) as ty)) ->
	     fn ((l,t)::acc) (i+1) ty
	 | Arrow(l,t,ty) ->
	     ((l,t)::acc,ty,i)
	 | _ ->
	     Printf.fprintf stderr "callback %s has no arguments\n" fname;
	     exit 1
       in
       let arglist, result_type, num_arg = fn [] 1 ty in
       let arglist = Array.of_list (List.rev arglist) in 

       let need_conversion =  
	 let test b = function _, Atom _ -> true | _ -> b in
	 test false ((), result_type) || Array.fold_left test false arglist
       in 
       let conversion = 
	 if need_conversion then
	   let result x = 
	     match result_type with
	       Atom s -> <:expr<($tyAcc_to_ExAcc "_of_int" true s$ $x$)>>
	     | _ -> x
	   in
	   let i, args = 
	     Array.fold_left 
	       (fun (i,p) (lbl,ty) ->
		 (i+1, 
		  let arg = match ty with
                    Atom s -> <:expr<($tyAcc_to_ExAcc "_to_int" true s$ $lid:"arg"^(string_of_int i)$)>>
                  | _ -> <:expr<$lid:"arg"^(string_of_int i)$ >>
		  in
		  match lbl with
		      None -> <:expr<$p$ $arg$>>
		    | Some lbl ->
			<:expr<$p$ $Ast.ExLab(loc,lbl,arg)$>>

	       )) (1,<:expr<$lid:"ml_"^fname$>>) arglist
	   in
	   let args = result args in
	   let _, exp = 
	     Array.fold_right
	       (fun (lbl,_) (i,p)  ->
		 (i-1, match lbl with
		   None -> <:expr<fun $lid:"arg"^(string_of_int i)$ -> $p$>>
		 | Some lbl -> <:expr<fun $Ast.PaLab(loc,lbl,Ast.PaId(loc,Ast.IdLid(loc,"arg"^(string_of_int i))))$ -> $p$>>

	       )) arglist (i - 1, args)
	   in
	   exp
	 else 
	   <:expr<$lid:"ml_"^fname$>>
       in
       output_to_cfile' fname arglist num_arg result_type;
       <:str_item@loc<external $"ml_"^fname$ 
				       : $cvttyast$ = $Ast.LCons(fname^"_cfun",Ast.LNil)$;
		    value $lid:bname$ = $conversion$;
                   >>
        | 
        "c_code" ; s = STRING ->
	  write_c_code loc s;
	  <:str_item<>>
        | 
        "c_concurrent_thread" ->
	  do_section := true;
	  <:str_item<>>
        | 
        "c_no_concurrent_thread" ->
	  do_section := false;
	  <:str_item<>>  ] ]
    ;
  END

end

module M = Camlp4.Register.OCamlSyntaxExtension(Id)(Extension)


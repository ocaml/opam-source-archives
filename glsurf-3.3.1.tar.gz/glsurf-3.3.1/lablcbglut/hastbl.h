#include "mlvalues.h"

/* hash of numbered values */
/* inspired and copied from callback.c */

typedef struct numbered_value {
  value val;
  struct numbered_value *next;
  int number;
} valuehashtbl;

#define Hash_size 101

CAMLexport value * caml_numbered_value(valuehash *hashtbl, int number);

CAMLprim value caml_register_numbered_value(valuehash *hashtbl, int number, value val);


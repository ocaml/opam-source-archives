/*
 *  wrap_glut.c
 *  
 *  an OCaml wrapper for a subset of Mark Kilgard's GLUT 
 *
 *  written by ijt
 *
 */

#ifdef _WIN32
#define GLUT_DISABLE_ATEXIT_HACK
#endif
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include <caml/mlvalues.h>
#include <caml/alloc.h>
#include <caml/memory.h>
//#include <caml/fail.h>
#include <caml/callback.h>
#include <caml/signals.h>

#include "ml_gl.h"

#define VoidPtr_val(x) ((void*) Int_val(x))

/* ML_0(glutMainLoop) */
CAMLprim value mlext_glutMainLoop (value unit) \
{ 
  enter_blocking_section ();
  glutMainLoop (); 
  leave_blocking_section ();
  return Val_unit; 
}


ML_0(glutSwapBuffers) /* makes a function called ml_glutSwapBuffers() */
ML_0(glutPostRedisplay)
ML_2(glutInitWindowSize, Int_val, Int_val)
ML_2(glutInitWindowPosition, Int_val, Int_val)
ML_1_(glutCreateWindow, String_val, Val_int)
ML_5_(glutCreateSubWindow, Int_val, Int_val, Int_val, Int_val, Int_val, Val_int)
ML_1(glutDestroyWindow, Int_val)
ML_0_(glutGetWindow, Val_int) /* return win id */
ML_1(glutSetWindow, Int_val)
ML_1(glutSetWindowTitle, String_val)
ML_1(glutSetIconTitle, String_val)
ML_2(glutPositionWindow, Int_val, Int_val)
ML_2(glutReshapeWindow, Int_val, Int_val)
ML_0(glutPopWindow)
ML_0(glutPushWindow)
ML_0(glutIconifyWindow)
ML_0(glutShowWindow)
ML_0(glutHideWindow)
ML_0(glutFullScreen)
ML_1(glutSetCursor, Int_val)
ML_0(glutEstablishOverlay)
ML_0(glutRemoveOverlay)
ML_1(glutUseLayer, Int_val)
ML_0(glutPostOverlayRedisplay)
ML_0(glutShowOverlay)
ML_0(glutHideOverlay)
ML_1(glutDestroyMenu, Int_val)
ML_0_(glutGetMenu, Val_int)
ML_1(glutSetMenu, Int_val)
ML_2(glutAddMenuEntry, String_val, Int_val)
ML_2(glutAddSubMenu, String_val, Int_val)
ML_3(glutChangeToMenuEntry, Int_val, String_val, Int_val)
ML_3(glutChangeToSubMenu, Int_val, String_val, Int_val)
ML_1(glutRemoveMenuItem, Int_val)
ML_1(glutAttachMenu, Int_val)
ML_1(glutDetachMenu, Int_val)
ML_4(glutSetColor, Int_val, Float_val, Float_val, Float_val)
ML_2_(glutGetColor, Int_val, Int_val, copy_double)
ML_1(glutCopyColormap, Int_val)
ML_1_(glutGet, Int_val, Val_int)
ML_1_(glutDeviceGet, Int_val, Val_int)
ML_1_(glutExtensionSupported, String_val, Val_bool)
ML_0_(glutGetModifiers, Val_int)
ML_1_(glutLayerGet, Int_val, Val_int)

ML_1_(glutVideoResizeGet, Int_val, Val_int)
ML_0(glutSetupVideoResizing)
ML_0(glutStopVideoResizing)
ML_4(glutVideoResize, Int_val, Int_val, Int_val, Int_val)
ML_4(glutVideoPan, Int_val, Int_val, Int_val, Int_val)
ML_0(glutReportErrors)

ML_3(glutWireSphere, Float_val, Int_val, Int_val)
ML_3(glutSolidSphere, Float_val, Int_val, Int_val)
ML_4(glutWireCone, Float_val, Float_val, Int_val, Int_val)
ML_4(glutSolidCone, Float_val, Float_val, Int_val, Int_val)
ML_1(glutWireCube, Float_val)
ML_1(glutSolidCube, Float_val)
ML_4(glutWireTorus, Float_val, Float_val, Int_val, Int_val)
ML_4(glutSolidTorus, Float_val, Float_val, Int_val, Int_val)
ML_0(glutWireDodecahedron)
ML_0(glutSolidDodecahedron)
ML_1(glutWireTeapot, Float_val)
ML_1(glutSolidTeapot, Float_val)
ML_0(glutWireOctahedron)
ML_0(glutSolidOctahedron)
ML_0(glutWireTetrahedron)
ML_0(glutSolidTetrahedron)
ML_0(glutWireIcosahedron)
ML_0(glutSolidIcosahedron)
ML_1(glutGameModeString, String_val)
ML_0(glutEnterGameMode)
ML_0(glutLeaveGameMode)
ML_1_(glutGameModeGet, Int_val, Val_int)

CAMLprim value mlext_glutInit( value v_argc, value v_argv )
{
    int i, argc;
    char** argv; 
  
    /* make an array for GLUT to handle */
    argc = Int_val(v_argc);
    /* the +1 is for the null terminal */
    argv = (char**) malloc(sizeof(char*) * (argc+1)); 
    for(i=0; i<argc; i++) 
    {
        char * arg = String_val(Field(v_argv, i));
        argv[i] = (char*) malloc(strlen(arg)+1);
        strcpy(argv[i], arg);
        argv[i][strlen(arg)] = '\0';
    }
    argv[argc] = NULL;

    glutInit(&argc, argv);

    /* 
    glutInit modifies argv, so we hand the result back to ocaml by repeatedly 
    calling a callback.  
    */
    for(i=0; i<argc; i++) {
        callback(*caml_named_value("add_arg"), copy_string(argv[i]));
    }

    /* clean up */
    for(i=0; i<argc; i++) {
        free(argv[i]);
    }
    free(argv);

    return Val_unit;
}


CAMLprim value native_glutInitDisplayMode(
    value double_buffer, 
    value index, 
    value accum,
    value alpha, 
    value depth,
    value stencil,
    value multisample,
    value stereo,
    value luminance)
{
    unsigned int acc = 0;
    acc |= Bool_val(double_buffer) ? GLUT_DOUBLE : 0; 
    acc |= Bool_val(index) ? GLUT_INDEX : 0; 
    acc |= Bool_val(accum) ? GLUT_ACCUM : 0;
    acc |= Bool_val(alpha) ? GLUT_RGBA : 0; 
    acc |= Bool_val(depth) ? GLUT_DEPTH : 0;
    acc |= Bool_val(stencil) ? GLUT_STENCIL : 0;
    acc |= Bool_val(multisample) ? GLUT_MULTISAMPLE : 0;
    acc |= Bool_val(stereo) ? GLUT_STEREO : 0;
    acc |= Bool_val(luminance) ? GLUT_LUMINANCE : 0;
    glutInitDisplayMode(acc);
    return Val_unit;
}

CAMLprim value bytecode_glutInitDisplayMode ( value * args, int num_args)
{
    assert(num_args == 9);
    native_glutInitDisplayMode(
        args[0],/*double_buffer*/
        args[1],/*index*/
        args[2],/*accum*/
        args[3],/*alpha*/
        args[4],/*depth*/
        args[5],/*stencil*/
        args[6],/*multisample*/
        args[7],/*stereo*/
        args[8] /*luminance*/
    );
    return Val_unit;
}


ML_1(glutDisplayFunc,Callback0)
ML_1(glutVisibilityFunc,Callback1)
ML_1_(glutCreateMenu,Callback1,Val_int)
ML_1(glutReshapeFunc,Callback2)
ML_1(glutKeyboardFunc,Callback3c)
ML_1(glutMotionFunc,Callback2)
ML_1(glutSpecialFunc,Callback3)
ML_1(glutPassiveMotionFunc, Callback2)
ML_1(glutEntryFunc, Callback1)
ML_1(glutMenuStateFunc, Callback1)
ML_1(glutSpaceballMotionFunc, Callback3)
ML_1(glutSpaceballRotateFunc, Callback3)
ML_1(glutSpaceballButtonFunc, Callback2)
ML_1(glutButtonBoxFunc, Callback2) 
ML_1(glutDialsFunc, Callback2)
ML_1(glutTabletMotionFunc, Callback2)
ML_1(glutTabletButtonFunc, Callback4)
ML_1(glutMenuStatusFunc, Callback3)
ML_1(glutOverlayDisplayFunc,Callback0)
ML_1(glutMouseFunc, Callback4)
ML_1(glutIdleFunc,Callback0)
ML_3(glutTimerFunc,Int_val,Callback1,Int_val)

CAMLprim value mlext_glutSetIdleFuncToNull( value unit )
{
    glutIdleFunc(NULL);
    return Val_unit;
}

/* font stuff */

/* integer code to font */
static void* i2font(int i)
{
  switch(i) { 
    case 0: return GLUT_STROKE_ROMAN; 
    case 1: return GLUT_STROKE_MONO_ROMAN; 
    case 2: return GLUT_BITMAP_9_BY_15; 
    case 3: return GLUT_BITMAP_8_BY_13; 
    case 4: return GLUT_BITMAP_TIMES_ROMAN_10; 
    case 5: return GLUT_BITMAP_TIMES_ROMAN_24; 
    case 6: return GLUT_BITMAP_HELVETICA_10; 
    case 7: return GLUT_BITMAP_HELVETICA_12; 
    case 8: return GLUT_BITMAP_HELVETICA_18; 
    default: {
      fprintf(stderr, "wrap_glut.c: unrecognized font. impossible...\n");
      fflush(stderr);
      exit(-1);
    }
  }
}

CAMLprim value mlext_glutBitmapCharacter(value font, value c)
{
  glutBitmapCharacter(i2font(Int_val(font)), Int_val(c));
  return Val_unit;
}

CAMLprim value mlext_glutBitmapWidth(value font, value c)
{
  return Val_int(glutBitmapWidth(i2font(Int_val(font)), Int_val(c)));
}

CAMLprim value mlext_glutStrokeCharacter(value font, value c)
{
  glutStrokeCharacter(i2font(Int_val(font)), Int_val(c)); 
  return Val_unit;
}

CAMLprim value mlext_glutStrokeWidth(value font, value c)
{
  return Val_int(glutStrokeWidth(i2font(Int_val(font)), Int_val(c)));
}

/* GLUT 4 functions included with GLUT 3.7 */
ML_1(glutInitDisplayString, String_val) 
ML_2(glutWarpPointer, Int_val, Int_val)

CAMLprim value mlext_glutBitmapLength(value font, value str)
{
  /* need to do something about the unsignedness of the chars expected? */
  return Val_int(glutBitmapLength(i2font(Int_val(font)), (unsigned char*) String_val(str)));
}

CAMLprim value mlext_glutStrokeLength(value font, value str)
{
  /* need to do something about the unsignedness of the chars expected? */
  return Val_int(glutStrokeLength(i2font(Int_val(font)), (unsigned char*) String_val(str)));
}

ML_1(glutWindowStatusFunc, Callback1)

ML_1(glutPostWindowRedisplay, Int_val)

ML_1(glutPostWindowOverlayRedisplay, Int_val)
ML_1(glutKeyboardUpFunc,  Callback3c)
ML_1(glutSpecialUpFunc,  Callback3)
ML_1(glutIgnoreKeyRepeat, Int_val)
ML_1(glutSetKeyRepeat, Int_val)
ML_2(glutJoystickFunc,Callback4u,Int_val)
ML_0(glutForceJoystickFunc)



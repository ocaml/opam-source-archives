(************** vector.ml ****************)


open Input_util
open Algebra
open Format

(****************************************************************************)
(*                          Module  Vector                                  *)
(****************************************************************************)

module type Dim =
  sig
    val dim : int
  end


module type Vector =
  sig
    include Vectorial_Space

    val (|.) : elem -> elem -> scalar
    val dim :  int               (* vector size *)
    val copy : elem -> elem           (* copy *)
    val vcreate : ((int -> scalar -> unit) -> unit) -> elem    (* create ... *)
    val from_array : scalar array -> elem
    val vget : elem -> int -> scalar
    val vput : elem -> int -> scalar -> unit
    val null : unit -> elem              (* null n : null vector of size n *)
    val init_null : elem -> unit        (* set a vector to zero *)
    val add : elem -> elem -> unit
    val sub : elem -> elem -> unit
    val mul_scal : scalar -> elem -> unit
    val mapq : (scalar -> scalar) -> elem -> unit
    val mapq2 : (scalar -> scalar -> scalar) -> elem -> elem -> unit
    val map : (scalar -> scalar) -> elem -> elem
    val map2 : (scalar -> scalar -> scalar) -> elem -> elem -> elem
  end

module type Normed_Vector =
  sig
    include Banach

    val dim :  int               (* vector size *)
    val copy : elem -> elem           (* copy *)
    val vcreate : ((int -> scalar -> unit) -> unit) -> elem    (* create ... *)
    val from_array : scalar array -> elem
    val vget : elem -> int -> scalar
    val vput : elem -> int -> scalar -> unit
    val null : unit -> elem              (* null n : null vector of size n *)
    val init_null : elem -> unit        (* set a vector to zero *)
    val add : elem -> elem -> unit
    val sub : elem -> elem -> unit
    val mul_scal : scalar -> elem -> unit
    val mapq : (scalar -> scalar) -> elem -> unit
    val mapq2 : (scalar -> scalar -> scalar) -> elem -> elem -> unit
    val map : (scalar -> scalar) -> elem -> elem
    val map2 : (scalar -> scalar -> scalar) -> elem -> elem -> elem
  end

module Make = functor (R : Ring) -> functor (D : Dim) ->
  struct

    open R

    type scalar = R.elem
    type elem = scalar array

    let dim = D.dim

    let copy = Array.copy

    let vcreate fn =
      let v = Array.make dim R.zero in
      let g i x = v.(i) <- x in
      let _ = fn g in
      v

    let from_array v =
      let w = Array.make dim R.zero in
      for i = 0 to dim - 1 do
        w.(i) <- v.(i)
      done;
      w

    let null () =
      Array.make dim R.zero

    let zero = null ()

    let parse str = failwith "not implemented"
    let read ch = parse (Stream.of_channel ch)

    let read_bin ch =
      input_value ch

    let vget v i =
      v.(i)
    let vput v i x =
      v.(i) <- x

    let init_null v =
      for i = 0 to (dim - 1) do
        v.(i) <- R.zero
      done

    let mul_scal x v =
      for i = 0 to (dim - 1) do
        v.(i) <- x ** v.(i)
      done

    let add v1 v2 =
      for i = 0 to (dim - 1) do
        v1.(i) <- v1.(i) ++ v2.(i)
      done

    let sub v1 v2 =
      for i = 0 to (dim - 1) do
        v1.(i) <- v1.(i) -- v2.(i)
      done

    let mapq fn v =
      for i = 0 to (dim - 1) do
        v.(i) <- fn v.(i)
      done

    let mapq2 fn v1 v2 =
      for i = 0 to (dim - 1) do
        v1.(i) <- fn v1.(i) v2.(i)
      done

    let write formatter p =
      pp_print_string formatter "[";
      pp_open_box formatter 2;
      pp_print_int formatter dim;
      pp_print_string formatter ":";
      for i= 0 to (dim-1) do
	if i <> 0 then pp_print_string formatter ",";
	pp_print_space formatter ();
	R.write formatter p.(i);
      done;
      pp_print_cut formatter ();
      pp_close_box formatter ();
      pp_print_string formatter "]"

    let print = write std_formatter


    let write_bin ch v =
      output_value ch v

    (* operation fonctionnelles sur les vecteurs *)

    let (++) v1 v2 =
      let r = Array.copy v1 in
      add r v2;
      r

    let (--) v1 v2 =
      let r = Array.copy v1 in
      sub r v2;
      r

    let map = Array.map

    let map2 fn v1 v2 =
      Array.init dim (fun i -> fn v1.(i) v2.(i))

    let opp v =
      map R.opp v

    let (@) scal v =
      map (fun x -> scal ** x) v

    let (==) v1 v2 =
      try
        for i = 0 to (dim-1) do
          if not (R.(==) v1.(i) v2.(i)) then raise Exit
        done; true
      with Exit -> false

    let normalize = map R.normalize

    let (|.) v1 v2 =
      let temp = ref R.zero in
      for i = 0 to (dim - 1) do
        temp := R.(++) !temp (R.( ** ) (R.conjugate v1.(i)) v2.(i))
      done;
      !temp

    let conjugate v = map R.conjugate v

  end



module Make_Normed =
  functor (R : Normed_Field) ->
  functor (D : Dim) ->
  struct
    module V = Make(R)(D)

    include V
    type norm = R.norm
    let norm v =
      let temp = ref R.zero_norm in
      for i = 0 to (dim - 1) do
        temp := R.add_norm !temp (R.norm (V.vget v i))
      done;
      !temp
    let abs v = R.sqrt (norm v)
  end



module Make_Cartesian_Product =
  functor (R : Ring) ->
  functor (V0 : Vector with type scalar = R.elem) ->
  functor (V1 : Vector with type scalar = R.elem) ->
struct

    let dim =  V0.dim + V1.dim
    module D = struct
      let dim = dim
    end

    type scalar = V0.scalar
    type elem = V0.elem * V1.elem

    let copy (v, v') = (V0.copy v, V1.copy v')
    let vcreate init = failwith "create not implemented"
    let from_array _ = failwith "from_array not implemented"
    let null () = (V0.null (), V1.null ())
    let zero = (V0.zero  , V1.zero) (* zero of vectorial space *)

    let parse str = failwith "create not implemented"
    let read ch = parse (Stream.of_channel ch)
    let read_bin = input_value


    let vget (v,v') i =
      if i < V0.dim then V0.vget v i else V1.vget v' (i-V0.dim)

    let vput (v,v') i x =
      if i < V0.dim then V0.vput v i x else V1.vput v' (i-V0.dim) x

    let init_null (v,v') =
      V0.init_null v; V1.init_null v'

    let mul_scal x (v,v') =
      V0.mul_scal x v; V1.mul_scal x v'

    let add (v1, v1') (v2, v2') =
      V0.add v1 v2; V1.add v1' v2'

    let sub (v1, v1') (v2, v2') =
      V0.sub v1 v2; V1.sub v1' v2'

    let mapq fn (v, v') =
      V0.mapq fn v; V1.mapq fn v'

    let mapq2 fn (v1, v1') (v2, v2') =
      V0.mapq2 fn v1 v2; V1.mapq2 fn v1' v2'

    let write formatter (v,v') =
      pp_open_box formatter 2;
      pp_print_string formatter "(";
      V0.write formatter v ;
      pp_print_string formatter ",";
      V1.write formatter v';
      pp_print_string formatter ")";
      pp_close_box formatter ()

    let print= write std_formatter

    let write_bin formatter (v, v') =
      V0.write_bin formatter  v ; V1.write_bin formatter v'

    let ( ++ ) (v1,v1') (v2,v2')  = (V0.(++) v1 v2 , V1.(++) v1' v2')

    let ( -- ) (v1,v1') (v2,v2')  = (V0.(--) v1 v2 , V1.(--) v1' v2')

    let map fn (v,v')= (V0.map fn v, V1.map fn v')

    let map2 fn (v1, v1') (v2, v2') = (V0.map2 fn v1 v2 ,V1.map2 fn v1' v2')

    let opp (v, v') = (V0.opp v , V1.opp v' )

    let (@) scal (v, v') = (V0.(@) scal v ,V1.(@) scal v')

    let (==) (v1, v1') (v2, v2') =
      V0.(==) v1 v2 && V1.(==) v1' v2'

    let normalize (v, v') = (V0.normalize v, V1.normalize v')

    let (|.) (v1,v1') (v2,v2') = R.(++) (V0.(|.) v1 v2) (V1.(|.) v1' v2')

    let conjugate (v, v') = V0.conjugate v, V1.conjugate v'
end



module Make_Normed_Cartesian_Product =
  functor (R : Normed_Field) ->
  functor (V0 : Normed_Vector
	   with type scalar = R.elem and type norm = R.norm) ->
  functor (V1 : Normed_Vector
	   with type scalar = R.elem and type norm = R.norm) ->
struct
  module V = Make_Cartesian_Product(R)(V0)(V1)

  include V
  type norm = R.norm
  let norm (v, v') = R.add_norm (V0.norm v) (V1.norm v')
  let abs c = R.sqrt (norm c)
end

(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Gl
open GlArray
open Vect3
open Format

let tex_ids = ref ([] : (([`alpha | `blue | `green | `luminance | `red ] * [`chessboard | `lines])
			 * GlTex.texture_id) list)

type texture = GlTex.texture_id * [`float] Raw.t * Gl.rgba
      * [ `blend | `decal | `modulate | `replace ]
type surface =
    {
     svertex : [`double] Raw.t;
     snormal : [`short] Raw.t;
     selements : [`uint] Raw.t;
     stexture : texture option
   }

type curve =
  {
     cvertex : [`double] Raw.t;
     celements : [`uint] Raw.t list;
     ctexture : texture option
  }

type points =
  {
     pvertex : [`double] Raw.t;
     pelements : [`uint] Raw.t;
  }

let write_obj_surface index ch s =
  let size = Raw.length s.svertex in

  for i = 0 to size/3 - 1 do
    let x = Raw.get_float s.svertex ~pos:(3*i) in
    let y = Raw.get_float s.svertex ~pos:(3*i+1) in
    let z = Raw.get_float s.svertex ~pos:(3*i+2) in
    Printf.fprintf ch "v %.12f %.12f %.12f\n" x y z;
  done;

  let size2 = Raw.length s.snormal in
  assert (size2=size);

  for i = 0 to size/3 - 1  do
    let x = float (Raw.get s.snormal ~pos:(3*i)) in
    let y = float (Raw.get s.snormal ~pos:(3*i+1)) in
    let z = float (Raw.get s.snormal ~pos:(3*i+2)) in
    let n = sqrt (x*.x +. y*.y +. z*.z) in
    let x = x /. n and y = y /. n and z = z /. n in
    Printf.fprintf ch "vn %f %f %f\n" x y z;
  done;

  let size_el = Raw.length s.selements in

  for i = 0 to size_el/3 - 1 do
    let a = Raw.get s.selements ~pos:(3*i)
    and b = Raw.get s.selements ~pos:(3*i+1)
    and c = Raw.get s.selements ~pos:(3*i+2) in
    Printf.fprintf ch "f %d//%d %d//%d %d//%d\n"
      (a + !index) (a + !index) (b + !index) (b + !index) (c + !index) (c + !index);
  done;

  index := !index + size/3

let write_obj_line index ch s =
  let size = Raw.length s.cvertex in

  for i = 0 to size/3 - 1 do
    let x = Raw.get_float s.cvertex ~pos:(3*i) in
    let y = Raw.get_float s.cvertex ~pos:(3*i+1) in
    let z = Raw.get_float s.cvertex ~pos:(3*i+2) in
    Printf.fprintf ch "v %.12f %.12f %.12f\n" x y z;
  done;

  List.iter (fun s ->
    let size = Raw.length s in
    Printf.fprintf ch "l";

    for i = 0 to size-1 do
      let a = Raw.get s ~pos:(i)  in
      Printf.fprintf ch " %d" (a + !index);
    done;
    Printf.fprintf ch "\n") s.celements;

  index := !index + size/3

let write_obj_point index ch s =
  let size = Raw.length s.pvertex in

  for i = 0 to size/3 - 1 do
    let x = Raw.get_float s.pvertex ~pos:(3*i) in
    let y = Raw.get_float s.pvertex ~pos:(3*i+1) in
    let z = Raw.get_float s.pvertex ~pos:(3*i+2) in
    Printf.fprintf ch "v %.12f %.12f %.12f\n" x y z;
  done;

  let s = s.pelements in
  let size = Raw.length s in
  Printf.fprintf ch "p";

  for i = 0 to size-1 do
    let a = Raw.get s ~pos:(i)  in
    Printf.fprintf ch " %d" (a + !index);
  done;
  Printf.fprintf ch "\n";
  index := !index + size

let raw_create k ~len:size =
  let t = Raw.create k ~len:size in
  Obj.set_field (Obj.repr t) 4 (Obj.repr true);
  t

exception Too_far

let all_iroots solve compute s =
  let (eval_fun,_,_) = compute in
  match s with None -> [] | Some s ->

  let res = ref [] in

  let rec do_triangle a b c =
    let center = (a ++ b ++ c) // 3.0 in
    let ca = (2.0/.3.0) ** a ++ (1.0 /. 3.0) ** center in
    let cb = (2.0/.3.0) ** b ++ (1.0 /. 3.0) ** center in
    let cc = (2.0/.3.0) ** c ++ (1.0 /. 3.0) ** center in
    let cab = (a ++ b ++ center) // 3.0 in
    let cac = (a ++ c ++ center) // 3.0 in
    let cbc = (b ++ c ++ center) // 3.0 in
    let r = max (norm (center -- a)) (max (norm (center -- b)) (norm (center -- c))) in
    try
      List.iter (fun x ->
	let tpl = solve compute (1.1 *. r) 5e-16 x in
	res := tpl :: !res) [center;ca;cb;cc;cab;cac;cbc]
    with
      Exit -> ()
  in
  let size = Raw.length s.selements in

  for i = 0 to size/3 - 1 do
    let a = Raw.get s.selements ~pos:(3*i)
    and b = Raw.get s.selements ~pos:(3*i+1)
    and c = Raw.get s.selements ~pos:(3*i+2) in
    let x1 = Raw.get_float s.svertex ~pos:(3*a) in
    let y1 = Raw.get_float s.svertex ~pos:(3*a+1) in
    let z1 = Raw.get_float s.svertex ~pos:(3*a+2) in
    let x2 = Raw.get_float s.svertex ~pos:(3*b) in
    let y2 = Raw.get_float s.svertex ~pos:(3*b+1) in
    let z2 = Raw.get_float s.svertex ~pos:(3*b+2) in
    let x3 = Raw.get_float s.svertex ~pos:(3*c) in
    let y3 = Raw.get_float s.svertex ~pos:(3*c+1) in
    let z3 = Raw.get_float s.svertex ~pos:(3*c+2) in
    do_triangle [|x1;y1;z1|] [|x2;y2;z2|] [|x3;y3;z3|];
    if i mod 10 = 0 then begin
      Printf.printf "\r %d%% of triangles          "
	(i * 300 / size);
      print_flush ()
    end
  done;
  print_newline ();

  let res = List.map (fun (a,b) -> a,b,1) !res in
  Printf.printf "kept %d points" (List.length res); print_newline ();
  let cmp (_,x,_) (_,y,_) = Pervasives.compare (abs_float x) (abs_float y) in
  let r = List.sort cmp res in
  let remove_id l =
    let rec fn acc = function
	[] -> List.rev acc
      | (xp,xf,xc) as x::l ->
	  let rec gn acc2 = function
	      [] ->
		fn (x::acc) l
	    | (yp,yf,yc) as y::acc ->
		let tot = xc + yc in
		if norm (xp -- yp) < 1e-7 then begin
		  let m = (float xc ** xp ++ float yc ** yp) // (float tot) in
		  let all = List.sort cmp [(m,eval_fun m,xc+yc);(xp,xf,tot);(yp,yf,tot)] in
		  fn (List.rev_append acc2 ((List.hd all)::acc)) l
		end else
		if norm (xp ++ yp) < 1e-7 then begin
		  let m = (float xc ** xp -- float yc ** yp) // (float tot) in
		  let all = List.sort cmp [(m,eval_fun m,xc+yc);(xp,xf,tot);(yp,yf,tot)] in
		  fn (List.rev_append acc2 ((List.hd all)::acc)) l
		end else
		  gn (y::acc2) acc
	  in
	  gn [] acc
    in
    fn [] l
  in
  let r = remove_id r in
  Printf.printf "regrouped in %d points" (List.length r); print_newline ();
(*  let r = List.map (fun (xp,xf,n) -> xp,xf) r in *)
  let r = List.map (fun (xp,xf,n) ->
    solve compute 10.0 5e-16 xp) r in
  Printf.printf "end solve"; print_newline ();

  r


let iter_surface fn s =
  let size = Raw.length s.selements in
  for i = 0 to size/3 - 1 do
    let x1 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i)) in
    let y1 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i)+1) in
    let z1 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i)+2) in
    let x2 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+1)) in
    let y2 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+1)+1) in
    let z2 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+1)+2) in
    let x3 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+2)) in
    let y3 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+2)+1) in
    let z3 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+2)+2) in
    fn [|x1;y1;z1|] [|x2;y2;z2|] [|x3;y3;z3|]
  done

let iter_surface_shared fn s =
  let gn i =
    let x1 = Raw.get_float s.svertex ~pos:(3*i) in
    let y1 = Raw.get_float s.svertex ~pos:(3*i+1) in
    let z1 = Raw.get_float s.svertex ~pos:(3*i+2) in
    [|x1;y1;z1|]
  in
  let allv = Array.init (Raw.length s.svertex / 3) gn in
  let size = Raw.length s.selements in
  for i = 0 to size/3 - 1 do
    let v1 = allv.(Raw.get s.selements ~pos:(3*i)) in
    let v2 = allv.(Raw.get s.selements ~pos:(3*i+1)) in
    let v3 = allv.(Raw.get s.selements ~pos:(3*i+2)) in
    fn v1 v2 v3
  done

let iter_surface_with_grad fn s =
  let size = Raw.length s.selements in
  for i = 0 to size/3 - 1 do
    let x1 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i)) in
    let y1 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i)+1) in
    let z1 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i)+2) in
    let x2 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+1)) in
    let y2 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+1)+1) in
    let z2 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+1)+2) in
    let x3 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+2)) in
    let y3 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+2)+1) in
    let z3 = Raw.get_float s.svertex ~pos:(3*Raw.get s.selements ~pos:(3*i+2)+2) in
    let x1' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i)) in
    let y1' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i)+1) in
    let z1' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i)+2) in
    let x2' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i+1)) in
    let y2' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i+1)+1) in
    let z2' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i+1)+2) in
    let x3' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i+2)) in
    let y3' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i+2)+1) in
    let z3' = Raw.get s.snormal ~pos:(3*Raw.get s.selements ~pos:(3*i+2)+2) in    fn [|x1;y1;z1|] [|x2;y2;z2|] [|x3;y3;z3|] [|x1';y1';z1'|] [|x2';y2';z2'|] [|x3';y3';z3'|]
  done


let triangles_to_surface texture grad tl =
  if tl = [] then None else
  let tbl = Hashtbl.create 10001 in
  let count = ref 0 in
  let find_point p =
    try
      Hashtbl.find tbl p
    with
      Not_found ->
	let r = !count, grad p in
	incr count;
	Hashtbl.add tbl p r;
	r

  in
  let selements = raw_create `uint (List.length tl * 3) in
  let pos = ref 0 in
  let treat_one_triangle (v1, v2, v3) =
    let i1, g1 = find_point v1 in
    let i2, g2 = find_point v2 in
    let i3, g3 = find_point v3 in
    if (vector_prod (v2 -- v1) (v3 -- v1) |. (g1 ++ g2 ++ g3)) > 0.0 then
      begin
	Raw.set selements ~pos:!pos i1;
	incr pos;
	Raw.set selements ~pos:!pos i2;
	incr pos;
	Raw.set selements ~pos:!pos i3;
	incr pos;
      end
    else
      begin
	Raw.set selements ~pos:!pos i3;
	incr pos;
	Raw.set selements ~pos:!pos i2;
	incr pos;
	Raw.set selements ~pos:!pos i1;
	incr pos;
      end
  in
  List.iter treat_one_triangle tl;
  let nb_vertex = !count in
  let svertex = raw_create `double (3*nb_vertex) in
  let snormal = raw_create `short (3*nb_vertex) in
  let make_grad index g =
    let [|x1;x2;x3|] as v' = 16383. ** g // norm g in
    let float_to_short x =
      if x <= -16383.0 then -16383 else
      if x >= 16383.0 then 16383 else
      truncate x
    in
    Raw.set snormal ~pos:(3*index) (float_to_short x1);
    Raw.set snormal ~pos:(3*index+1) (float_to_short x2);
    Raw.set snormal ~pos:(3*index+2) (float_to_short x3);
    let v = Array.map float (Raw.gets snormal ~pos:(3*index) ~len:3) in
    if (norm (v' -- v) > 3.0) then begin
      print_vector v;
      print_vector v';
      print_newline ();
      assert false
    end
  in
  let tex, do_tex = match texture with
    None -> None, (fun index p -> ())
  | Some (fmt,typ,evalx,evaly,evalz,c,mode) ->
      let id = List.assoc (fmt,typ) !tex_ids in
      let table = raw_create `float ~len:(nb_vertex*3) in
      Some(id,table,c,mode),
      fun index p ->
	Raw.set_float table (3*index) (evalx p);
	Raw.set_float table (3*index+1) (evaly p);
	Raw.set_float table (3*index+2) (evalz p)
  in
  let treat_one_vertex p (index,g) =
    Raw.sets_float svertex ~pos:(3*index) p;
    make_grad index (grad p);
    do_tex index p
  in
  Hashtbl.iter treat_one_vertex tbl;

  let s = {selements = selements;
	   snormal = snormal;
	   stexture = tex;
	   svertex = svertex} in
  Some s

exception Found of int

let triangles_to_polytope vl tl =
  if tl = [] then None else
  (* need to duplicate vertices because of distinct normals *)
  let svertices = raw_create `double (List.length tl * 9) in
  let snormal = raw_create `short (List.length tl * 9) in
  let selements = raw_create `uint (List.length tl * 3) in
  let va = Array.of_list vl in
  let make_grad index g =
    let [|x1;x2;x3|] = 16383. ** g // norm g in
    let float_to_ushort x =
      let r =
	if x <= -16383.0 then -16383 else
	if x >= 16383.0 then 16383 else
	truncate x
      in
      r
    in
    Raw.set snormal ~pos:(3*index) (float_to_ushort x1);
    Raw.set snormal ~pos:(3*index+1) (float_to_ushort x2);
    Raw.set snormal ~pos:(3*index+2) (float_to_ushort x3)
  in
  let treat_one_vertex index [|x;y;z|] g =
    Raw.set selements index index;
    Raw.set_float svertices ~pos:(3*index) x;
    Raw.set_float svertices ~pos:(3*index+1) y;
    Raw.set_float svertices ~pos:(3*index+2) z;
    make_grad index g
  in
  let pos = ref 0 in
  let fn (i1,i2,i3) =
    let [|x1;y1;z1|] as p1 = va.(i1) in
    let [|x2;y2;z2|] as p2 = va.(i2) in
    let [|x2;y3;z3|] as p3 = va.(i3) in
    let g = vector_prod (p2 -- p1) (p3 -- p1) in
    treat_one_vertex !pos p1 g;
    incr pos;
    treat_one_vertex !pos p2 g;
    incr pos;
    treat_one_vertex !pos p3 g;
    incr pos;
  in
  List.iter fn tl;
  let c = {selements = selements; stexture = None; snormal = snormal; svertex = svertices} in
  Some c

let object_to_curve_and_points vl tl pl =
  if tl = [] && pl = [] then None, None else
  let nb_vertex = List.length vl in
  let cvertex = raw_create `double (3*nb_vertex) in
  let index = ref 0 in
  let treat_one_vertex [|x;y;z|]  =
    Raw.set_float cvertex ~pos:!index x;
    incr index;
    Raw.set_float cvertex ~pos:!index y;
    incr index;
    Raw.set_float cvertex ~pos:!index z;
    incr index
  in
  List.iter treat_one_vertex vl;
  let tl = match tl with
    [] -> None
  | _ ->
      let celements = List.map (fun a ->
				  let size = List.length a in
				  let el = raw_create `uint size in
				  ignore (List.fold_left (fun i x -> Raw.set el i x; i + 1) 0 a);
				  el) tl
      in
      let c = {cvertex = cvertex; ctexture = None; celements = celements } in
      Some c
  in
  let pl = match pl with
    [] -> None
  | _ ->
      let pelements =
	let size = List.length pl in
	let el = raw_create `uint size in
	ignore (List.fold_left (fun i x -> Raw.set el i x; i + 1) 0 pl);
	el
      in
      let c = {pvertex = cvertex; pelements = pelements } in
      Some c
  in
  tl, pl

let lines_to_curve tl =
  if tl = [] then None else
  let tbl = Hashtbl.create 10001 in
  let count = ref 0 in
  let find_points (p1, p2) =
    if p1 != p2 then
    let l1,i1 =
	   try Hashtbl.find tbl p1
	   with Not_found -> let r = [], !count in incr count; r
    in
    let l2,i2 =
	   try Hashtbl.find tbl p2
	   with Not_found -> let r = [], !count in incr count; r
    in
    let l2 = i1::l2 in
    let l1 = i2::l1 in
    Hashtbl.replace tbl p1 (l1, i1);
    Hashtbl.replace tbl p2 (l2, i2)
  in
  List.iter find_points tl;
(*
    Printf.printf "%d : %d at (%f,%f,%f)\n" i (List.length l) v1 v2 v3) tbl;
*)
  let nb_vertex = !count in
  let svertex = raw_create `double (3*nb_vertex) in
  let neighbors = Array.make nb_vertex [] in
  let treat_one_vertex ([|v1;v2;v3|]) (l,index) =
    Raw.set_float svertex ~pos:(3*index) v1;
    Raw.set_float svertex ~pos:(3*index+1) v2;
    Raw.set_float svertex ~pos:(3*index+2) v3;
    neighbors.(index) <- l
  in
  Hashtbl.iter treat_one_vertex tbl;
  Hashtbl.clear tbl;
  let first = ref 0 in
  let rec get_one () =
    if !first >= nb_vertex then None else
    if neighbors.(!first) <> [] then Some !first else (incr first; get_one ())
  in
  let get_next k =
    let l = neighbors.(k) in
    match l with
      [] -> None
    | n::l ->
      neighbors.(k) <- l;
      let l' = neighbors.(n) in
      let l' = List.filter (fun i -> i <> k) l' in
      neighbors.(n) <- l';
      Some n
  in
  let rec fn all =
    let rec gn acc i =
      match get_next i with
	None -> acc
      | Some j -> gn (j::acc) j
    in
    match get_one () with
      None -> all
    | Some i ->
	let l = gn [i] i in
	let l' = gn [] i in
	let l = List.rev_append (List.rev l) (List.rev l') in
	let elements = raw_create `uint (List.length l) in
	let pos = ref 0 in
	List.iter (fun i -> Raw.set elements ~pos:!pos i; incr pos) l;
	fn (elements::all)
  in
  let c = {celements = fn  []; ctexture = None; cvertex = svertex} in
  Some c

let drawSurface do_tex s =
  GlArray.enable `vertex;
  GlArray.vertex `three s.svertex;
  GlArray.enable `normal;
  GlArray.normal s.snormal;
  if do_tex then begin match s.stexture with
    None -> ()
  | Some (i,tbl,c,mode) ->
      GlArray.enable `texture_coord;
      GlExt.enable `texture_3d;
      GlExt.bind_texture `texture_3d i;
      GlTex.env (`mode mode);
      GlTex.env (`color c);
      GlArray.tex_coord `three tbl;
  end;
  GlArray.draw_elements `triangles (Raw.length s.selements) s.selements;
  GlArray.disable `vertex;
  GlArray.disable `normal;
  GlExt.disable `texture_3d;
  GlArray.disable `texture_coord

let drawCurve s =
  GlArray.enable `vertex;
  GlArray.vertex `three s.cvertex;
  begin match s.ctexture with
    None -> ()
  | Some (i,tbl,c,mode) ->
      GlArray.enable `texture_coord;
      GlExt.enable `texture_3d;
      GlExt.bind_texture `texture_3d i;
      GlTex.env (`mode mode);
      GlTex.env (`color c);
      GlArray.tex_coord `three tbl;
  end;
  List.iter (fun e ->
    GlArray.draw_elements `line_strip (Raw.length e) e)
    s.celements;
  GlArray.disable `vertex;
  GlExt.disable `texture_3d;
  GlArray.disable `texture_coord

let drawCurveasPoints s =
  GlArray.enable `vertex;
  GlArray.vertex `three s.cvertex;
  List.iter (fun e -> GlArray.draw_elements `points (Raw.length e) e)
    s.celements;
  GlArray.disable `vertex

let drawPoints s =
  GlArray.enable `vertex;
  GlArray.vertex `three s.pvertex;
  GlArray.draw_elements `points (Raw.length s.pelements) s.pelements;
  GlArray.disable `vertex

let write_texture ch = function
    None -> output_value ch false
  | Some(i,t,c,m) ->
      output_value ch true;
      output_value ch i;
      output_value ch c;
      output_value ch m;
      output_value ch (Raw.length t);
      output_value ch (Raw.gets_float ~pos:0 ~len:(Raw.length t) t)

let read_texture ch =
  let b = input_value ch in
  if b then begin
    let i = input_value ch in
    let c = input_value ch in
    let m = input_value ch in
    let size = input_value ch in
    let t = raw_create `float size in
    let fs = input_value ch in
    Raw.sets_float ~pos:0 t fs;
    Some(i,t,c,m)
  end else None

let write_surface ch a =
  match a with
    None -> output_value ch false
  | Some a ->
      output_value ch true;
      output_value ch (Raw.length a.svertex);
      output_value ch (Raw.length a.selements);
      output_value ch (Raw.gets_float ~pos:0 ~len:(Raw.length a.svertex)
			 a.svertex);
      output_value ch (Raw.gets ~pos:0 ~len:(Raw.length a.snormal)
			 a.snormal);
      output_value ch (Raw.gets ~pos:0 ~len:(Raw.length a.selements)
			 a.selements);
      write_texture ch a.stexture

let read_surface ch =
  let none = input_value ch in
  if none then
    let lv = input_value ch in
    let le = input_value ch in
    let v = raw_create `double lv in
    let n = raw_create `short lv in
    let e = raw_create `uint le in
    Raw.sets_float v 0 (input_value ch);
    Raw.sets n 0 (input_value ch);
    Raw.sets e 0 (input_value ch);
    let tex = read_texture ch in
    let s = { svertex = v; snormal = n; selements = e; stexture = tex } in
    Some s
  else
    None

let write_curve ch a =
  match a with
    None -> output_value ch false
  | Some a ->
      output_value ch true;
      output_value ch (Raw.length a.cvertex);
      output_value ch (List.length a.celements);
      output_value ch (Raw.gets_float ~pos:0 ~len:(Raw.length a.cvertex)
			 a.cvertex);
      List.iter (fun e ->
        output_value ch (Raw.length e);
        output_value ch (Raw.gets ~pos:0 ~len:(Raw.length e) e))
			 a.celements;
      write_texture ch a.ctexture

let read_curve ch =
  let none = input_value ch in
  if none then
    let lv = input_value ch in
    let ne = input_value ch in
    let v = raw_create `double lv in
    Raw.sets_float v 0 (input_value ch);
    let rec fn all i =
      if i = 0 then all else
      let le = input_value ch in
      let e = raw_create `uint le in
      Raw.sets e 0 (input_value ch);
      fn (e::all) (i - 1)
    in
    let tex = read_texture ch in
    let s = { cvertex = v; celements = fn [] ne; ctexture = tex } in
    Some s
  else
    None

let write_points ch a =
  match a with
    None -> output_value ch false
  | Some a ->
      output_value ch true;
      output_value ch (Raw.length a.pelements);
      output_value ch (Raw.gets ~pos:0 ~len:(Raw.length a.pelements)
			 a.pelements);
      output_value ch (Raw.length a.pvertex);
      output_value ch (Raw.gets_float ~pos:0 ~len:(Raw.length a.pvertex)
			 a.pvertex)

let read_points ch =
  let none = input_value ch in
  if none then
    let lv = input_value ch in
    let el = raw_create `uint lv in
    Raw.sets el 0 (input_value ch);
    let lv = input_value ch in
    let vs = raw_create `double lv in
    Raw.sets_float vs 0 (input_value ch);
    let s = { pvertex = vs; pelements = el } in
    Some s
  else
    None

(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004, 2005 Christohe Raffalli                          *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Vect3
open Glarrays
open Parameters
open Target

module Expr = Function.Expr

let batch = ref false
let file_prefix = ref "image"
let file_format = ref "png"
let pov_surface_texture = ref ""
let pov_line_texture = ref ""
let pov_point_texture = ref ""
let pov_preambule = ref ""
let pov_pixels = ref 0
let pov_aliasing = ref 0.3
let pov_import_light = ref false
let background = ref (0.,0.,0.)
let lmodel_twosides = ref true
let inflate_key = ref "a"
let inflate_code = ref ""
let inflate_fake_topology = ref "None"

let main_window = ref 0

let string_params = [
  ("file_prefix", file_prefix);
  ("file_format", file_format);
  ("pov_surface_texture", pov_surface_texture);
  ("pov_line_texture", pov_line_texture);
  ("pov_point_texture", pov_point_texture);
  ("pov_preambule", pov_preambule);
  ("inflate_key", inflate_key);
  ("inflate_code", inflate_code);
  ("inflate_fake_topology", inflate_fake_topology);
]

let float_params = [
  ("pov_aliasing", pov_aliasing)
]

let int_params = [
  ("pov_pixels", pov_pixels)
]

let bool_params = [
  ("pov_import_light", pov_import_light)
]

let file_count = ref 0
let badt = ref []

let cube_edges = ref None

let rec filename file_format =
  incr file_count ;
  let name = !file_prefix^(string_of_int !file_count)^"."^ file_format in
  if Sys.file_exists name then filename file_format else name

let glDraw_triangle grad (v1, v2, v3) =
  let g1 = grad v1 in
  let g2 = grad v2 in
  let g3 = grad v3 in
  if (vector_prod (v2 -- v1) (v3 -- v1) |. (g1 ++ g2 ++ g3)) > 0.0 then
    begin
      GlDraw.normal ~x:g1.(0) ~y:g1.(1) ~z:g1.(2)();
      GlDraw.vertex ~x:v1.(0) ~y:v1.(1) ~z:v1.(2)();
      GlDraw.normal ~x:g2.(0) ~y:g2.(1) ~z:g2.(2)();
      GlDraw.vertex ~x:v2.(0) ~y:v2.(1) ~z:v2.(2)();
      GlDraw.normal ~x:g3.(0) ~y:g3.(1) ~z:g3.(2)();
      GlDraw.vertex ~x:v3.(0) ~y:v3.(1) ~z:v3.(2)();
    end else begin
      GlDraw.normal ~x:g1.(0) ~y:g1.(1) ~z:g1.(2)();
      GlDraw.vertex ~x:v1.(0) ~y:v1.(1) ~z:v1.(2)();
      GlDraw.normal ~x:g3.(0) ~y:g3.(1) ~z:g3.(2)();
      GlDraw.vertex ~x:v3.(0) ~y:v3.(1) ~z:v3.(2)();
      GlDraw.normal ~x:g2.(0) ~y:g2.(1) ~z:g2.(2)();
      GlDraw.vertex ~x:v2.(0) ~y:v2.(1) ~z:v2.(2)();
    end

let glDraw_simple_triangle (v1, v2, v3) =
  GlDraw.vertex ~x:v1.(0) ~y:v1.(1) ~z:v1.(2)();
  GlDraw.vertex ~x:v2.(0) ~y:v2.(1) ~z:v2.(2)();
  GlDraw.vertex ~x:v3.(0) ~y:v3.(1) ~z:v3.(2)()

let glDraw_grad grad (v1, v2, v3) =
  let g1 = v1 ++ 0.2 ** grad v1 in
  let g2 = v2 ++ 0.2 ** grad v2 in
  let g3 = v3 ++ 0.2 ** grad v3 in
  GlDraw.vertex ~x:g1.(0) ~y:g1.(1) ~z:g1.(2)();
  GlDraw.vertex ~x:v1.(0) ~y:v1.(1) ~z:v1.(2)();
  GlDraw.vertex ~x:g2.(0) ~y:g2.(1) ~z:g2.(2)();
  GlDraw.vertex ~x:v2.(0) ~y:v2.(1) ~z:v2.(2)();
  GlDraw.vertex ~x:g3.(0) ~y:g3.(1) ~z:g3.(2)();
  GlDraw.vertex ~x:v3.(0) ~y:v3.(1) ~z:v3.(2)()

let all_surfaces = ref (([] : Parameters.surface list), ([] : Parameters.surface list))

type message = {
    message : string;
    message_x : int;
    message_y : int;
    message_color : float * float * float;
  }

let all_messages = ref []
let waiting = ref false
let wait_message = { message_x = 60; message_y = 0; message_color = (0.5,0.5,0.5);
		     message = "Press N to continue" }



let gl_origin = ref [|0.0;0.0;0.0|]
let gl_size = ref 1.0
let eye = ref (!gl_origin ++ [|0.0;0.0;2.0 *. !gl_size|])
let up = ref [|0.0;1.0;0.0|]
let front = ref [|0.0;0.0;-1.0|]
let right = ref [|1.0;0.0;0.0|]
let speed = ref (!gl_size /. 10.0) (*in one second*)
let step = pi/.10.0                (*in one second*)
let speed_hfactor = ref 1.0
let speed_vfactor = ref 1.0
let speed_vafactor = ref 1.0
let speed_hafactor = ref 1.0
let draw_edge = ref false
let last_time = ref (Unix.gettimeofday ())

let lights_on = [|true; true; false; false; false; false; false; false|]
let lights_param =
  [|
    {
     light_position = 0.8, 0.8, 1.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
    {
     light_position = -0.8, -0.8, 1.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
    {
     light_position = 0.0, 0.0, 0.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
    {
     light_position = 0.0, 0.0, 0.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
    {
     light_position = 0.0, 0.0, 0.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
    {
     light_position = 0.0, 0.0, 0.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
    {
     light_position = 0.0, 0.0, 0.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
    {
     light_position = 0.0, 0.0, 0.0, 0.0;
     light_ambient = 0.2,0.2,0.2,1.0;
     light_diffuse = 1.0,1.0,1.0,1.0;
     light_specular = 0.8,0.8,0.8,0.8;
   };
  |]

let do_light f index =
  match index with
  | 0 -> f `light0
  | 1 -> f `light1
  | 2 -> f `light2
  | 3 -> f `light3
  | 4 -> f `light4
  | 5 -> f `light5
  | 6 -> f `light6
  | 7 -> f `light7
  | _ -> failwith ("Illegal light number: " ^ (string_of_int index))


let set_lights () =
  for num = 0 to 7 do
    if lights_on.(num) then begin
      let l = lights_param.(num) in
      GlLight.light ~num (`ambient l.light_ambient);
      GlLight.light ~num (`diffuse l.light_diffuse);
      GlLight.light ~num (`specular l.light_specular);
      GlLight.light ~num (`position l.light_position);
      do_light Gl.enable num
    end else
      do_light Gl.disable num
  done

let init_pos () =
  eye := (!gl_origin ++ [|0.0;0.0;2.0 *. !gl_size|]);
  up := [|0.0;1.0;0.0|];
  front := [|0.0;0.0;-1.0|];
  right := [|1.0;0.0;0.0|];
  speed := (!gl_size /. 10.0);
  speed_hfactor := 1.0;
  speed_vfactor := 1.0;
  speed_hafactor := 1.0;
  speed_vafactor := 1.0;
  last_time := Unix.gettimeofday ()

let moving_right = ref false
let moving_left = ref false
let moving_up = ref false
let moving_down = ref false
let moving_back = ref false
let moving_forward = ref false
let moving_rleft = ref false
let moving_rright = ref false

let rotate_right = ref false
let rotate_left = ref false
let rotate_up = ref false
let rotate_down = ref false

let slide_right = ref false
let slide_left = ref false
let slide_up = ref false
let slide_down = ref false

let active () = !moving_right || !moving_left  || !moving_up || !moving_down || !moving_back || !moving_forward || !moving_rleft || !moving_rright || !rotate_right || !rotate_left || !rotate_up || !rotate_down || !slide_right || !slide_left || !slide_up || !slide_down
let curve_mode = ref false

let init_target_pos () =
  let p = !eye ++ 20.0 ** !speed ** !front in
  target := Some p;
  p


let interval = 50

let last_interaction = ref (Unix.gettimeofday ())

let did_interaction () =
  last_interaction := Unix.gettimeofday ()

let update_pos () =
  Cbglut.setWindow !main_window;
  let old_time = !last_time in
  last_time := Unix.gettimeofday ();
  if active () then begin
    did_interaction ();
    let delta = !last_time -. old_time in
    let hstep = delta *. step *. !speed_hfactor in
    let vstep = delta *. step *. !speed_vfactor in
    let hadvance = delta *. !speed *. !speed_hafactor in
    let vadvance = delta *. !speed *. !speed_vafactor in
    let hadvance =
      if !curve_mode then
	!eye.(2) *. hadvance /. (1.0 +. vadvance)
      else hadvance
    in
    let vadvance =
      if !curve_mode then
	!eye.(2) *. vadvance /. (1.0 +. vadvance)
      else vadvance
    in
    if !rotate_left then begin
      let nfront = cos(hstep) ** !front -- sin(hstep) ** !right in
      let nright = cos(hstep) ** !right ++ sin(hstep) ** !front in
      eye := !eye ++ 20.0 ** !speed ** !front -- 20.0 ** !speed ** nfront;
      right := nright;
      front := nfront;
    end;
    if !rotate_right then begin
      let nfront = cos(hstep) ** !front ++ sin(hstep) ** !right in
      let nright = cos(hstep) ** !right -- sin(hstep) ** !front in
      eye := !eye ++ 20.0 ** !speed ** !front -- 20.0 ** !speed ** nfront;
      right := nright;
      front := nfront;
    end;
    if !rotate_up then begin
      let nfront = cos(vstep) ** !front ++ sin(vstep) ** !up in
      let nup = cos(vstep) ** !up -- sin(vstep) ** !front in
      eye := !eye ++ 20.0 ** !speed ** !front -- 20.0 ** !speed ** nfront;
      up := nup;
      front := nfront;
    end;
    if !rotate_down then begin
      let nfront = cos(vstep) ** !front -- sin(vstep) ** !up in
      let nup = cos(vstep) ** !up ++ sin(vstep) ** !front in
      eye := !eye ++ 20.0 ** !speed ** !front -- 20.0 ** !speed ** nfront;
      up := nup;
      front := nfront;
    end;
    if !slide_left then begin
      eye := !eye -- hadvance ** !right;
    end;
    if !slide_right then begin
      eye := !eye ++ hadvance ** !right;
    end;
    if !slide_up then begin
      eye := !eye ++ vadvance ** !up;
    end;
    if !slide_down then begin
      eye := !eye -- vadvance ** !up;
    end;
    if !moving_rleft then begin
      let nup = cos(hstep) ** !up -- sin(hstep) ** !right in
      let nright = cos(hstep) ** !right ++ sin(hstep) ** !up in
      up := nup; right := nright;
    end;
    if !moving_rright then begin
      let nup = cos(hstep) ** !up ++ sin(hstep) ** !right in
      let nright = cos(hstep) ** !right -- sin(hstep) ** !up in
      up := nup; right := nright;
    end;
    if !moving_up then begin
      let vstep = vstep /. 2. in
      let nup = cos(vstep) ** !up ++ sin(vstep) ** !front in
      let nfront = cos(vstep) ** !front -- sin(vstep) ** !up in
      up := nup; front := nfront;
    end;
    if !moving_down then begin
      let vstep = vstep /. 2. in
      let nup = cos(vstep) ** !up -- sin(vstep) ** !front in
      let nfront = cos(vstep) ** !front ++ sin(vstep) ** !up in
      up := nup; front := nfront;
    end;
    if !moving_left then begin
      let nright = cos(hstep) ** !right ++ sin(hstep) ** !front in
      let nfront = cos(hstep) ** !front -- sin(hstep) ** !right in
      right := nright; front := nfront;
    end;
    if !moving_right then begin
      let nright = cos(hstep) ** !right -- sin(hstep) ** !front in
      let nfront = cos(hstep) ** !front ++ sin(hstep) ** !right in
      right := nright; front := nfront;
    end;
    if !moving_forward then begin
      eye := !eye ++ vadvance ** !front;
    end;
    if !moving_back then begin
      eye := !eye -- vadvance ** !front;
    end;
    Cbglut.postRedisplay ();
  end

let cur_width = ref 600
let cur_height = ref 600


external readPosition : int -> int -> float array =  "readPosition"

let save_image name =
  print_string ("saving image: "^name^" ... "); flush stdout;
  let w = !cur_width and h = !cur_height in
  let pixmap =
    GlPix.read ~x:0 ~y:0 ~width:w ~height:h ~format:`rgb ~kind:`ubyte in
  let raw =
    GlPix.to_raw pixmap in
  let image = Rgb24.create w h in
  for i = 0 to w - 1 do
    for j = 0 to h - 1 do
      match Raw.gets raw ~pos:(3*(j*w+i)) ~len:3 with
	[|r;g;b|] ->
	  Rgb24.set image i (h-1-j) {Color.r = r; Color.g = g; Color.b = b}
      | _ ->
	  assert false
    done;
  done;
  try
    Images.save name None [] (Images.Rgb24 image);
    print_string "Done.";
    print_newline ();
  with
    e ->
      prerr_newline ();
      prerr_string (Printexc.to_string e); prerr_newline ();
      Printexc.print_backtrace stderr; prerr_newline ()

(* povray *)

let povray () =
  let ratio = (float) !cur_height /. (float) !cur_width in
  let pixels = match !pov_pixels with
    0 -> !cur_width
  | n -> n
  in
  let pv ch [|x;y;z|] =
    Printf.fprintf ch "<%.15e,%.15e,%.15e>" x y z
  in
  let write_camera ch =
    Printf.fprintf ch "camera {\n  location %a\n  direction %a\n  up %a\n  right %a\n angle 45\n}\n"
      pv !eye
      pv !front
      pv (ratio ** !up)
      pv !right;
  in
  let write_light ch num =
    if lights_on.(num) then begin
      let l = lights_param.(num) in
      let (r,g,b,_) = l.light_diffuse in
      let (x,y,z,t) = l.light_position in
      let m = if abs_float t < 1e-10 then 1e10  else 1. /. t in
      let p = !eye ++ m ** (x ** !right -- z ** !front ++ y ** !up) in
      Printf.fprintf ch "light_source { %a color rgb <%f,%f,%f> }\n" pv p r g b
    end
  in

  let poly_to_pov_poly ch su =
    let l = Expr.decompose_poly su.poly in
    let degree_monome m =
      let fn acc (v,i) = acc+i in
      List.fold_left fn 0 m
    in
    let degree l =
      let fn acc (c,m) = max acc (degree_monome m) in
      List.fold_left fn 0 l
    in
    let d = degree l in
    if d <= 0 || d > 15 then raise Exit;
    let rec cmp l l' = match l, l' with
    | [], [] -> 0
    | _ , [] -> 1
    | [], _ ->  -1
    | (v,n)::l,(v',n')::l' when v = v' ->
	let r = cmp l l' in
	if r = 0 then n - n' else r
    | (v,_)::l,(v',_)::_ when v > v' ->
	let r = cmp l l' in
	if r = 0 then 1 else r
    | (v,n)::_,(v',n')::l' ->
	let r = cmp l l' in
	if r = 0 then -1 else r
    in
    let lp = ref [] in
    let l = ref (List.sort (fun (_,x) (_,y) -> cmp x y) l) in
    for dx = 0 to d do
      for dy = 0 to d - dx do
        for dz = 0 to d - dx - dy do
	  let conc v i l = if i = 0 then l else (v,i)::l in
          let m = conc "z" dz (conc "y" dy (conc "x" dx [])) in
	  let rec search = function
	      (c,m')::ls when m = m' -> lp := c::!lp; l := ls
	    | _ -> lp := 0.0::!lp
	  in
	  search !l
	done
      done
    done;
    assert (!l = []);
    let rec fn ch = function
      [] -> ()
    | x::[] -> Printf.fprintf ch "%.15e" x
    | x::l -> Printf.fprintf ch "%.15e, " x; fn ch l
    in
    if d = 1 then begin
      match !lp with
	[a;b;c;d] ->
	  Printf.fprintf ch "plane { <%.15e,%.15e,%.15e>, %.15e\n"
	    a b c (-.d/.sqrt(a*.a+.b*.b+.c*.c));
      | _ -> assert false
    end else begin
      Printf.fprintf ch "poly { %d, <%a>\n  sturm\n" d fn !lp;
    end;
    Printf.fprintf ch "  clipped_by { box { %a %a }}\n"
      pv (su.sorigin ++ (su.ssize /. 2.) ** [|1.;1.;1.|])
      pv (su.sorigin ++ (su.ssize /. 2.) ** [|-1.;-1.;-1.|])
  in

  let pov_iso ch su =
    let max_gradient =
      match su.ts with None -> assert false | Some s ->
      let mg = ref 0.0 in
      let size = Raw.length s.svertex / 3 in
      for i = 0 to size - 1 do
	let p = Raw.gets_float s.svertex ~pos:(3*i) ~len:3 in
	let ng = norm (su.grad p) in
	if !mg < ng then mg := ng
      done;
      !mg
    in
    Printf.fprintf ch "isosurface {\n  function {";
    let save = !Expr.print_mode in
    Expr.print_mode := `C;
    let out = formatter_of_out_channel ch in
    Expr.write out su.poly;
    pp_print_newline out ();
    Expr.print_mode := save;
    Printf.fprintf ch "\n}\n  contained_by { box { %a %a }}\n"
      pv (su.sorigin ++ (su.ssize /. 2.) ** [|1.;1.;1.|])
      pv (su.sorigin ++ (su.ssize /. 2.) ** [|-1.;-1.;-1.|]);
    Printf.fprintf ch "  evaluate %e,%e,%e\n  open\n" max_gradient (max_gradient*.max_gradient) 0.5
  in

  let write_mesh2 ch su = match su.ts with None -> () | Some s ->
    begin
      try
	if not su.pov_poly then raise Exit;
	poly_to_pov_poly ch su;
      with Exit ->
	if su.pov_isosurface then pov_iso ch su else begin
	Printf.fprintf ch "mesh2 {\n  vertex_vectors {\n";
	let size = Raw.length s.svertex / 3 in
	Printf.fprintf ch "    %d" size;
	for i = 0 to size - 1 do
	  Printf.fprintf ch ",\n    <%.15e,%.15e,%.15e>"
	    (Raw.get_float s.svertex ~pos:(3*i))
	    (Raw.get_float s.svertex ~pos:(3*i+1))
	    (Raw.get_float s.svertex ~pos:(3*i+2))
	done;
	Printf.fprintf ch "\n  }";
	Printf.fprintf ch "  normal_vectors {\n";
	let size' = Raw.length s.snormal / 3 in
	assert (size = size');
	Printf.fprintf ch "    %d" size';
	for i = 0 to size' - 1 do
	  let x1 = Raw.get s.snormal ~pos:(3*i) in
	  let x2 = Raw.get s.snormal ~pos:(3*i+1) in
	  let x3 = Raw.get s.snormal ~pos:(3*i+2) in
	  Printf.fprintf ch ",\n    <%d,%d,%d>" x1 x2 x3
	done;
	Printf.fprintf ch "\n  }";
	Printf.fprintf ch "  face_indices {\n";
	let size = Raw.length s.selements / 3 in
	Printf.fprintf ch "    %d" size;
	for i = 0 to size - 1 do
	  Printf.fprintf ch ",\n    <%d,%d,%d>"
	    (Raw.get s.selements ~pos:(3*i))
	    (Raw.get s.selements ~pos:(3*i+1))
	    (Raw.get s.selements ~pos:(3*i+2))
	done;
	Printf.fprintf ch "\n  }\n";
      end end;
    begin match su.pov_surface_texture with
      "" ->
	let (r,g,b,a) = su.front_diffuse in
	Printf.fprintf ch "  texture {\n    pigment { color rgb <%f,%f,%f> transmit %f }\n"
	  r g b (if su.transparent then sqrt(1.0 -. a) else 0.0);
	let (rs,gs,bs,_) = su.front_specular in
	let (ra,ga,ba,_) = su.front_specular in
	Printf.fprintf ch "    finish { phong %f ambient rgb <%f,%f,%f>}\n  }\n" ((rs+.gs+.bs)/.3.) ra ga ba;
	if !lmodel_twosides then begin
	  let (r,g,b,a) = su.back_diffuse in
	  Printf.fprintf ch "  interior_texture {\n    pigment { color rgb <%f,%f,%f> transmit %f }\n"
	    r g b (if su.transparent then sqrt(1.0 -. a) else 0.0);
	  let (rs,gs,bs,_) = su.back_specular in
	  let (ra,ga,ba,_) = su.back_specular in
	  Printf.fprintf ch "    finish { phong %f ambient rgb <%f,%f,%f>}\n  }\n" ((rs+.gs+.bs)/.3.) ra ga ba;
	end;
    | s -> Printf.fprintf ch "%s\n" s
    end;
    Printf.fprintf ch "}\n";
  in
  let write_curve ch su = match su.es with None -> () | Some s ->
    let coef = tan (pi /. 4. /. float pixels) *.
	su.line_width /. 2. in
    Printf.fprintf ch "union {\n  ";
    let size = Raw.length s.cvertex in
    for i = 0 to size/3 - 1 do
      let x1 = Raw.gets_float s.cvertex (3*i) 3 in
      let d1 = norm (!eye -- x1) *. coef in
      Printf.fprintf ch "sphere { %a,%.15e}\n"
	    pv x1 d1;
    done;
    let fn array =
      let size = Raw.length array in
      for i = 0 to size - 2 do
	let p1 = Raw.get array ~pos:(i) in
	let p2 = Raw.get array ~pos:(i+1) in
	let x1 = Raw.gets_float s.cvertex (3*p1) 3 in
	let x2 = Raw.gets_float s.cvertex (3*p2) 3 in
	let rec fn x1 x2 =
	  let v1 = x1 -- !eye and v2 = x2 -- !eye in
	  if angle v1 v2 > pi /. 3.0 then begin
	    fn x1 ((x1 ++ x2) // 2.0);
	    fn ((x1 ++ x2) // 2.0) x2;
	  end else
	    let d1 = norm v1 *. coef in
	    let d2 = norm v2 *. coef in
	    if norm (x1 -- x2) > min d1 d2 *. 1e-4 then
	      Printf.fprintf ch "cone { %a,%.15e,%a,%.15e}\n"
		pv x1 d1 pv x2 d2;
	in
	fn x1 x2
      done;
    in
    List.iter fn s.celements;
    begin match su.pov_line_texture with
      "" ->
	let (r,g,b,a) = su.line_color in
	Printf.fprintf ch "  pigment { color rgb <%f,%f,%f>}\n" r g b;
    | s -> Printf.fprintf ch "%s\n" s
    end;
    Printf.fprintf ch "}\n";
  in
  let write_point ch su = match su.ps with None -> () | Some s ->
    let coef = tan (pi /. 4. /. float pixels) *.
	su.point_size /. 2. in
    Printf.fprintf ch "union {\n  ";
    let size = Raw.length s.pelements in
    for i = 0 to size - 1 do
      let x1 = Raw.gets_float s.pvertex
	  (3*Raw.get s.pelements i) 3 in
      let d1 = norm (!eye -- x1) *. coef in
      Printf.fprintf ch "sphere { %a,%.15e}\n"
	    pv x1 d1;
    done;
    begin match su.pov_point_texture with
      "" ->
	let (r,g,b,a) = su.point_color in
	Printf.fprintf ch "  pigment { color rgb <%f,%f,%f>}\n" r g b;
    | s -> Printf.fprintf ch "%s\n" s
    end;
    Printf.fprintf ch "}\n";
  in

  let in_filename = filename "pov" in
  print_string "Creating POVRay file: "; print_string in_filename;
  print_newline ();

  let ch = open_out in_filename in

  (match !pov_preambule with
    "" ->
      let (r,g,b) = !background in
      Printf.fprintf ch "\nglobal_settings { assumed_gamma 2.2 }\n sky_sphere { pigment { rgb <%f,%f,%f> } }\n" r g b
  | s ->  Printf.fprintf ch  "%s\n" s
  );

  for num = 0 to 7 do write_light ch num done;

  write_camera ch;

  let rec fn (s : Parameters.surface) =
    write_mesh2 ch s;
    write_curve ch s;
    write_point ch s;
  in

  List.iter fn (fst !all_surfaces);
  List.iter fn (snd !all_surfaces);

  close_out ch;

  let out_filename = filename "png" in
  let command = "povray" in
  let command_args =
    [|
      "povray";
      (*"+SP8";*) "+FN8"; "+P";
      Printf.sprintf "+A%f" !pov_aliasing;
      Printf.sprintf "+W%d" pixels;
      Printf.sprintf "+H%d" (int_of_float (ratio *. (float) pixels));
      Printf.sprintf "+O%s" out_filename;
      in_filename
    |]
  in
  let f () =
    print_string ("Calling POVRay: "^command);
    print_newline ();
    let pid = Unix.fork() in
    let status =
      if pid = 0 then begin
	Unix.execvp command command_args
      end else  begin
	snd (Thread.wait_pid pid)
      end;
    in
    if status <> Unix.WEXITED(0) then begin
      print_string ("execution of \""^command^"\" failed.");
      print_newline ();
    end else begin
      print_newline ();
      print_newline ();
      Printf.printf ("Calling POVRay on file %s produced file %s")
	in_filename out_filename;
      print_newline ()
    end
  in
  ignore (Thread.create f ())

type mouse_mode =
    Observer | Object | Slide | Move | Nothing

let mouse_mode = ref Nothing

let reset_move () =
  let l =
    [rotate_right; rotate_left; rotate_up; rotate_down;
     slide_right; slide_left; slide_up; slide_down;
     moving_rright; moving_rleft; moving_down; moving_up;
     moving_right; moving_left; moving_forward; moving_back]
  in
  List.iter (fun p -> p := false) l



let special_key down ~key ~x ~y =
  did_interaction ();
  Cbglut.setWindow !main_window;
  if !mouse_mode <> Observer then begin
    speed_hfactor := 1.0;
    speed_vfactor := 1.0;
    speed_hafactor := 1.0;
    speed_vafactor := 1.0;
  end;
  match key with
    Cbglut.KEY_LEFT ->
      (if !curve_mode then slide_left else rotate_left) := down
  | Cbglut.KEY_RIGHT ->
      (if !curve_mode then slide_right else rotate_right) := down
  | Cbglut.KEY_UP ->
      (if !curve_mode then slide_up else rotate_up) := down
  | Cbglut.KEY_DOWN ->
      (if !curve_mode then slide_down else rotate_down) := down
  | Cbglut.KEY_PAGE_DOWN -> if down then
      begin
        speed := !speed /. sqrt 2.0;
	Cbglut.postRedisplay ();
      end
  | Cbglut.KEY_PAGE_UP -> if down then
      begin
        speed := !speed *. sqrt 2.0;
	Cbglut.postRedisplay ();
      end
  | Cbglut.KEY_HOME ->if down then
      begin
	init_pos ();
        Cbglut.postRedisplay ();
      end
  | _ -> ()

let click_x = ref 0
let click_y = ref 0
let click_pos = ref [|0.0;0.0;0.0|]

let mouse_func ~button ~state ~x ~y =
  did_interaction ();
  match state with
    Cbglut.UP ->
      click_pos := [|0.0;0.0;0.0|];
      if !mouse_mode = Observer then begin
	click_x := !cur_height / 2;
	click_y := !cur_width / 2;
      end else begin
	reset_move ();
	mouse_mode := Nothing;
	Cbglut.setCursor Cbglut.CURSOR_INHERIT;
      end;
  | Cbglut.DOWN ->
      let [|xv;yv;zv|] as pos = readPosition x y in
      click_pos := pos;
      Printf.printf "\n click at x = %g, y = %g, z = %g" xv yv zv;
      print_newline ();
      if !mouse_mode = Observer then begin
	click_x := !cur_height / 2;
	click_y := !cur_width / 2;
      end else begin
	click_x := x;
	click_y := y;
      end;
      match button with
	Cbglut.LEFT_BUTTON ->
	  Cbglut.setCursor Cbglut.CURSOR_CROSSHAIR;
	  mouse_mode := Slide
      | Cbglut.RIGHT_BUTTON when not !curve_mode ->
          Cbglut.setCursor Cbglut.CURSOR_CYCLE;
	  mouse_mode := Object
      | Cbglut.MIDDLE_BUTTON when not !curve_mode ->
	  Cbglut.setCursor Cbglut.CURSOR_LEFT_RIGHT;
	  mouse_mode := Move
      | Cbglut.OTHER_BUTTON 3 when! mouse_mode = Observer ->
          speed_vafactor := !speed_vafactor *. sqrt 2.0;
	  print_string "Speed: ";
	  print_float !speed; print_newline ();
	  moving_forward := true
      | Cbglut.OTHER_BUTTON 4 when! mouse_mode = Observer ->
          speed_vafactor := !speed_vafactor /. sqrt 2.0;
	  print_string "Speed: ";
	  print_float !speed; print_newline ();
	  moving_forward := true
      | Cbglut.OTHER_BUTTON i ->
	  print_string "Unknow mouse button: ";
	  print_int i;
	  print_newline ()
      | _ -> ()

let mouse_motion ~x ~y =
  try
    if !mouse_mode = Slide && !curve_mode then begin
      did_interaction ();
      let coef = 1.0 /.(float !cur_width)*.sin(45.0)*. !eye.(2) in
      eye := !eye ++
	  (float (-x + !click_x) *. coef) ** !right ++
	  (float (y - !click_y) *. coef) ** !up;
      click_x := x;
      click_y := y;
      Cbglut.postRedisplay ();
    end else begin
      let right, left, down, up =
	match !mouse_mode with
	  Object ->
	    did_interaction ();
	    rotate_right, rotate_left, rotate_up, rotate_down
	| Observer ->
	    did_interaction ();
	    moving_rright, moving_rleft, moving_up, moving_down
	| Move ->
	    did_interaction ();
	    moving_right, moving_left, moving_forward, moving_back
	| Slide ->
	    did_interaction ();
	    slide_left, slide_right, slide_down, slide_up
	| Nothing ->
	    raise Exit
      in
      let limite = 20 in
      right := x - !click_x > limite;
      left := x - !click_x < -limite;
      up := y - !click_y > limite;
      down := y - !click_y < -limite;
      match !mouse_mode with
	Move ->
	  speed_hfactor := (float (abs(x - !click_x)) -. (float) limite) /.
	    float (!cur_width / 2) *. 5. ;
	  speed_vafactor := (float (abs(y - !click_y)) -. (float) limite) /.
	    float (!cur_height / 2) *. 5. ;
      | Slide ->
	  speed_hafactor := (float (abs(x - !click_x)) -. (float) limite) /.
	    float (!cur_width / 2) *. 5. ;
	  speed_vafactor := (float (abs(y - !click_y)) -. (float) limite) /.
	    float (!cur_height / 2) *. 5. ;
      | Observer ->
	  speed_hfactor := (float (abs(x - !click_x)) -. (float) limite) /.
	    float (!cur_width / 2) *. 2. ;
	  speed_vfactor := (float (abs(y - !click_y)) -. (float) limite) /.
	    float (!cur_height / 2) *. 5. ;
      | Object ->
	  speed_hfactor := (float (abs(x - !click_x)) -. (float) limite) /.
	    float (!cur_width / 2) *. 5. ;
	  speed_vfactor := (float (abs(y - !click_y)) -. (float) limite) /.
	    float (!cur_height / 2) *. 5. ;
      | _ -> assert false
    end
  with Exit -> ()


let reshape ~w ~h =
  cur_width := w;
  cur_height := h;
  GlDraw.viewport ~x:0 ~y:0 ~w ~h;
  GlMat.mode `projection;
  GlMat.load_identity ();
  GluMat.perspective ~fovy:45.0 ~aspect:((float) w /. (float) h)
    ~z:(if !curve_mode then !eye.(2)*. 0.1, !eye.(2)*.30.0 else 0.25*. !speed, 75.0*. !speed);
  GlMat.mode `modelview;
  GlMat.load_identity ();
  set_lights ();
  GluMat.look_at ~eye:(tuple !eye) ~center:(tuple (!eye ++ (if !curve_mode then !eye.(2) ** !front else !front))) ~up:(tuple !up);
  Gl.flush ()

let display (opaque, transparent) () =
  reshape ~w:!cur_width ~h:!cur_height;
  GlFunc.color_mask ~red:true ~green:true ~blue:true ~alpha:true ();
  GlFunc.depth_mask true;
  GlDraw.color  (1.0, 1.0, 1.0);
  GlFunc.depth_func `less;
  GlClear.clear [`color; `depth];
  Gl.enable `lighting;
  Gl.disable `color_material;
  (* the two next lines are a bug fix for my ATI card ! *)
  GlDraw.begins `triangles;
  GlDraw.ends ();

  let rec fn1 s =
    match s.ts with
      None -> ()
    | Some tl ->
    if s.transparent then begin
      Gl.enable `depth_test;
      Gl.enable `blend;
      GlFunc.depth_mask false;
      GlLight.material ~face:`front (`ambient s.front_ambient);
      GlLight.material ~face:`back (`ambient s.back_ambient);
      let (_,_,_,fa) = s.front_diffuse in
      let (_,_,_,ba) = s.back_diffuse in
      GlLight.material ~face:`front (`diffuse (0.0,0.0,0.0,fa));
      GlLight.material ~face:`back (`diffuse (0.0,0.0,0.0,ba));
      GlLight.material ~face:`both (`shininess 0.0);
      let (_,_,_,fs) = s.front_specular in
      let (_,_,_,bs) = s.back_specular in
      GlLight.material ~face:`front (`specular (0.0,0.0,0.0,fs));
      GlLight.material ~face:`back (`specular (0.0,0.0,0.0,bs));
      GlFunc.blend_func `zero `one_minus_src_alpha;
      Glarrays.drawSurface true tl;
    end else begin
      GlLight.material ~face:`front (`ambient s.front_ambient);
      GlLight.material ~face:`back (`ambient s.back_ambient);
      GlLight.material ~face:`front (`diffuse s.front_diffuse);
      GlLight.material ~face:`back (`diffuse s.back_diffuse);
      GlLight.material ~face:`front (`shininess s.front_shininess);
      GlLight.material ~face:`back (`shininess s.back_shininess);
      GlLight.material ~face:`front (`specular s.front_specular);
      GlLight.material ~face:`back (`specular s.back_specular);
      Gl.enable `depth_test;
      Gl.disable `blend;
      GlFunc.depth_mask true;
      Glarrays.drawSurface true tl;
    end
  in
  let rec fn2 s =
    match s.ts with
      None -> ()
    | Some tl ->
    if s.transparent then begin
      Gl.enable `depth_test;
      Gl.enable `blend;
      GlFunc.depth_mask false;
      GlLight.material ~face:`both (`ambient (0.0,0.0,0.0,0.0));
      GlLight.material ~face:`front (`diffuse s.front_diffuse);
      GlLight.material ~face:`back (`diffuse s.back_diffuse);
      GlLight.material ~face:`front (`shininess s.front_shininess);
      GlLight.material ~face:`back (`shininess s.back_shininess);
      GlLight.material ~face:`front (`specular s.front_specular);
      GlLight.material ~face:`back (`specular s.back_specular);
      GlFunc.blend_func `src_alpha `one;
      Glarrays.drawSurface true tl;
    end
  in
  let rec fn3 s =
    match s.ts with
      None -> ()
    | Some tl ->
    if s.transparent then begin
      Gl.enable `depth_test;
      Gl.disable `blend;
      GlFunc.depth_mask true;
      GlFunc.color_mask ~red:false ~green:false ~blue:false ();
      Glarrays.drawSurface true tl;
    end
  in
  let rec fn4 s =
    match s.ts with
      None -> ()
    | Some tl ->
    if s.transparent then begin
      Gl.enable `depth_test;
      GlFunc.depth_func `lequal;
      Gl.enable `blend;
      GlFunc.depth_mask false;
      GlFunc.color_mask ~red:true ~green:true ~blue:true ();
      GlLight.material ~face:`front (`ambient s.front_ambient);
      GlLight.material ~face:`back (`ambient s.back_ambient);
      GlLight.material ~face:`front (`diffuse s.front_diffuse);
      GlLight.material ~face:`back (`diffuse s.back_diffuse);
      GlLight.material ~face:`front (`shininess s.front_shininess);
      GlLight.material ~face:`back (`shininess s.back_shininess);
      GlLight.material ~face:`front (`specular s.front_specular);
      GlLight.material ~face:`back (`specular s.back_specular);
      GlFunc.blend_func `src_alpha `one_minus_src_alpha;
      Glarrays.drawSurface true tl;
      GlFunc.depth_func `less;
    end
  in

  let gn s =

    Gl.disable `blend;
    Gl.enable `depth_test;
    GlFunc.depth_mask true;

    (match s.ts with
      None -> ()
    | Some tl ->
    if !draw_edge && !cube_edges = None then begin
      let fc =
	let (r,g,b,_) = s.front_diffuse in
	(1.0 -. r,1.0 -. g ,1.0 -. b,1.0)
      in
      let bc =
	let (r,g,b,_) = s.back_diffuse in
	(1.0 -. r,1.0 -. g ,1.0 -. b,1.0)
      in
      GlLight.material ~face:`front (`ambient s.front_ambient);
      GlLight.material ~face:`back (`ambient s.back_ambient);
      GlLight.material ~face:`front (`diffuse fc);
      GlLight.material ~face:`back (`diffuse bc);
      GlLight.material ~face:`front (`shininess s.front_shininess);
      GlLight.material ~face:`back (`shininess s.back_shininess);
      GlLight.material ~face:`front (`specular s.front_specular);
      GlLight.material ~face:`back (`specular s.back_specular);
      GlDraw.polygon_mode `both `line;
      GlDraw.line_width 1.5;
      Glarrays.drawSurface false tl;
      GlDraw.polygon_mode `both `fill;
    end);
    (match s.text with
      [] -> ()
    | l ->
	List.iter
	  (fun (pos, str) ->
	    Glchar.display_string pos str s.text_color;
	  ) l;
    );
    (match s.es with
      None -> ()
    | Some tl ->
	GlLight.material ~face:`both (`diffuse (0.0,0.0,0.0,0.0));
	GlLight.material ~face:`both (`shininess (0.0));
	GlLight.material ~face:`both (`ambient (0.0,0.0,0.0,0.0));
	GlLight.material ~face:`both (`specular (0.0,0.0,0.0,0.0));
	GlLight.material ~face:`both (`emission s.line_color);
	GlDraw.line_width s.line_width;
	Glarrays.drawCurve tl;
	GlLight.material ~face:`both (`emission (0.0,0.0,0.0,0.0)));
    (match s.es with
      None -> ()
    | Some tl ->
    if !draw_edge && !cube_edges = None then begin
      let fc =
	let (r,g,b,_) = s.line_color in
	(1.0 -. r,1.0 -. g ,1.0 -. b,1.0)
      in
      GlLight.material ~face:`both (`diffuse (0.0,0.0,0.0,0.0));
      GlLight.material ~face:`both (`shininess (0.0));
      GlLight.material ~face:`both (`ambient (0.0,0.0,0.0,0.0));
      GlLight.material ~face:`both (`specular (0.0,0.0,0.0,0.0));
      GlLight.material ~face:`both (`emission fc);
      GlDraw.point_size 5.0;
      Glarrays.drawCurveasPoints tl;
      GlLight.material ~face:`both (`emission (0.0,0.0,0.0,0.0))
    end);
    (match s.ps with
      None -> ()
    | Some tl ->

	GlLight.material ~face:`both (`diffuse (0.0,0.0,0.0,0.0));
	GlLight.material ~face:`both (`shininess (0.0));
	GlLight.material ~face:`both (`ambient (0.0,0.0,0.0,0.0));
	GlLight.material ~face:`both (`specular (0.0,0.0,0.0,0.0));
	GlLight.material ~face:`both (`emission s.point_color);
	GlDraw.point_size s.point_size;
	Glarrays.drawPoints tl;
	GlLight.material ~face:`both (`emission (0.0,0.0,0.0,0.0)));
  in

  List.iter gn opaque;
  List.iter gn transparent;
  List.iter fn1 opaque;
  List.iter fn1 transparent;
  List.iter fn2 transparent;
  List.iter fn3 transparent;
  List.iter fn4 transparent;

  if !draw_edge then (match !cube_edges with
    Some l ->
      GlLight.material ~face:`both (`ambient (1.0,1.0,1.0,1.0));
      Gl.enable `depth_test;
      Gl.disable `blend;
      GlFunc.depth_mask true;
      GlDraw.line_width 1.0;
      GlList.call l
  | None -> ());

  begin
    match !target with None -> () | Some x ->
      Gl.enable `depth_test;
      Gl.disable `blend;
      GlFunc.depth_mask true;
      GlDraw.polygon_mode `both `fill;
      GlLight.material ~face:`both (`ambient (1.0,1.0,1.0,1.0));
      GlFunc.blend_func `src_alpha `one_minus_src_alpha;
      GlDraw.point_size 3.0;
      GlDraw.begins `points;
      GlDraw.vertex ~x:x.(0) ~y:x.(1) ~z:x.(2) ();
      GlDraw.ends ()
  end;

  if !badt <> [] then begin
    Gl.enable `depth_test;
    Gl.disable `blend;
    GlFunc.depth_mask true;
    GlDraw.polygon_mode `both `fill;
    GlLight.material ~face:`both (`ambient (1.0,0.0,0.0,1.0));
    GlFunc.blend_func `src_alpha `one_minus_src_alpha;
    GlDraw.polygon_mode `both `line;
    GlDraw.line_width 3.0;
    GlDraw.begins `triangles;
    List.iter glDraw_simple_triangle !badt;
    GlDraw.ends ()
  end;

  let fn { message_x = x; message_y = y; message = str; message_color = color } =
    Glchar.display_message !cur_width !cur_height ((x,y),str,color)
  in
  List.iter (fun (_, m) -> fn m) !all_messages;
(*  if !waiting then fn wait_message;*)

  Cbglut.swapBuffers ()

let display_all ()  =  display !all_surfaces ()

let set_hint (cap:GlMisc.hint_target) value =
  match cap with
    `perspective_correction ->
      (match value with
	`off ->
	  failwith "off is not a possible value for perspective_correction"
      | (`fastest|`nicest|`dont_care as y) ->
	  GlMisc.hint cap y)
  | (`fog|`line_smooth|`point_smooth|`polygon_smooth as x) ->
      match value with
	`off ->
	  Gl.disable x
      | (`fastest|`nicest|`dont_care as y) ->
	  Gl.enable x;
	  GlMisc.hint x y

type gl_action =
    Change_param of bool * gl_parameters * draw_parameters
  | Add_surfaces of surface list
  | Add_message of string * message
  | Remove_surfaces of surface list
  | Remove_message of string
  | Remove_all
  | Wait of int
  | LightOn of int
  | LightOff of int
  | LightPos of int * light_parameters
  | Redisplay
  | Curve_mode of bool
  | Save_image of string
  | Run of (unit -> unit)
  | Quit

let events_list = Queue.create ()

let queue_mutex = Mutex.create ()

let max_queue = 100

let lock_to_write () =
(*  while Queue.length events_list > 100 do
    Thread.delay (float max_queue *. 1e-3)
  done; *)
  Mutex.lock queue_mutex

let add_to_queue = ref (fun l ->
      lock_to_write ();
      if !Input_util.interactive then begin
	try
	  let e = Queue.peek events_list in
	  if e = Wait(-1) then ignore(Queue.pop events_list);
	with Queue.Empty -> ()
      end;
      List.iter (fun x -> Queue.add x events_list) l;
      Mutex.unlock queue_mutex)


exception Unavailable

let lock_queue () =
    if not (Mutex.try_lock queue_mutex) then raise Unavailable

let unlock_queue () =
    Mutex.unlock queue_mutex


external init_timer : (value:int -> unit) -> unit = "myinit_glutTimerFunc"

external set_timer : int -> int -> unit = "myml_glutTimerFunc"

let time_before_next = ref 0
let time_before_rotate = ref (-1)


let remain_ptr = ref 0
let cur_file_img = ref 0

let rec treat_one_event ~value:_ =
  Cbglut.setWindow !main_window;
  let remain = !remain_ptr - interval in
  let current = Unix.gettimeofday () in
  let deltaf = current -. !last_time in
  let delta = int_of_float ((current -. !last_interaction) *. 1000.0) in
  if !time_before_next > 0 && delta > !time_before_next then begin
    last_time := current;
    stop_wait ()
  end else if not !curve_mode &&
    !time_before_rotate >= 0 && delta > !time_before_rotate
  then begin
    last_time := current;
    let vstep = cos(current /. 10.0) *. step *. deltaf in
    let hstep = sin(current /. 10.0) *. step *. deltaf in

    let nfront = cos(hstep) ** !front ++ sin(hstep) ** !right in
    let nright = cos(hstep) ** !right -- sin(hstep) ** !front in
    eye := !eye ++ 20.0 ** !speed ** !front -- 20.0 ** !speed ** nfront;
    front := nfront;
    right := nright;

    let nfront = cos(vstep) ** !front ++ sin(vstep) ** !up in
    let nup = cos(vstep) ** !up -- sin(vstep) ** !front in
    eye := !eye ++ 20.0 ** !speed ** !front -- 20.0 ** !speed ** nfront;
    front := nfront;
    up := nup;
    Cbglut.postRedisplay ();
  end else begin
    update_pos ();
  end;
  if remain > 0 then (remain_ptr := remain; set_timer interval remain) else begin
  let rec do_treat () =
    try
      lock_queue ();
      let e = Queue.peek events_list in
      if e <> Wait(-1) then begin
	waiting := false;
	ignore (Queue.pop events_list);
      end;
      unlock_queue ();
    match e with
      Change_param(move, gl_param, draw_param) ->
	draw_init move gl_param draw_param;
        do_treat ()
    | Redisplay ->
	Cbglut.postRedisplay ();
	do_treat ()
    | Add_surfaces s ->
	all_surfaces :=
	  List.fold_left (fun (opaque, transparent) s ->
	    if s.transparent then opaque, s::transparent else s::opaque, transparent)
	    !all_surfaces s;
	do_treat ()
    | Add_message (name, m ) ->
	all_messages := (name,m) :: (List.remove_assoc name !all_messages);
	do_treat ()
    | Remove_surfaces s ->
	let fn l =  List.fold_left (fun l s' ->
	    if List.memq s' s then l else s'::l) [] l
	in
	all_surfaces := fn (fst !all_surfaces), fn (snd !all_surfaces);
	do_treat ()
    | Remove_message name ->
	all_messages := List.remove_assoc name !all_messages;
	do_treat ()
    | Remove_all ->
	all_surfaces := [],[];
	do_treat ()
    | Wait -1 ->
	if not !waiting then begin
	  waiting := true;
	  Cbglut.postRedisplay ()
	end;
        remain_ptr := 0; set_timer interval 0
    | Wait n ->
	if not !waiting then begin
	  waiting := true;
	  Cbglut.postRedisplay ()
	end;
        remain_ptr := n; set_timer interval n;
    | LightOn num ->
	lights_on.(num) <- true;
        do_treat ()
    | LightOff num ->
	lights_on.(num) <- false;
	do_treat ()
    | LightPos (num, l) ->
	lights_param.(num) <- l;
    | Curve_mode x ->
	curve_mode := x;
	do_treat()
    | Run f ->
	f ();
	do_treat ();
    | Save_image name ->
	let name =
	  try
	    let i = String.index name '?' in
	    let n = Printf.sprintf "%06d" (!cur_file_img) in
	    let len = String.length name in
	    let name = String.sub name 0 i ^ n ^
	      (if (i+1 < len) then String.sub name (i+1) (len - i - 1) else "") ^ "." ^ !file_format;
	    in
	    incr cur_file_img;
	    name
	  with
	    Not_found -> name ^ !file_format
	in
	save_image name;
	do_treat ()
    | Quit ->
	raise Exit
      with Queue.Empty ->
	unlock_queue ();
	remain_ptr := 0; set_timer interval 0
         | Unavailable ->
	remain_ptr := 0; set_timer interval 0
  in
  do_treat ()
  end

and stop_wait () =
  did_interaction ();
  lock_queue ();
  begin
    try
      let e = Queue.peek events_list in
      if e = Wait(-1) then begin
	waiting := false;
	Cbglut.postRedisplay ();
	ignore (Queue.pop events_list);
      end;
    with Queue.Empty -> ()
  end;
  unlock_queue ()

and first_draw_init = ref true

and draw_init move gl_param draw_param =
  Cbglut.setWindow !main_window;

  if move || !first_draw_init then begin
    gl_origin := gl_param.origin;
    gl_size := gl_param.size;
    first_draw_init := false;
    init_pos ();
  end;

  GlClear.color draw_param.background;
  background := draw_param.background;
  GlLight.light_model (`ambient draw_param.lmodel_ambient);
  GlLight.light_model (`two_side draw_param.lmodel_twoside);
  lmodel_twosides := draw_param.lmodel_twoside;
  set_hint `fog draw_param.fog;
  set_hint `perspective_correction draw_param.perspective_correction;
  set_hint `line_smooth draw_param.line_smooth;
  set_hint `point_smooth draw_param.point_smooth;
  set_hint `polygon_smooth draw_param.polygon_smooth;
  Gl.enable `normalize;
  if draw_param.smooth_shade then
    GlDraw.shade_model `smooth
  else
    GlDraw.shade_model `flat;
  GlMat.mode `modelview;
  GlMat.load_identity ()

and is_fullScreen = ref None

and full_screen b =
  Cbglut.setWindow !main_window;
  match !is_fullScreen, b with
    None, true ->
      is_fullScreen := Some(!cur_width,!cur_height,
			      Cbglut.get Cbglut.WINDOW_X,
			      Cbglut.get Cbglut.WINDOW_Y);
      Cbglut.positionWindow 0 0;
      Cbglut.fullScreen ()
  | Some(w,h,x,y), false ->
      is_fullScreen := None;
      Cbglut.reshapeWindow w h;
      Cbglut.positionWindow x y
  | _ -> ()


and normal_key down ~key ~x ~y =
  did_interaction ();
  Cbglut.setWindow !main_window;
  if !mouse_mode <> Observer then begin
    speed_hfactor := 1.0;
    speed_vfactor := 1.0;
    speed_hafactor := 1.0;
    speed_vafactor := 1.0;
  end;
  match key with
    '4' -> moving_rleft := down
  | '6' -> moving_rright := down
  | '2' -> moving_down := down
  | '8' -> moving_up := down
  | '1' -> moving_left := down
  | '3' -> moving_right := down
  | ' ' -> moving_forward := down
  | 'b'|'B' -> moving_back := down
  | 'c'|'C' ->
      if down then begin
	curve_mode := not !curve_mode;
	if !curve_mode then
	  print_string "Curve mode on."
	else
	  print_string "Curve mode off.";
	print_newline ();
      end;
      Cbglut.postRedisplay ();
  | 'm'|'M' ->
      if down then begin
	if !mouse_mode = Observer then
	  begin
	    reset_move ();
	    Cbglut.setCursor Cbglut.CURSOR_INHERIT;
	    mouse_mode := Nothing;
	  end
	else
	  begin
	    Cbglut.setCursor Cbglut.CURSOR_NONE;
	    mouse_mode := Observer;
	    click_x := !cur_height / 2;
	    click_y := !cur_width / 2;
	  end
      end
  | 'n'|'N' ->
      if down then begin
	stop_wait ();
	treat_one_event ~value:0
      end
  | 'r'|'R' -> if down then povray ()
  | 's'|'S' -> if down then let name = filename !file_format in save_image name
  | 'x'|'X'|'\027' -> if down then raise Exit
  | 'e'|'E' ->
      if down then begin
	draw_edge := not !draw_edge;
	Cbglut.postRedisplay ();
      end
  | 't'|'T' ->
      if down then begin
	Cbglut.postRedisplay ();
	match !target with
	  None ->
	    let p = init_target_pos () in
	    print_vector p; print_newline ()
	| Some _ -> target := None
      end
  | 'p'|'P' ->
      if down then begin
	open_hbox (); print_string "eye position: "; print_vector !eye; print_newline ();
	open_hbox (); print_string "front direction: "; print_vector !front; print_newline ();
	open_hbox (); print_string "up direction: "; print_vector !up; print_newline ();
	open_hbox (); print_string "right direction: "; print_vector !right; print_newline ();
	open_hbox (); print_string "target position: "; print_vector (!eye ++ 20.0 ** !speed ** !front); print_newline ();
      end
  | 'f'|'F' ->
      if down then begin
	match !is_fullScreen with
	  None ->
	    is_fullScreen := Some(!cur_width,!cur_height,
				  Cbglut.get Cbglut.WINDOW_X,
				  Cbglut.get Cbglut.WINDOW_Y);
	    Cbglut.fullScreen ()
	| Some(w,h,x,y) ->
	    is_fullScreen := None;
	    Cbglut.reshapeWindow w h;
	    Cbglut.positionWindow x y
      end
  | '<' ->
      if down then
	begin
          speed := !speed /. sqrt 2.0;
	  print_string "Speed: ";
	  print_float !speed; print_newline ();
	  Cbglut.postRedisplay ();
	end
  | '>' ->
      if down then
	begin
          speed := !speed *. sqrt 2.0;
	  print_string "Speed: ";
	  print_float !speed; print_newline ();
	  Cbglut.postRedisplay ();
	end
  | 'i'|'I' ->
      if down then
      begin
	init_pos ();
        Cbglut.postRedisplay ();
      end
  | c ->
      print_string "key \"";
      if Char.code c >= 32 then print_char c else (print_string "\\"; print_int (Char.code c));
      print_string "\" undefined.";
      print_newline ()


let thread_started = ref None

let normal_key_press = normal_key true
let normal_key_up = normal_key false
c_wrapper normal_key_press_cb for normal_key_press : key:char->x:int->y:int->unit
c_wrapper normal_key_up_cb for normal_key_up : key:char->x:int->y:int->unit

let special_key_press = special_key true
let special_key_up = special_key false
c_wrapper special_key_press_cb for special_key_press : key:Cbglut.special_key_t->x:int->y:int->unit
c_wrapper special_key_up_cb for special_key_up : key:Cbglut.special_key_t->x:int->y:int->unit

c_wrapper display_all_cb for display_all : unit -> unit

let menu_w = 42 and menu_h = 20

let display_menu ()  =
  GlClear.color (0.5,0.5,0.5);
  GlDraw.color (1.0,1.0,1.0);
  GlClear.clear [`color];
  Glchar.print_string 5.0 5.0 (0.0,0.0,0.0) menu_w menu_h "Menu";
  Cbglut.swapBuffers ();
  Cbglut.setWindow !main_window;


c_wrapper display_menu_cb for display_menu : unit -> unit

c_wrapper mouse_func_cb for mouse_func :button:Cbglut.button_t->state:Cbglut.mouse_button_state_t->
  x:int->y:int->unit
c_wrapper mouse_motion_cb for mouse_motion :x:int->y:int->unit
c_wrapper reshape_cb for reshape : w:int->h:int->unit

let do_menu ~value =
  Cbglut.setWindow !main_window;
  match value with
    1 -> raise Exit
  | 2 ->
      stop_wait ();
      treat_one_event ~value:0
  | 3 -> let name = filename !file_format in save_image name
  | 4 -> povray ()
  | 5 ->
      draw_edge := not !draw_edge;
      Cbglut.postRedisplay ();
  | 6 ->
      begin
	match !is_fullScreen with
	  None ->
	    is_fullScreen := Some(!cur_width,!cur_height,
				  Cbglut.get Cbglut.WINDOW_X,
				  Cbglut.get Cbglut.WINDOW_Y);
	    Cbglut.fullScreen ()
	| Some(w,h,x,y) ->
	    is_fullScreen := None;
	    Cbglut.reshapeWindow w h;
	    Cbglut.positionWindow x y
      end
  | 7 ->
      init_pos ();
      Cbglut.postRedisplay ();
  | _ ->
      assert false

c_wrapper menu_cb for do_menu : value:int -> unit

let init_texture () =
  let size1 = 4 in
  let table1 = Raw.create `ubyte (size1*size1*size1) in
  for i = 0 to size1-1 do
    for j = 0 to size1-1 do
      for k = 0 to size1-1 do
	Raw.set table1 ~pos:((i*size1+j)*size1+k) (if (i/2 + j/2 + k/2) mod 2 = 0 then 255 else 127);
      done
    done
  done;
  let size2 = 64 in
  let table2 = Raw.create `ubyte (size2*size2*size2) in
  for i = 0 to size2-1 do
    for j = 0 to size2-1 do
      for k = 0 to size2-1 do
	Raw.set table2 ~pos:((i*size2+j)*size2+k) (if i = 0 || j = 0 || k = 0 then 255 else 127);
      done
    done
  done;
  GlExt.enable `texture_3d;
  let ids = GlTex.gen_textures 10 in
  let l = [(`alpha,0);(`red,1);(`green,2);(`blue,3);(`luminance,4)] in
  tex_ids :=
    List.map (fun (fmt, i) -> ((fmt,`chessboard),ids.(2*i))) l @
    List.map (fun (fmt, i) -> ((fmt,`lines),ids.(2*i+1))) l;
  List.iter (fun (format,i) ->
    GlExt.bind_texture `texture_3d ids.(2*i);
    GlExt.parameter `texture_3d (`min_filter `nearest);
    GlExt.parameter `texture_3d (`mag_filter `nearest);
    GlExt.parameter `texture_3d (`wrap_s `repeat);
    GlExt.image3d_direct ~proxy:false ~level:0 ~internal:4 ~width:size1 ~depth:size1
      ~height:size1 ~border:0 ~format table1;
    GlExt.bind_texture `texture_3d ids.(2*i + 1);
    GlExt.parameter `texture_3d (`min_filter `nearest);
    GlExt.parameter `texture_3d (`mag_filter `nearest);
    GlExt.parameter `texture_3d (`wrap_s `repeat);
    GlExt.image3d_direct ~proxy:false ~level:0 ~internal:4 ~width:size2 ~depth:size2
      ~height:size2 ~border:0 ~format table2)
    l;
  GlExt.disable `texture_3d

let gl_init () =
  let cwd = Sys.getcwd () in
  Cbglut.initWindowSize ~w:600 ~h:600;
  let r = Cbglut.init Sys.argv in
  Cbglut.initDisplayMode ~double_buffer:true ~depth:true ~alpha:false () ;
  let winid = Cbglut.createWindow ~title:"Surface" in
  main_window := winid;
  Cbglut.ignoreKeyRepeat(true);
  Cbglut.keyboardFunc normal_key_press_cb;
  Cbglut.keyboardUpFunc normal_key_up_cb;
  Cbglut.specialFunc special_key_press_cb;
  Cbglut.specialUpFunc special_key_up_cb;
  Cbglut.displayFunc display_all_cb;
  Cbglut.mouseFunc mouse_func_cb;
  Cbglut.motionFunc mouse_motion_cb;
  Cbglut.passiveMotionFunc mouse_motion_cb;
  Cbglut.reshapeFunc reshape_cb;
  GlClear.depth 1.0;
  List.iter GlArray.disable
      [`vertex;`normal;`edge_flag;`color;`index;`texture_coord];
  init_pos ();

  let _menuid = Cbglut.createSubWindow winid 0 0 menu_w menu_h in
  Cbglut.displayFunc display_menu_cb;
  GlDraw.color (1.0,1.0,1.0);
  let _the_menu = Cbglut.createMenu menu_cb in
  Cbglut.addMenuEntry "Intitial position - I" 7;
  Cbglut.addMenuEntry "Draw Edge - E" 5;
  Cbglut.addMenuEntry "Full Screen - F" 6;
  Cbglut.addMenuEntry "Call PovRay - R" 4;
  Cbglut.addMenuEntry "Save Image - S" 3;
  Cbglut.addMenuEntry "Continue - N" 2;
  Cbglut.addMenuEntry "Quit - ESC" 1;

  Cbglut.attachMenu Cbglut.LEFT_BUTTON;
  Cbglut.attachMenu Cbglut.RIGHT_BUTTON;
  Cbglut.attachMenu Cbglut.MIDDLE_BUTTON;
  Cbglut.keyboardFunc normal_key_press_cb;
  Cbglut.keyboardUpFunc normal_key_up_cb;
  Cbglut.specialFunc special_key_press_cb;
  Cbglut.specialUpFunc special_key_up_cb;
  Cbglut.popWindow ();
  Cbglut.setWindow winid;

  Sys.chdir cwd; (* on OS X, Cbglut.init changes the cwd !!! *)
  init_texture ();

  r

let gl_started = Mutex.create ()

let start_gl gl_param draw_param =
  all_surfaces := [], [];
  Cbglut.postRedisplay ();
  init_timer treat_one_event;
  set_timer interval 0;
  Mutex.unlock gl_started;
  Cbglut.mainLoop ()

let draw time gl_param draw_param surfaces =
  !add_to_queue [Remove_all;
		Change_param(false,gl_param, draw_param);
		Add_surfaces(surfaces);
		Wait time]

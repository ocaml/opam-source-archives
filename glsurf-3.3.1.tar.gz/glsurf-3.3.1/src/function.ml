(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Algebra
open Expression
open Vect3
open Floatexpr
module Expr = Expr

let cc_name =
  try Sys.getenv "CC" with Not_found -> "gcc"

let rec split_string str =
  let rec fn acc pos =
    try
      let npos = String.index_from str pos ' ' in
      let word = String.sub str pos (npos - pos) in
      let acc = if word = "" then acc else word::acc in
      fn acc (npos + 1)
    with
      Not_found ->
	Array.of_list (List.rev acc)
  in
  fn [cc_name] 0

let cc_test =
  try Sys.getenv "CCTEST" with Not_found -> "-v"

let cc_shopts =
  try Sys.getenv "CCSHOPTS" with Not_found ->
    IFDEF OSX THEN "-bundle -lm -O -pipe"
    ELSE "-shared -lm -O -pipe -fPIC" ENDIF

let can_compile =
  match cc_name with
    "NONE" ->
      false
  | _ ->
      Sys.command (cc_name ^" " ^ cc_test) = 0

let _ =
  if can_compile then
    begin
      print_newline ();
      print_string "Compilation of functions available.";
      print_newline ();
      print_newline ();
    end
  else
    begin
      print_newline ();
      print_string ("Compilation of functions not available ("^cc_name^" not found).");
      print_newline ();
      print_newline ();
    end

let rec fsqrt = {
	Expr.name = "sqrt";
	Expr.calcul = sqrt;
	Expr.deriv = Expr.Div (Expr.Cst (0.5), Expr.Tra (0, Expr.Var "x"));
	Expr.name_var = "x" }

and fexp = {
	Expr.name = "exp";
	Expr.calcul = exp;
	Expr.deriv = Expr.Tra (1, Expr.Var "x");
	Expr.name_var = "x" }

let fcos = {
	Expr.name = "cos";
	Expr.calcul = cos;
	Expr.deriv = Expr.Mul (Expr.Cst (-1.0), Expr.Tra (4, Expr.Var "x"));
	Expr.name_var = "x" }

and fsin = {
	Expr.name = "sin";
	Expr.calcul = sin;
	Expr.deriv = Expr.Tra (3, Expr.Var "x");
	Expr.name_var = "x" }

and ftan = {
	Expr.name = "tan";
	Expr.calcul = tan;
	Expr.deriv = Expr.Div (Expr.Cst 1.0, Expr.Pow( Expr.Tra (3, Expr.Var "x"), 2));
	Expr.name_var = "x" }

let flog = {
	Expr.name = "log";
	Expr.calcul = log;
	Expr.deriv = Expr.Div (Expr.Cst 1.0, Expr.Var "x");
	Expr.name_var = "x" }

let fatan = {
	Expr.name = "atan";
	Expr.calcul = atan;
	Expr.deriv = Expr.Div (Expr.Cst 1.0, Expr.Add(Expr.Cst 1.0, Expr.Pow (Expr.Var "x", 2)));
	Expr.name_var = "x" }

let facos = {
	Expr.name = "acos";
	Expr.calcul = acos;
	Expr.deriv = Expr.Div (Expr.Cst (-1.0), Expr.Tra(0, Expr.Sub(Expr.Cst 1.0, Expr.Pow (Expr.Var "x", 2))));
	Expr.name_var = "x" }

let fasin = {
	Expr.name = "asin";
	Expr.calcul = asin;
	Expr.deriv = Expr.Div (Expr.Cst 1.0, Expr.Tra(0, Expr.Sub(Expr.Cst 1.0, Expr.Pow (Expr.Var "x", 2))));
	Expr.name_var = "x" }

let fsgn = {
	Expr.name = "sgn";
	Expr.calcul = (fun x -> if x > 0.0 then 1.0 else if x < 0.0 then -1.0 else 0.0);
	Expr.deriv = Expr.Cst 0.0;
	Expr.name_var = "x" }

let fabs = {
	Expr.name = "fabs";
	Expr.calcul = abs_float;
	Expr.deriv = Expr.Tra(10, Expr.Var "x");
	Expr.name_var = "x" }

let fpositive = {
  Expr.name = "positive";
  Expr.calcul = (fun x -> if x >= 0.0 then 1.0 else 0.0);
  Expr.deriv = Expr.Cst 0.0;
  Expr.name_var = "x" }

let fnegative = {
  Expr.name = "negative";
  Expr.calcul = (fun x -> if x <= 0.0 then 1.0 else 0.0);
  Expr.deriv = Expr.Cst 0.0;
  Expr.name_var = "x" }

let fmax = {
  Expr.name2 = "max";
  Expr.calcul2 = max;
  Expr.deriv1 = Expr.Tra(5,Expr.Sub(Expr.var "x", Expr.Var "y"));
  Expr.deriv2 = Expr.Tra(6,Expr.Sub(Expr.var "x", Expr.Var "y"));
  Expr.name_var1 = "x";
  Expr.name_var2 = "y";
}

let fmin = {
  Expr.name2 = "min";
  Expr.calcul2 = min;
  Expr.deriv1 = Expr.Tra(6,Expr.Sub(Expr.var "x", Expr.Var "y"));
  Expr.deriv2 = Expr.Tra(5,Expr.Sub(Expr.var "x", Expr.Var "y"));
  Expr.name_var1 = "x";
  Expr.name_var2 = "y";
}

let _ =
  Expr.trans_array :=
    [| fsqrt; fexp; flog; fcos; fsin; fpositive; fnegative; fatan; facos; fasin; fsgn; fabs; ftan |];

  Expr.trans_table :=
    List.fold_left (fun acc (name, f) -> StringMap.add name f acc) !Expr.trans_table
    [ "exp", 1; "sin", 4; "cos", 3; "log", 2; "sqrt", 0;
      "positive", 5; "negative", 6; "atan", 7; "acos", 8; "asin", 9; "sgn", 10; "abs", 11; "tan", 12 ];

  Expr.trans2_array :=
    [| fmax; fmin |];

  Expr.trans2_table :=
    List.fold_left (fun acc (name, f) -> StringMap.add name f acc) !Expr.trans2_table
    [ "max", 0; "min", 1]

let _ = Expr.fun_table :=
  List.fold_left (fun acc (name, f) -> StringMap.add name f acc) !Expr.fun_table
  [ "true", {Expr.fname = "true"; Expr.variables = []; Expr.value = Expr.Cst 1.0};
    "false", {Expr.fname = "false"; Expr.variables = []; Expr.value = Expr.Cst 0.0};
    "fastest", {Expr.fname = "fastest"; Expr.variables = []; Expr.value = Expr.Cst 0.0};
    "nicest", {Expr.fname = "nicest"; Expr.variables = []; Expr.value = Expr.Cst 1.0};
    "dont_care", {Expr.fname = "dont_care"; Expr.variables = []; Expr.value = Expr.Cst (-1.0)};
    "on", {Expr.fname = "true"; Expr.variables = []; Expr.value = Expr.Cst 1.0};
    "off", {Expr.fname = "off"; Expr.variables = []; Expr.value = Expr.Cst (-2.0)};
    "pi", {Expr.fname = "pi"; Expr.variables = []; Expr.value = Expr.Cst (2.0 *. acos 0.0)} ]

type handle

external c_set_functions: handle -> unit = "set_functions"
external c_load_file: string -> handle = "load_file"
external dlclose : handle -> unit = "fun_dlclose"

external cf : float -> float -> float -> float = "sf" "ff" "float"
external cffst : float -> float -> float -> float array = "sffst" "fffst"
external cfsnd : float -> float -> float -> float array = "sfsnd" "ffsnd"
external cth : float -> float -> float ->
  float array = "sfthd" "ffthd"
external cfi : float -> float -> float -> float -> float -> float ->
  float array = "sfi" "ffi"


let reinit handle = c_set_functions (fst handle)

let delete_handle (h,n) =
  dlclose h; Sys.remove n

module type Function =
  sig
    val value : point -> float
    val grad : point -> vector
    val hessian_mat : point -> float array
    val hessian : point -> vector -> vector
    val third : point -> vector -> float  array array
    val ihessian : float -> float -> float -> float -> float -> float ->
      (float * float) * (float * float) * (float * float) *
	(float * float) * (float * float) * (float * float)

    val handle : (handle * string) option
    val f : Expr.elem
    val fx : Expr.elem
    val fy : Expr.elem
    val fz : Expr.elem

    val epsilon : float
    val dighotomie : point -> point -> point
    val newton : float -> float -> point -> point
  end

module type String_Expr =
  sig
    val f : string
    val epsilon : float
    val compile : bool
    val hessian : bool
    val third : bool
  end

module type Expr_Expr =
  sig
    val f : Expr.elem
    val epsilon : float
    val compile : bool
    val hessian : bool
    val third : bool
  end

module Make_Function_From_Expr = functor (Str:Expr_Expr) ->
  struct
    let f = Str.f

    let fx = Expr.derive f "x" and
	fy = Expr.derive f "y" and
	fz = Expr.derive f "z"

    let fxx,fyy,fzz,fxy,fxz,fyz =
      if Str.hessian then
	Expr.derive fx "x",
	Expr.derive fy "y",
	Expr.derive fz "z",
	Expr.derive fx "y",
	Expr.derive fx "z",
	Expr.derive fy "z"
      else
        Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero

     let fxxx,fyyy,fzzz,fxxy,fxyy,fxxz,fxzz,fyyz,fyzz,fxyz =
      if Str.third then
	Expr.derive fxx "x",
	Expr.derive fyy "y",
	Expr.derive fzz "z",
	Expr.derive fxx "y",
	Expr.derive fxy "y",
	Expr.derive fxx "z",
	Expr.derive fxz "z",
	Expr.derive fyy "z",
	Expr.derive fyz "z",
	Expr.derive fxy "z"
      else
        Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero, Expr.zero

    let _ = Expr.eval f ["x",0.0; "y",0.0; "z",0.0]

    let value, grad, hessian_mat, ihessian, third, handle =
      if Str.compile then begin
	let filename = Filename.temp_file "fun" ".c" in
        let shext = IFDEF WIN32 THEN ".dll" ELSE IFDEF OSX THEN ".dylib" ELSE ".so" ENDIF ENDIF in
	let fileobj = Filename.temp_file "fun" shext in
	let file = open_out filename in
	let out = formatter_of_out_channel file in
	pp_open_vbox out 0;
	pp_print_string out "/* A function ! */";
	pp_print_cut out ();
	pp_print_string out "#include <stdlib.h>";
	pp_print_cut out ();
	pp_print_string out "#include <stdio.h>";
	pp_print_cut out ();
	pp_print_string out "#include <math.h>";
	pp_print_cut out ();
	pp_print_string out "#define sgn(x) (x>0?1:(?x<0?-1:0))";
	pp_print_cut out ();
	pp_print_string out "#define positive(x) (x>=0?1:0)";
	pp_print_cut out ();
	pp_print_string out "#define negative(x) (x<=0?1:0)";
	pp_print_cut out ();
	pp_print_string out "double max(double x, double y) {
	  if (x >= y) return x; else return y;}";
        pp_print_cut out ();
        pp_print_string out "double min(double x, double y) {
          if (x >= y) return y; else return x;}";
	pp_print_cut out ();
        pp_print_string out "
typedef struct {
  double min;
  double max; }
    interval;

inline interval add(interval x, interval y) {
  interval r;
  r.min = x.min + y.min;
  r.max = x.max + y.max;
  return r;
}

inline interval addl(interval x, double y) {
  interval r;
  r.min = x.min + y;
  r.max = x.max + y;
  return r;
}

inline interval addr(double x, interval y) {
  interval r;
  r.min = x + y.min;
  r.max = x + y.max;
  return r;
}

inline interval sub(interval x, interval y) {
  interval r;
  r.min = x.min - y.max;
  r.max = x.max - y.min;
  return r;
}

inline interval subl(interval x, double y) {
  interval r;
  r.min = x.min - y;
  r.max = x.max - y;
  return r;
}

inline interval subr(double x, interval y) {
  interval r;
  r.min = x - y.max;
  r.max = x - y.min;
  return r;
}

inline interval mul(interval x, interval y) {
  interval r;
  double a = x.min * y.min, b = x.min * y.max, c = x.max * y.min, d = x.max * y.max;
  r.min = min(min(a,b),min(c,d));
  r.max = max(max(a,b),max(c,d));
  return r;
}

inline interval mull(interval x, double y) {
  interval r;
  double a = x.min * y, b = x.max * y;
  r.min = min(a,b);
  r.max = max(a,b);
  return r;
}

inline interval mulr(double x, interval y) {
  interval r;
  double a = x * y.min, b = x * y.max;
  r.min = min(a,b);
  r.max = max(a,b);
  return r;
}

inline interval divl(interval x, double y) {
  interval r;
  double a = x.min / y, b = x.max / y;
  r.min = min(a,b);
  r.max = max(a,b);
  return r;
}

inline interval ipow(interval x, int i) {
  interval r;
  double a = pow(x.min, i), b = pow(x.max,i);
  if (!(i % 2) && x.min * x.max <= 0) {
    r.min = 0;
    r.max = max(a,b);
    return r;
  } else {
    r.min = min(a,b);
    r.max = max(a,b);
    return r;
  }
}

inline interval iexp(interval x) {
  interval r;
  r.min = exp(x.min);
  r.max = exp(x.max);
  return r;
}

inline interval ilog(interval x) {
  interval r;
  r.min = log(x.min);
  r.max = log(x.max);
  return r;
}

inline interval isqrt(interval x) {
  interval r;
  r.min = sqrt(x.min);
  r.max = sqrt(x.max);
  return r;
}

inline interval iabs(interval x) {
  interval r;
  double a = fabs(x.min), b = fabs(x.max);
  r.min = x.min * x.max <= 0.0 ? 0.0 : min(a,b);
  r.max = max(a,b);
  return r;
}

inline interval icos(interval x) { // FIXME
  interval r;
  double a = cos(x.min), b = cos(x.max);
  r.min = min(a,b);
  r.max = max(a,b);
  return r;
}

inline interval isin(interval x) { // FIXME
  interval r;
  double a = sin(x.min), b = sin(x.max);
  r.min = min(a,b);
  r.max = max(a,b);
  return r;
}

inline interval itan(interval x) { // FIXME
  interval r;
  double a = tan(x.min), b = tan(x.max);
  r.min = min(a,b);
  r.max = max(a,b);
  return r;
}

inline interval iacos(interval x) {
  interval r;
  r.min = acos(x.max);
  r.max = acos(x.min);
  return r;
}

inline interval iasin(interval x) {
  interval r;
  r.min = asin(x.min);
  r.max = asin(x.max);
  return r;
}

inline interval iatan(interval x) {
  interval r;
  r.min = atan(x.min);
  r.max = atan(x.max);
  return r;
};

inline interval isgn(interval x) {
  interval r;
  r.min = x.min > 0.0 ? 1.0 : x.max == 0.0 ? 0.0 : -1.0;
  r.max = x.max > 0.0 ? 1.0 : x.min == 0.0 ? 0.0 : -1.0;
  return r;
}

inline interval ipositive(interval x) {
  interval r;
  r.min = x.min > 0.0 ? 1.0 : 0.0;
  r.max = x.max > 0.0 ? 1.0 : 0.0;
  return r;
}

inline interval inegative(interval x) {
  interval r;
  r.min = x.max > 0.0 ? 1.0 : 0.0;
  r.max = x.min > 0.0 ? 1.0 : 0.0;
  return r;
}

inline interval imax(interval x, interval y) {
  interval r;
  r.min = max(x.min,y.min);
  r.max = max(x.max,y.max);
  return r;
}
inline interval imin(interval x, interval y) {
  interval r;
  r.min = min(x.min,y.min);
  r.max = min(x.max,y.max);
  return r;
}";

  let out_fun fn f =
    pp_print_cut out ();
	  pp_print_cut out ();
	  pp_print_string out "/*";
	  pp_print_cut out ();
	  Expr.write out f;
	  pp_print_string out "*/";
	  pp_print_cut out ();
	  pp_print_string out ("double "^fn^"(double x,double y,double z) {");
	  pp_print_cut out ();
	  pp_open_hovbox out 2;
	  let sh = Expr.init_share () in
	  Expr.build_share sh f;
	  Expr.write_share out sh;
	  pp_print_string out "return(";
	  pp_print_space out ();
	  let save = !Expr.print_mode in
	  Expr.print_mode := `C_Shared sh;
	  Expr.write out f;
	  Expr.print_mode := save;
	  pp_print_string out ");\n";
	  pp_close_box out ();
	  pp_print_string out "}"
	in
	out_fun "f" f;
  let save = !Expr.print_mode in
   pp_print_string out "
double* ffst (double x, double y, double z)
{
  double* result = (double*) malloc(3 * sizeof(double));
";
   pp_print_cut out ();
   pp_open_hovbox out 2;
   let sh = Expr.init_share () in
   Expr.print_mode := `C_Shared sh;
   let dl_share f = Expr.build_share sh f in
   dl_share fx;
   dl_share fy;
   dl_share fz;
   Expr.write_share out sh;
   pp_print_string out "  result[0] = ";
   Expr.write out fx;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "  result[1] = ";
   Expr.write out fy;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "  result[2] = ";
   Expr.write out fz;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "return result;\n}\n";
   Expr.print_mode := save;
	if not Str.hessian then begin
	  pp_print_string out "double * fi(double x1, double x2, double y1, double y2, double z1, double z2) { exit(1); }\n";
	  pp_print_string out "double * fsnd(double x1, double x2, double y1, double y2, double z1, double z2) { exit(1); }\n";
	end else begin
	  pp_print_string out "
	    double* fi (double x1, double x2, double y1, double y2, double z1, double z2)
	    {
	     interval x,y,z;
	     double* result = (double*) malloc(12 * sizeof(double));
x.min = x1;
x.max = x2;
y.min = y1;
  y.max = y2;
  z.min = z1;
  z.max = z2;
";
   pp_print_cut out ();
   pp_open_hovbox out 2;
   let save = !Expr.print_mode in
   let sh = Expr.init_ishare [] in
   Expr.print_mode := `C_Interval sh;
   let dl_ishare f = Expr.build_ishare sh f in
   dl_ishare fxx;
   dl_ishare fyy;
   dl_ishare fzz;
   dl_ishare fxy;
   dl_ishare fxz;
   dl_ishare fyz;
   Expr.write_ishare out sh;
   pp_print_string out "{ interval rtmp = ";
   Expr.write_interval out fxx;
   pp_print_string out "; result[0] = rtmp.min; result[1] = rtmp.max;} \n";
   pp_print_cut out ();
   pp_print_string out "{ interval rtmp = ";
   Expr.write_interval out fyy;
   pp_print_string out "; result[2] = rtmp.min; result[3] = rtmp.max;} \n";
   pp_print_cut out ();
   pp_print_string out "{ interval rtmp = ";
   Expr.write_interval out fzz;
   pp_print_string out "; result[4] = rtmp.min; result[5] = rtmp.max;} \n";
   pp_print_cut out ();
   pp_print_string out "{ interval rtmp = ";
   Expr.write_interval out fxy;
   pp_print_string out "; result[6] = rtmp.min; result[7] = rtmp.max;} \n";
   pp_print_cut out ();
   pp_print_string out "{ interval rtmp = ";
   Expr.write_interval out fxz;
   pp_print_string out "; result[8] = rtmp.min; result[9] = rtmp.max;} \n";
   pp_print_cut out ();
   pp_print_string out "{ interval rtmp = ";
   Expr.write_interval out fyz;
   pp_print_string out "; result[10] = rtmp.min; result[11] = rtmp.max;} \n";
   pp_print_cut out ();
   pp_print_string out "return result;\n}\n";
   pp_print_string out "
double* fsnd (double x, double y, double z)
{
  double* result = (double*) malloc(6 * sizeof(double));
";
   pp_print_cut out ();
   pp_open_hovbox out 2;
   let sh = Expr.init_share () in
   Expr.print_mode := `C_Shared sh;
   let dl_share f = Expr.build_share sh f in
   dl_share fxx;
   dl_share fyy;
   dl_share fzz;
   dl_share fxy;
   dl_share fxz;
   dl_share fyz;
   Expr.write_share out sh;
   pp_print_string out "  result[0] = ";
   Expr.write out fxx;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "  result[1] = ";
   Expr.write out fyy;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "  result[2] = ";
   Expr.write out fzz;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "  result[3] = ";
   Expr.write out fxy;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "  result[4] = ";
   Expr.write out fxz;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "  result[5] = ";
   Expr.write out fyz;
   pp_print_string out ";\n";
   pp_print_cut out ();
   pp_print_string out "return result;\n}\n";
   Expr.print_mode := save;
end;
	if not Str.third then
	  pp_print_string out "double * th(double x, double y, double z) { exit(1); }\n"
 	else begin
	  pp_print_string out "double * th(double x, double y, double z) { \n double* result = (double*) malloc(10 * sizeof(double));\n";
	  let sh = Expr.init_share () in
          Expr.build_share sh fxxx;
          Expr.build_share sh fyyy;
          Expr.build_share sh fzzz;
          Expr.build_share sh fxxy;
          Expr.build_share sh fxyy;
          Expr.build_share sh fxxz;
          Expr.build_share sh fxzz;
          Expr.build_share sh fyyz;
          Expr.build_share sh fyzz;
          Expr.build_share sh fxyz;
	  Expr.write_share out sh;
	  let save = !Expr.print_mode in
	  Expr.print_mode := `C_Shared sh;
	  pp_print_string out "result[0] = ";
	  Expr.write out fxxx;
	  pp_print_string out ";\n";
	  pp_print_string out "result[1] = ";
	  Expr.write out fyyy;
	  pp_print_string out ";\n";
	  pp_print_string out "result[2] = ";
	  Expr.write out fzzz;
	  pp_print_string out ";\n";
	  pp_print_string out "result[3] = ";
	  Expr.write out fxxy;
	  pp_print_string out ";\n";
	  pp_print_string out "result[4] = ";
	  Expr.write out fxyy;
	  pp_print_string out ";\n";
	  pp_print_string out "result[5] = ";
	  Expr.write out fxxz;
	  pp_print_string out ";\n";
	  pp_print_string out "result[6] = ";
	  Expr.write out fxzz;
	  pp_print_string out ";\n";
	  pp_print_string out "result[7] = ";
	  Expr.write out fyyz;
	  pp_print_string out ";\n";
	  pp_print_string out "result[8] = ";
	  Expr.write out fyzz;
	  pp_print_string out ";\n";
	  pp_print_string out "result[9] = ";
	  Expr.write out fxyz;
	  pp_print_string out ";\n return(result);\n}\n";
	  Expr.print_mode := save;
	end;
        pp_close_box out ();
        pp_print_newline out ();
	close_out file;
	let options = cc_shopts ^ " -o "^fileobj^" "^filename^" " in
	let options = split_string options in
	let status =
	  let fd = Unix.fork () in
	  if fd = 0 then Unix.execvp cc_name options
	  else snd (Unix.waitpid [] fd)
	in
	if status <> Unix.WEXITED 0 then begin
	  let _ = Sys.remove filename in
	  failwith ("compilation failed.");
	end;
	let handle = (c_load_file fileobj, fileobj) in
 	Gc.finalise delete_handle handle;
	let _ = Sys.remove filename in
	let value [|x;y;z|] = reinit handle; cf x y z in
	let grad [|x;y;z|] = reinit handle; cffst x y z in
	let hessian [|x;y;z|] = reinit handle; cfsnd x y z in
	let ihessian =
	  if not Str.hessian then
	    fun x1 x2 y1 y2 z1 z2 ->
	      assert false
	  else
	    fun x1 x2 y1 y2 z1 z2 ->
	      reinit handle;
	      let [| fxx1; fxx2; fyy1; fyy2; fzz1; fzz2; fxy1; fxy2; fxz1; fxz2; fyz1; fyz2 |] =
		cfi x1 x2 y1 y2 z1 z2 in
	      (fxx1, fxx2), (fyy1, fyy2), (fzz1, fzz2), (fxy1, fxy2), (fxz1, fxz2), (fyz1, fyz2)
	in
	let third [|x;y;z|] [|fx;fy;fz|]= reinit handle;
	  let [| fxxx; fyyy; fzzz; fxxy; fxyy; fxxz; fxzz; fyyz; fyzz; fxyz |] =
	    cth x y z in
	  [|[| fxxx *. fx +.  fxxy *. fy +. fxxz *. fz; fxxy *. fx +.  fxyy *. fy +. fxyz *. fz; fxxz *. fx +.  fxyz *. fy +. fxzz *. fz|];
	    [| fxxy *. fx +.  fxyy *. fy +. fxyz *. fz; fxyy *. fx +.  fyyy *. fy +. fyyz *. fz; fxyz *. fx +.  fyyz *. fy +. fyzz *. fz|];
	    [| fxxz *. fx +.  fxyz *. fy +. fxzz *. fz; fxyz *. fx +.  fyyz *. fy +. fyzz *. fz; fxzz *. fx +.  fyzz *. fy +. fzzz *. fz|]|]
	in
	value, grad, hessian, ihessian, third, Some handle
      end else begin
	let eval f [|x;y;z|] = Expr.eval f ["x",x; "y",y; "z",z] in
	let value (p:point) = eval f p in
	let grad (p:point) = [|eval fx p; eval fy p; eval fz p|] in
	let hessian (p:point) =
	  [|eval fxx p; eval fyy p; eval fzz p; eval fxy p; eval fxz p; eval fyz p|] in
	let ihessian x1 x2 y1 y2 z1 z2 =
	  let env = [("x", (x1, x2));
		     ("y", (y1, y2));
		     ("z", (z1, z2))] in
	  let fxx = Interval.bound_eval fxx env in
	  let fyy = Interval.bound_eval fyy env in
	  let fzz = Interval.bound_eval fzz env in
	  let fxy = Interval.bound_eval fxy env in
	  let fxz = Interval.bound_eval fxz env in
	  let fyz = Interval.bound_eval fyz env in
	  fxx, fyy, fzz, fxy, fxz, fyz
	in
	let third [|x;y;z|] [|fx;fy;fz|]=
	  let env = [("x", x);
		     ("y", y);
		     ("z", z)] in
	  let fxxx =  Expr.eval fxxx env in
	  let fyyy =  Expr.eval fyyy env in
	  let fzzz =  Expr.eval fzzz env in
	  let fxxy =  Expr.eval fxxy env in
	  let fxyy =  Expr.eval fxyy env in
	  let fxxz =  Expr.eval fxxz env in
	  let fxzz =  Expr.eval fxzz env in
	  let fyyz =  Expr.eval fyyz env in
	  let fyzz =  Expr.eval fyzz env in
	  let fxyz =  Expr.eval fxyz env in
	  [|[| fxxx *. fx +.  fxxy *. fy +. fxxz *. fz; fxxy *. fx +.  fxyy *. fy +. fxyz *. fz; fxxz *. fx +.  fxyz *. fy +. fxzz *. fz|];
	    [| fxxy *. fx +.  fxyy *. fy +. fxyz *. fz; fxyy *. fx +.  fyyy *. fy +. fyyz *. fz; fxyz *. fx +.  fyyz *. fy +. fyzz *. fz|];
	    [| fxxz *. fx +.  fxyz *. fy +. fxzz *. fz; fxyz *. fx +.  fyyz *. fy +. fyzz *. fz; fxzz *. fx +.  fyzz *. fy +. fzzz *. fz|]|]
	in
	value, grad, hessian, ihessian, third, None

      end

    let hessian p [|dx;dy;dz|] =
      let [|fxx; fyy; fzz; fxy; fxz; fyz|] = hessian_mat p in
      [| dx *. fxx +. dy *. fxy +. dz *. fxz;
	 dx *. fxy +. dy *. fyy +. dz *. fyz;
	 dx *. fxz +. dy *. fyz +. dz *. fzz|]


    let epsilon = Str.epsilon

    let dighotomie a b =
      let fa = value a and fb = value b in
      let fa, a, fb, b =
	if fa < 0.0 && fb > 0.0 then fa, a, fb, b else
	if fa > 0.0 && fb < 0.0 then fb, b, fa, a else
	raise Not_found
      in

      let rec fn fa a fb b =
	let c = middle a b (*  (fa ** b -- fb ** a) // (fa +. fb) *) in
	let fc = value c in
	if norm (c -- a) < epsilon then c else
	if fc < 0.0 then fn fc c fb b else fn fa a fc c
      in
      fn fa a fb b

    let newton dmax eps a =
      let rec fn step prho b =
	let fb = value b in
	let gfb = grad b in
        let s = norm gfb in
        let rho = fb /. s in
	let arho = abs_float rho in
	if arho < eps then b else
	let c = b -- (rho /. s) ** gfb in
	let d = norm (c -- a) in
	let cd = classify_float d in
	let comp = step mod 10 = 0 in
	if d > dmax || (comp && arho >= prho) || cd = FP_nan  then begin
	  raise Not_found;
	end;
	fn (step + 1) (if comp then arho else prho) c
      in
      fn 0 max_float a


  end

module Make_Function_From_String = functor (Str:String_Expr) ->
  struct
    module F =
    struct
      let f = Expr.parse (Stream.of_string Str.f)
      let epsilon = Str.epsilon
      let compile = Str.compile
      let hessian = Str.hessian
      let third = Str.third
    end
    include Make_Function_From_Expr(F)
  end

(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

let print_string x y color w h s =

  Gl.disable `blend;
  GlFunc.depth_mask false;
  Gl.disable `depth_test;
  Gl.disable `lighting;
  Gl.disable `color_material;
  GlDraw.color color;

  GlMat.mode `projection;
  GlMat.load_identity ();
  GlMat.ortho (0.0, (float) w) (0.0, (float) h) (-1.0, 1.0);
  GlMat.mode `modelview;
  GlMat.load_identity ();
  GlPix.raster_pos ~x ~y ();

  String.iter (fun c ->
    Cbglut.bitmapCharacter Cbglut.BITMAP_HELVETICA_12 (Char.code c)) s


let display_string [|x; y;z|] s color =
(*
  let size = ref 0 in
  String.iter (fun c ->
    size := !size + Cbglut.bitmapWidth Cbglut.BITMAP_HELVETICA_12 (Char.code c)) s;
*)
  GlLight.material ~face:`both (`emission color);
  GlPix.raster_pos ~x ~y ~z ();
  String.iter (fun c ->
    Cbglut.bitmapCharacter Cbglut.BITMAP_HELVETICA_12 (Char.code c)) s

let display_message cw ch ((w,h),text,color) =
  let text = Str.split (Str.regexp "\r*\n\r*") text in
  let line_height = 20 in
  let height = List.length text * line_height in
  let width = List.fold_left (fun m line ->
    max m (
      let width = ref 0 in
      String.iter (fun c -> width :=
	!width + Cbglut.bitmapWidth  Cbglut.BITMAP_HELVETICA_12 (Char.code c)) line;
      !width)) 0 text in
  let w = if w > 0 then w else cw + w - width in
  let h = if h > 0 then h else ch + h - height in
  let i = ref 0 in
  List.iter (fun line ->
    print_string (float w) (float (h + !i*line_height)) color cw ch line;
    incr i) (List.rev text)

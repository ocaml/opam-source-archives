(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Algebra
open Expression
open Vect3
open Function
open Parameters
open Dirty
open Topology

type edge =
    { vertex1 : point;
      vertex2 : point;
      mutable status : edge_status;
      mutable middle : point;
    }

and edge_status =
    Nothing
  | Mesh_point of point
  | Divided of edge * edge

let length_edge e =
  norm (e.vertex2 -- e.vertex1)

type divide_answer =
    Subdivided
  | Triangle of (int * edge * edge * edge)

let do_topology = ref None
let do_depth = ref None

module Make_curve =
  functor (P:Computing_parameter) ->
    functor (F:Function) ->
struct

  open P
  open F

  let all_edges =
    Hashtbl.create 10001

  let get_edge v1 v2 =
    let key =
      if v1 < v2 then
	(v1, v2)
      else (v2, v1)
    in
    Hashtbl.find all_edges key

  let add_edge e =
    let v1 = e.vertex1 and v2 = e.vertex2 in
    let key =
      if v1 < v2 then
	(v1, v2)
      else (v2, v1)
    in
    Hashtbl.add all_edges key e

  let set_status e =
    let v1 = e.vertex1 and v2 = e.vertex2 in
    let f1 = F.value v1 and f2 = F.value v2 in
    if f1 *. f2 < 0.0 then
      e.status <- Mesh_point (dighotomie v1 v2)
    else if f1 = 0.0 && f2 > 0.0 then e.status <- Mesh_point v1
    else if f2 = 0.0 && f1 > 0.0 then e.status <- Mesh_point v2

  let create_edge v1 v2 =
(*
    print_string "creating edge: ";
    print_vector v1;
    print_vector v2;
*)
    let e =
      { vertex1 = v1;
	vertex2 = v2;
	status = Nothing;
	middle = [||];
      }
    in
    set_status e;
    e

  let create_shared_edge v1 v2 =
    try get_edge v1 v2
    with Not_found ->
      let e = create_edge v1 v2 in
      add_edge e;
      e

  module Cache = Cache.Make(P)


  let build_curve refine surf =
    try Cache.read [F.f;surf.poly]
    with Not_found -> begin

    let snewton dmax eps fa a =
      let rec fn fb b =
	let gfb = surf.grad b in
	let s = norm gfb in
	let rho = fb /. s in
	if abs_float rho < eps then b else
	let c = b -- (rho /. s) ** gfb in
	let d = norm (c -- a) in
	let cd = classify_float d in
	if d > dmax || cd = FP_nan  then raise Not_found;
	let fc = surf.eval c in
	fn fc c
      in
      fn fa a
    in


    let add_to_undo p ul = match !ul with
      None -> ()
    | Some l -> ul:=Some (p::l)
    in

    let do_undo ul = match !ul with
      None -> ()
    | Some l -> List.iter (fun f -> f ()) l
    in

    let cancel_undo uls =
      List.iter (fun ul -> ul:=None) uls
    in

    let undo_edge e ov () =
      e.status <- ov
    in

    let divide_edge undo_list e =
      match e.status with
	Divided (e1,e2) -> e1, e2, e1.vertex2
      | _ ->
	  let m =
	    if e.middle <> [||] then e.middle else
	    let x0 = middle e.vertex1 e.vertex2 in
	    let f0 = surf.eval x0 in
	    let len = length_edge e in
	    let m =
	      try
		snewton len epsilon f0 x0
	      with Not_found ->
		x0
	    in
	    e.middle <- m;
	    m
	  in
	  let e1 = create_edge e.vertex1 m in
	  let e2 = create_edge m e.vertex2 in
	  let old_status = e.status in
	  add_to_undo (undo_edge e old_status) undo_list;
	  e.status <- Divided(e1,e2);
	  e1,e2,m
    in

    Hashtbl.clear all_edges;

    let all_triangles = ref [] in

    let fn v1 v2 v3 =
      let e1 = create_shared_edge v2 v3 in
      let e2 = create_shared_edge v3 v1 in
      let e3 = create_shared_edge v1 v2 in
      all_triangles := (-1,e1,e2,e3)::!all_triangles
    in

    begin
      match surf.ts with
	None -> raise Exit
      | Some s -> Glarrays.iter_surface_shared fn s
    end;

    Hashtbl.clear all_edges;
(*
    let randoms v1 v2 v3 =
      if nb_random_points <= 0 then [] else
      let rec fn acc nb =
	if nb = 0 then acc
	else
	  let v = random_normed_vector () in
	  let a = v.(0) ** v1 ++ v.(1) ** v2 ++ v.(2) ** v3 in
	  fn (a::acc) (nb - 1)
      in
      fn [] nb_random_points
    in
*)
    let get_all_roots e1 e2 e3 =
      let rec fn acc e =
	match e.status with
	  Mesh_point x -> if List.memq x acc then acc else x::acc
	| Divided (e1,e2) -> fn (fn acc e1) e2
	| _ -> acc
      in
      fn (fn (fn [] e1) e2) e3
    in

    let found = ref true in
    let count = ref 0.0 and previous_print = ref 0 in
    let total = ref (Triangulation_tools.area surf.ts) in
    let num_triangles = ref (List.length !all_triangles) in
    let total_triangles = ref !num_triangles in
    let previous_triangles = ref 0 in
    let nb_min_size = ref 0 in


    let area (_,e1,e2,e3) =
      let v1 = e1.vertex1 in
      let v2 = e1.vertex2 in
      let v3 = if e2.vertex1 == v1 || e2.vertex1 == v2
      then e2.vertex2 else e2.vertex1 in
      norm (vector_prod (v2 -- v1) (v3 -- v2)) /. 2.0;
    in

    let compute = (value, grad, hessian_mat) in

    let linktbl = Hashtbl.create (match !do_topology with None -> 0 | Some _ -> 10001) in

    let rec find v =
      try
	let v' = Hashtbl.find linktbl v in
	let r = find v' in
	if r <> v' then Hashtbl.replace linktbl v r;
	r
      with Not_found ->
	v
    in
    let rec union v v' =
      let v = find v and v' = find v' in
      if v <> v' then Hashtbl.add linktbl v v'
    in
    let do_edge e =
      match !do_topology, e.status with
	Some _, Nothing -> union e.vertex1 e.vertex2
      | _ -> ()
    in

    let rec divide_triangles to_treat uls (nb_roots,e1,e2,e3 as t) =
      let roots = get_all_roots e1 e2 e3 in
      let size = length_edge e1 in
      let max_depth = size /. 2.0 < min_size in
      let len = List.length roots in
      let v1 = if e2.vertex1 == e1.vertex1 ||
	e2.vertex1 == e1.vertex2 then e2.vertex2 else e2.vertex1 in
      let vertices =
	List.map (fun v -> F.value v, v,
	  project_vector (grad v) (surf.grad v))
	  ([v1;e1.vertex1;e1.vertex2](* @randoms v1 e1.vertex1 e1.vertex2*) )
      in
      if (len > nb_roots && not max_depth &&
	  (len > 2 ||
	   let roots =
	     List.map (fun v -> 0.0, v,
	       project_vector (grad v) (surf.grad v)) roots in
	   split_cond vertices roots)) then begin
	let ul = ref (Some []) in
	let e1',e1'',m1 = divide_edge ul e1 in
	let e2',e2'',m2 = divide_edge ul e2 in
	let e3',e3'',m3 = divide_edge ul e3 in
	let v1m3,m3v2 =
	  if e3.vertex1 == e2.vertex1 ||
	    e3.vertex1 == e2.vertex2 then e3', e3'' else e3'',e3' in
	let v2m1,m1v3 =
	  if e1.vertex1 == e2.vertex1 ||
	    e1.vertex1 == e2.vertex2 then e1'', e1' else e1',e1'' in
	let v1m2,m2v3 =
	  if e2.vertex1 == e1.vertex1 ||
	    e2.vertex1 == e1.vertex2 then e2'', e2' else e2',e2'' in
	let (_,m2m3,m3m1,m1m2 as ct) =
	  -1, create_edge m2 m3, create_edge m3 m1,
	  create_edge m1 m2 in
	let t1 = (-1,m2m3, v1m2, v1m3) in
	let t2 = (-1,m3v2, v2m1, m3m1) in
	let t3 = (-1,m2v3, m1m2, m1v3) in
	let oldt = !total in
	total := !total -. area t +.
	    area t1 +. area t2 +. area t3 +. area ct ;
	num_triangles := !num_triangles + 3;
	total_triangles := !total_triangles + 3;

	let uls' = ul::uls in
	let r0 = divide_triangles true uls' ct in
	let r1 = divide_triangles true uls' t1 in
	let r2 = divide_triangles true uls' t2 in
	let r3 = divide_triangles true uls' t3 in
	try
	  let fn acc = function
	      Subdivided -> raise Exit
	    | Triangle(_,e1,e2,e3) ->
		unionq acc (get_all_roots e1 e2 e3)
	  in
	  let roots = fn (fn (fn (fn roots r0) r1) r2) r3 in
	  let len = List.length roots in
	  if  (len >= 2 || let roots =
		 List.map (fun v -> v,
		   project_vector (grad v) (surf.grad v)) roots in
	       keep_split_cond vertices roots)
	  then raise Exit
	  else begin
	    do_undo ul;
	    total := oldt;
	    num_triangles := !num_triangles - 3;
	    if len > nb_roots then
	       Triangle(len,e1,e2,e3)
	    else
	       Triangle(t)
	  end
	with Exit -> begin
	  let gn = function
	      Subdivided -> ()
	    | Triangle(t) ->
		found := true;
		all_triangles:=t::!all_triangles
	  in
	  gn r0; gn r1; gn r2; gn r3;
	  cancel_undo uls;
	  Subdivided
	end
    end else begin
      count := !count +. area t;
      if max_depth then (incr nb_min_size);
      let percent = int_of_float (!count *. 100. /. !total) in
      if percent - !previous_print >= 1 || !num_triangles - !previous_triangles > 100
	then begin
	  print_string "\r";
	  print_int percent; print_string "%, ";
	  print_int !num_triangles;
	  print_string " triangles (";
	  print_int !total_triangles;
	  print_string " tested)";
	  print_flush ();
	  previous_print := percent;
	  previous_triangles := !num_triangles;
	end;
      if to_treat then begin
	do_edge e1;
	do_edge e2;
	do_edge e3;
	treatment compute (v1,e1.vertex1,e1.vertex2);
      end;
      if len > nb_roots then
	Triangle(len,e1,e2,e3)
      else
	Triangle(t)
    end;

    in

    let first = ref true in
    let _ =
      while !found do
	found := false;
	if not !first then begin
	  print_string "\rTrying to reach fixpoint (";
	  print_int !num_triangles; print_string " triangles).     ";
	  print_newline ();
	end;
	nb_min_size := 0;
	count := 0.0; previous_print := 0;
	let fn t =
	  let r = divide_triangles !first [] t in
	  match r with
	    Subdivided -> ()
	  | Triangle(t) ->
	      all_triangles:=t::!all_triangles
	in
	let ts = !all_triangles in
	all_triangles := [];
	List.iter fn ts;
	first := false;
      done;
      print_string "\rFixpoint reached (";
      print_int !num_triangles; print_string " triangles).      ";
      print_newline ();
      if !nb_min_size <> 0 then begin
	print_string "Warning: minsize reached: ";
	print_int !nb_min_size;
	print_string " times.";
	print_newline ();
      end;
      print_string "Finished: sending to openGL.";
      print_newline ();
    in
    let ts = !all_triangles in
    all_triangles := [];
(*
    let fn (e1,e2,e3) =
      let v2,v3 = if e1.vertex1 == e2.vertex1 ||
	e1.vertex1 == e2.vertex2 then e1.vertex2, e1.vertex1 else e1.vertex1, e1.vertex2 in
      let v1 = if e3.vertex2 == v2 then
	e3.vertex1 else e3.vertex2 in
      v1,v2,v3
    in
*)
    begin match !do_topology with
      None -> ()
    | Some _ ->
(*
	let  fn (_,e1,e2,e3) =
	  let v1 = if e2.vertex1 == e1.vertex1 ||
	    e2.vertex1 == e1.vertex2 then e2.vertex2 else e2.vertex1 in
	  treatment compute (v1,e1.vertex1,e1.vertex2);
	  do_edge e1; do_edge e2; do_edge e3
	in
	let _ = List.iter fn ts in
*)
	let topotbl = Hashtbl.create 101 in
	let find_rel v =
	  try
	    Hashtbl.find topotbl v
	  with
	    Not_found -> []
	in
	let rec add_rel e =
	  match e.status with
	    Mesh_point _ ->
	      let v = find e.vertex1 and v' = find e.vertex2 in
	      let l = find_rel v in
	      let l' = find_rel v' in
	      if not (List.mem v' l) then begin
		assert (not (List.mem v l'));
		Hashtbl.replace topotbl v (v'::l);
		Hashtbl.replace topotbl v' (v::l')
	      end else
		assert (List.mem v l')
	  | Divided (e1,e2) ->
	      add_rel e1; add_rel e2
	  | _ -> ()
	in
	let  fn (_,e1,e2,e3) = add_rel e1; add_rel e2; add_rel e3 in
	let _ = List.iter fn ts in
	let extract_tbl = Hashtbl.create 101 in
	let depth_tbl = Hashtbl.create 101 in
	let get_rel v =
	  try
	    Hashtbl.find extract_tbl v
	  with
	    Not_found -> []
	in
	let extract_one () =
	  let to_rm = ref [] in
	  let fn v l =
	    match l with
	    | [parent] ->
		begin match get_rel parent with
		  l ->
		    let tv = get_rel v in
		    Hashtbl.add depth_tbl v (depth tv);
		    Hashtbl.replace extract_tbl parent (Par (get_rel v)::l);
		    Hashtbl.remove extract_tbl v;
		    to_rm := (parent, v)::!to_rm
		end
	    | _ -> ()
	  in
	  Hashtbl.iter fn topotbl;
	  let gn (parent, v) =
	    let l = find_rel parent in
(*	    assert (List.mem v l);*)
	    Hashtbl.remove topotbl v;
	    Hashtbl.replace topotbl parent (List.filter (fun v' -> v <> v') l)
	  in
	  List.iter gn !to_rm
	in
	while Hashtbl.length topotbl > 2 do
	  extract_one ()
	done;
	begin match Hashtbl.length topotbl with
	  0 ->
	    do_topology := Some []
	| 1 ->
	    Hashtbl.iter (fun v r ->
	      let r = div2_topo (normalize_topo r) in
	      Hashtbl.add depth_tbl v (depth r);
	      do_topology := Some r) extract_tbl
	| 2 ->
	    Hashtbl.iter (fun v r ->
	      let r = normalize_topo r in
	      Hashtbl.add depth_tbl v (depth r);
	      do_topology := Some r) extract_tbl
	| _ -> assert false
	end;
	match !do_depth with
	  None -> ()
	| _ ->
	    let depth v =
	      try
		Hashtbl.find depth_tbl (find v)
	      with
		Not_found -> -1
	    in
	    do_depth := Some depth
    end;

    let curve =
      let fn acc (_,e1,e2,e3) =
	let roots = get_all_roots e1 e2 e3 in
	match roots with
	  [x;y] -> (x, y)::acc
	| x::y::z::_ -> print_string "Warning at"; print_vector x; print_newline (); acc
	| _ -> acc
      in
      List.fold_left fn [] ts
    in

    let _ =
      match refine with
	None -> ()
      | Some s ->
	  let triangles_from_triangle acct (_,e1,e2,e3) =
	    let v2,v3,oe1 =
	      if e1.vertex1 == e2.vertex1 ||
		e1.vertex1 == e2.vertex2 then e1.vertex2, e1.vertex1, false
	      else e1.vertex1, e1.vertex2, true in
	    let v1,oe3 = if e3.vertex2 == v2 then
	      e3.vertex1, true else e3.vertex2, false in
	    let oe2 = if e2.vertex2 == v3 then
	      true else false in
	    let getv1 e o =
	      if o then e.vertex1 else e.vertex2 in
	    let rec gn acc e o =
	      match e.status with
		Divided (e1, e2) ->
		  if o then
		    gn (gn acc e1 o) e2 o
		  else
		    gn (gn acc e2 o) e1 o
	      | _ ->
		   getv1 e o::acc
	    in
	    let p = gn (gn (gn [] e3 oe3) e1 oe1) e2 (not oe2) in
	    triangles_from_polygones acct [p]
	  in
	  let nt = List.fold_left triangles_from_triangle [] ts in
	  s := nt
    in

    let result = [], curve, [] in
    Cache.write [F.f;surf.poly] result;

    result
    end


end

let arc_length curve p1 p2 =
  let alpha = angle (curve.grad p1) (curve.grad p2) /. 2. in
  let d = norm (p1 -- p2) in
  if alpha < 1e-10 then d else
  d *. alpha /. sin (alpha)

let length curve =
  match curve.es with None -> 0.0 | Some surface ->
    let elements = surface.Glarrays.cvertex in
    let total = ref 0.0 in
    let treat_one_component c =
      let size = Raw.length c in
      if Raw.get c ~pos:0 == Raw.get c ~pos:(size - 1) then begin
	if size < 3 then failwith "integrate: small component";
	let x0 = ref (Raw.gets_float elements
			~pos:(3 * Raw.get c ~pos:0) ~len:3) in
	let next = ref 1 in
	while !next < size do
	  let nx = Raw.gets_float elements
	      ~pos:(3 * Raw.get c ~pos:!next) ~len:3 in
	  total := !total +. arc_length curve !x0 nx;
	  x0 := nx;
	  incr next;
	done
      end
    in
    List.iter treat_one_component surface.Glarrays.celements;
    !total

#include <caml/mlvalues.h>
#include <caml/callback.h>
#include <caml/memory.h>
#include <caml/signals.h>

value normal_key_press_cb_cpointer = (value) NULL; 
void normal_key_press_cb_cfun(unsigned char arg1, int arg2, int arg3)
{
	leave_blocking_section ();
	caml_callback3(normal_key_press_cb_cpointer,Val_int(arg1),Val_int(arg2),Val_int(arg3)); 
	enter_blocking_section ();
}

CAMLprim value normal_key_press_cb_set_cpointer (value cb) {
	if (normal_key_press_cb_cpointer == cb) return Val_unit;
	if (!normal_key_press_cb_cpointer) caml_register_global_root(&normal_key_press_cb_cpointer);
	normal_key_press_cb_cpointer=cb;
	return (value) &normal_key_press_cb_cfun;
}

value normal_key_up_cb_cpointer = (value) NULL; 
void normal_key_up_cb_cfun(unsigned char arg1, int arg2, int arg3)
{
	leave_blocking_section ();
	caml_callback3(normal_key_up_cb_cpointer,Val_int(arg1),Val_int(arg2),Val_int(arg3)); 
	enter_blocking_section ();
}

CAMLprim value normal_key_up_cb_set_cpointer (value cb) {
	if (normal_key_up_cb_cpointer == cb) return Val_unit;
	if (!normal_key_up_cb_cpointer) caml_register_global_root(&normal_key_up_cb_cpointer);
	normal_key_up_cb_cpointer=cb;
	return (value) &normal_key_up_cb_cfun;
}

value special_key_press_cb_cpointer = (value) NULL; 
void special_key_press_cb_cfun(int arg1, int arg2, int arg3)
{
	leave_blocking_section ();
	caml_callback3(special_key_press_cb_cpointer,Val_int(arg1),Val_int(arg2),Val_int(arg3)); 
	enter_blocking_section ();
}

CAMLprim value special_key_press_cb_set_cpointer (value cb) {
	if (special_key_press_cb_cpointer == cb) return Val_unit;
	if (!special_key_press_cb_cpointer) caml_register_global_root(&special_key_press_cb_cpointer);
	special_key_press_cb_cpointer=cb;
	return (value) &special_key_press_cb_cfun;
}

value special_key_up_cb_cpointer = (value) NULL; 
void special_key_up_cb_cfun(int arg1, int arg2, int arg3)
{
	leave_blocking_section ();
	caml_callback3(special_key_up_cb_cpointer,Val_int(arg1),Val_int(arg2),Val_int(arg3)); 
	enter_blocking_section ();
}

CAMLprim value special_key_up_cb_set_cpointer (value cb) {
	if (special_key_up_cb_cpointer == cb) return Val_unit;
	if (!special_key_up_cb_cpointer) caml_register_global_root(&special_key_up_cb_cpointer);
	special_key_up_cb_cpointer=cb;
	return (value) &special_key_up_cb_cfun;
}

value display_all_cb_cpointer = (value) NULL; 
void display_all_cb_cfun(void)
{
	leave_blocking_section ();
	caml_callback(display_all_cb_cpointer,Val_unit); 
	enter_blocking_section ();
}

CAMLprim value display_all_cb_set_cpointer (value cb) {
	if (display_all_cb_cpointer == cb) return Val_unit;
	if (!display_all_cb_cpointer) caml_register_global_root(&display_all_cb_cpointer);
	display_all_cb_cpointer=cb;
	return (value) &display_all_cb_cfun;
}

value display_menu_cb_cpointer = (value) NULL; 
void display_menu_cb_cfun(void)
{
	leave_blocking_section ();
	caml_callback(display_menu_cb_cpointer,Val_unit); 
	enter_blocking_section ();
}

CAMLprim value display_menu_cb_set_cpointer (value cb) {
	if (display_menu_cb_cpointer == cb) return Val_unit;
	if (!display_menu_cb_cpointer) caml_register_global_root(&display_menu_cb_cpointer);
	display_menu_cb_cpointer=cb;
	return (value) &display_menu_cb_cfun;
}

value mouse_func_cb_cpointer = (value) NULL; 
void mouse_func_cb_cfun(int arg1, int arg2, int arg3, int arg4)
{
	leave_blocking_section ();
	value argv[4] = {Val_int(arg1), Val_int(arg2), Val_int(arg3), Val_int(arg4)};
	caml_callbackN(mouse_func_cb_cpointer,4,argv); 
	enter_blocking_section ();
}

CAMLprim value mouse_func_cb_set_cpointer (value cb) {
	if (mouse_func_cb_cpointer == cb) return Val_unit;
	if (!mouse_func_cb_cpointer) caml_register_global_root(&mouse_func_cb_cpointer);
	mouse_func_cb_cpointer=cb;
	return (value) &mouse_func_cb_cfun;
}

value mouse_motion_cb_cpointer = (value) NULL; 
void mouse_motion_cb_cfun(int arg1, int arg2)
{
	leave_blocking_section ();
	caml_callback2(mouse_motion_cb_cpointer,Val_int(arg1),Val_int(arg2)); 
	enter_blocking_section ();
}

CAMLprim value mouse_motion_cb_set_cpointer (value cb) {
	if (mouse_motion_cb_cpointer == cb) return Val_unit;
	if (!mouse_motion_cb_cpointer) caml_register_global_root(&mouse_motion_cb_cpointer);
	mouse_motion_cb_cpointer=cb;
	return (value) &mouse_motion_cb_cfun;
}

value reshape_cb_cpointer = (value) NULL; 
void reshape_cb_cfun(int arg1, int arg2)
{
	leave_blocking_section ();
	caml_callback2(reshape_cb_cpointer,Val_int(arg1),Val_int(arg2)); 
	enter_blocking_section ();
}

CAMLprim value reshape_cb_set_cpointer (value cb) {
	if (reshape_cb_cpointer == cb) return Val_unit;
	if (!reshape_cb_cpointer) caml_register_global_root(&reshape_cb_cpointer);
	reshape_cb_cpointer=cb;
	return (value) &reshape_cb_cfun;
}

value menu_cb_cpointer = (value) NULL; 
void menu_cb_cfun(int arg1)
{
	leave_blocking_section ();
	caml_callback(menu_cb_cpointer,Val_int(arg1)); 
	enter_blocking_section ();
}

CAMLprim value menu_cb_set_cpointer (value cb) {
	if (menu_cb_cpointer == cb) return Val_unit;
	if (!menu_cb_cpointer) caml_register_global_root(&menu_cb_cpointer);
	menu_cb_cpointer=cb;
	return (value) &menu_cb_cfun;
}


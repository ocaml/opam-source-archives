(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format

type point = float array
type vector = point
type vector4 = float * float * float * float
type vector3 = float * float * float

let tuple v = v.(0), v.(1), v.(2)

type triangle = point * point * point

let (++) [|x;y;z|] [|x';y';z'|] = [|x+.x';y+.y';z+.z'|]

let (--) [|x;y;z|] [|x';y';z'|] = [|x-.x';y-.y';z-.z'|]

let opp [|x;y;z|] = [|-.x;-.y;-.z|]

let (|.) [|x;y;z|] [|x';y';z'|] = x*.x'+.y*.y'+.z*.z'

let (//) [|x;y;z|] t = [|x/.t; y/.t; z/.t|]

let ( ** ) t [|x;y;z|] = [|x*.t; y*.t; z*.t|]

(* square of the euclidian norm *)
let norm2 x = (x |. x)
let norm x = sqrt (x |. x)

(* vectorial product *)
let vector_prod [|x;y;z|] [|x';y';z'|] =
   [|  y*.z'-.y'*.z;
   -.x*.z'+.x'*.z;
     x*.y'-.x'*.y |]

let project_vector v v' =
  v -- ((v |. v') /. norm2 v') ** v'

(* discriminant of 3 vectors *)
let det [|x;y;z|] [|x';y';z'|] [|x'';y'';z''|] =
  x*.y'*.z'' +. x'*.y''*.z +. x''*.y*.z' -. x*.y''*.z' -. x'*.y*.z'' -. x''*.y'*.z

let tetra_vol p1 p2 p3 p4 =
  abs_float (det (p2 -- p1) (p3 -- p1) (p4 -- p1))

(* middle of 2 vectors *)
let middle [|x;y;z|] [|x';y';z'|] = [|(x+.x')/.2.0;(y+.y')/.2.0;(z+.z')/.2.0|]

let pi = 2.0 *. acos(0.0)


let print_vector [|x;y;z|] =
  print_string "(";
  print_float x; print_space ();
  print_float y; print_space ();
  print_float z; print_string ")"

let print_triangle (x,y,z) =
  print_string "(";
  print_vector x; print_space ();
  print_vector y; print_space ();
  print_vector z; print_string ")"

(* angle of 2 vector (between 0 and pi) *)
let angle x y =
  let num = (x |. y) in
  if num = 0.0 then pi/.2.0 else
  let p = (num /. sqrt (norm2 x *. norm2 y)) in
  (* 0 <= p <= 1.0 is in math, not in computer science *)
  if p > 1.0 then 0.0 else
  if p < -1.0 then pi else
  acos p

let in_cube v1 v2 [|x;y;z|] =
  let in_interval a b x =
    let a,b = if a <= b then a,b else b,a in
    a <= x && x <= b
  in

  let [|xa;ya;za|] = v1 and [|xb;yb;zb|] = v2 in
  in_interval xa xb x && in_interval ya yb y && in_interval za zb z

let in_cube_strict v1 v2 [|x;y;z|] =
  let in_interval a b x =
    let a,b = if a <= b then a,b else b,a in
    a < x && x < b
  in

  let [|xa;ya;za|] = v1 and [|xb;yb;zb|] = v2 in
  in_interval xa xb x && in_interval ya yb y && in_interval za zb z

let polygone_normal = function
    [] -> assert false
  | p0::ps ->
      let rec fn acc = function
	  p::(q::_ as l) ->
	    let v = vector_prod (q -- p) (p -- p0) in
	    fn (acc ++ v) l
	| [_] ->
	    acc
	| _ -> assert false
      in fn [|0.0;0.0;0.0|] ps

let rec triangles_from_polygones acc ps =
  match ps with
  | ([] | [_] | [_;_])::ps ->
      triangles_from_polygones acc ps
  | [p1;p2;p3]::ps ->
      triangles_from_polygones ((p1,p2,p3)::acc) ps
  | polygone::ps ->
      let normal = polygone_normal polygone in
      let compute_length = function
	  [] -> assert false
	| p0::_ as ps ->
	    let rec fn acc = function
		p::(q::_ as l) ->
		  fn (acc +. norm (q -- p)) l
	      | [p] ->
		  acc +. norm (p -- p0)
	      | _ -> assert false
	    in fn 0.0 ps
      in
      let perimeter = compute_length polygone in
      let num_sd = List.length polygone in
      let num_sd' = float_of_int num_sd in
      let mesure x y z =
	let v1 = z -- y and v2 = y -- x and v3 = x -- z in
	let sn = vector_prod v1 v2 in
	let nv1 = norm v1 and nv2 = norm v2 and nv3 = norm v3 in
	let pn = nv1 +. nv2 +. nv3 in
	let sn' = normal -- sn in
	let pn' = perimeter -. nv1 -. nv2 +. nv3 in
	assert (num_sd' >=3.0);
	min ((normal |. sn) /. sin(2.0*.pi/.3.0) /. (pn *. pn) *. 3.0) ((normal |. sn') /. sin (2.0*.pi/.num_sd') /. (pn' *. pn') *. num_sd')
      in
      let find_best = function
	  p0::p1::_ ->
	    let rec fn best_pos best_mes pos = function
		p1::(p2::(p3::_ as l') as l) ->
		  let m = mesure p1 p2 p3 in
		  if m < best_mes then
		    fn (p2, l'@List.rev (p1::pos))  m (p1::pos) l
		  else
		    fn best_pos best_mes (p1::pos) l
	      | [p2;p3] ->
		  let m = mesure p2 p3 p0 in
                  let best_pos, best_mes =
		    if m < best_mes then
		      (p3,List.rev (p2::pos)), m
		    else
		      best_pos, best_mes
		  in
		  let m = mesure p3 p0 p1 in
                  let best_pos, best_mes =
		    if m < best_mes then
		      (List.hd polygone, List.tl polygone), m
		    else
		      best_pos, best_mes
		  in
		  best_pos
	      | _ -> assert false
	    in
	    fn (p0,[]) infinity [] polygone
	| _ -> assert false
      in
      let p0, remain = find_best polygone in
      let find_best' ps =
	let rec fn curnormal curper curpos best_mes best_pos = function
	    p1::(p2::_::_ as l) ->
	      let v2 = p2 -- p1 and v1 = p1 -- p0 and v3 = p2 -- p0 in
	      let sn = curnormal ++ vector_prod v2 v1 in
	      let sn' = normal -- sn in
	      let curper = curper  +. norm v2 in
	      let nv3 = norm v3 in
	      let pn = curper +. nv3 in
	      let pn' = perimeter -. pn +. 2.0 *. nv3 in
	      let nsd = float_of_int (curpos + 2) in
	      let nsd' = num_sd' -. nsd +. 2.0 in
	      assert (nsd' >=3.0);
	      assert (nsd >=3.0);
	      let m = min ((normal |. sn) /. sin(2.0*.pi/.nsd) /. (pn *. pn) *. nsd)
		  ((normal |. sn') /. sin(2.0*.pi/.nsd') /. (pn' *. pn') *. nsd') in
	      if m > best_mes then
		fn sn curper (curpos+1) m curpos l
	      else
		fn sn curper (curpos+1) best_mes best_pos l
	  | _ ->
	      best_pos
	in
	fn [|0.0;0.0;0.0|] (norm ((List.hd ps) -- p0)) 1 neg_infinity 0 ps
      in
      let pos = find_best' remain in
      let rec extract pos acc p =
	match p, pos with
	  p1::_ as l, 0 ->
	    p0::p1::acc, p0::l
	| p1::l, _ ->
	    extract (pos -1) (p1::acc) l
	| _ -> assert false
      in
      let p, p' = extract pos [] remain in
      triangles_from_polygones acc (p::p'::ps)
  | [] ->
      acc


let random_vector () =
  [| Random.float 1.0; Random.float 1.0; Random.float 1.0 |]

let random_normed_vector () =
  let v = random_vector () in
  v // norm v

 let hessian_mult [|fxx; fyy; fzz; fxy; fxz; fyz|] [|dx;dy;dz|] =
   [| dx *. fxx +. dy *. fxy +. dz *. fxz;
      dx *. fxy +. dy *. fyy +. dz *. fyz;
      dx *. fxz +. dy *. fyz +. dz *. fzz|]

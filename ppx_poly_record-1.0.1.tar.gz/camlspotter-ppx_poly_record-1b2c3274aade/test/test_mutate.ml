[%poly_record let r = { x = ref 0 } in r.x <- 1; r];;

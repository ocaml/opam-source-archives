---
name: I need help writing a pattern, or have questions
about: Please see the description and head over to Gitter for questions about usage
title: ''
labels: ''
assignees: ''

---

If you're trying to rewrite something and need help or clarification please head over to Gitter: https://gitter.im/comby-tools/community and don't post this issue. Thanks!

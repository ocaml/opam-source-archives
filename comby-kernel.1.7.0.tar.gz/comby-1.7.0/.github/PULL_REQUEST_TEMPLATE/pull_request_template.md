**Please make sure to add at least one test case for any change that is not a trivial bug fix, or a small code cleanup.**

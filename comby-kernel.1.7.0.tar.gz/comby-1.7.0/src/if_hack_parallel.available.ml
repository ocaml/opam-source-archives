let check_entry_point () =
  Scheduler.Daemon.check_entry_point ()

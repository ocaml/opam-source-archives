let check_entry_point () =
  ()

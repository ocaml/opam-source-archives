func main() {
// in a comment foo()
foo()
}

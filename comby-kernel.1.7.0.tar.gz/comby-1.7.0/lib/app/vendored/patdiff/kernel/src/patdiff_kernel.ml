module Ansi_output = Ansi_output
module Ascii_output = Ascii_output
module Comparison_result = Comparison_result
module Configuration = Configuration
module Diff_input = Diff_input
module File_name = File_name
module Float_tolerance = Float_tolerance
module Format = Format
module Html_output = Html_output
module Hunks = Hunks
module Import = Import
module Is_binary = Is_binary
module Output = Output

module Patdiff_core = Patdiff_core
module Should_keep_whitespace = Should_keep_whitespace

open! Core_kernel
include Composition_infix
module Patience_diff = Patience_diff_lib.Patience_diff

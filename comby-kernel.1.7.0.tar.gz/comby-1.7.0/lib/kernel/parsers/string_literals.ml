module Alpha = Alpha_string_literals
module Omega = Omega_string_literals

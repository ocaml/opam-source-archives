type location = Location.t
[@@deriving yojson, eq, sexp]

type range = Range.t
[@@deriving yojson, eq, sexp]

type environment = Environment.t
[@@deriving yojson]

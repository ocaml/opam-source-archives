open Ppxx.Utils (* must come after Ast_helper *)
open Ast_mapper

let make_mapper () =
  Comprehension.extend & Pattern_guard.extend & Do_.extend default_mapper

let () = Ppxx.Ppx.run [] "ppx_monadic" (fun () -> ()) make_mapper

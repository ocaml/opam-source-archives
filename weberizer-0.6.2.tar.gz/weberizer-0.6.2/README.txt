(* OASIS_START *)
(* DO NOT EDIT (digest: ee55052b9554d90713d2ecabbf7f6f55) *)
This is the README file for the weberizer distribution.

HTML templating system.

Template allows HTML templates to be compiled into OCaml modules.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/Chris00/weberizer


(* OASIS_STOP *)

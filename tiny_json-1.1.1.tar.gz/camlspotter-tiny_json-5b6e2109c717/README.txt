(* OASIS_START *)
(* DO NOT EDIT (digest: f2b2f09887d95412c91c28b889f4af1d) *)
This is the README file for the tiny_json distribution.

A small Json library from OCAMLTTER

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)

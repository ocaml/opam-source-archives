# ocp-manager

`ocp-manager` is a tool to manage multiple versions of OCaml. It is a
useful complement to work with OPAM switches.

ocp-manager is part of TypeRex, developed and maintained by OCamlPro.
Documentation to install and use this tool is available on
[http://www.typerex.org/ocp-manager.html](http://www.typerex.org/ocp-manager.html)

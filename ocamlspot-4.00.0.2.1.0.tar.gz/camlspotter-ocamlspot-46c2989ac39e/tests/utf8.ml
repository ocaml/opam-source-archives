(* UTF8 program *)

(* コメント *)

let (* txt => *) txt (* <= txt *) = "こんにちは"
let x = txt (* ? txt *)

(* コメント *)

let y = txt (* ? txt *)

(* blah blah blah blah blah blah
   blah blah blah blah blah blah
   blah blah blah blah blah blah
   blah blah blah blah blah blah
   blah blah blah blah blah blah
   blah blah blah blah blah blah
*)

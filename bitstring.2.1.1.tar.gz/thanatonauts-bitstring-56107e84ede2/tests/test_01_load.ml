(* Just check that the extension and library load without error.
 * $Id$
 *)

let _ = Bitstring.extract_bit

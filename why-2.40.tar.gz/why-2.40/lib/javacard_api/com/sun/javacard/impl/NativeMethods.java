
package com.sun.javacard.impl;


public class NativeMethods {

}
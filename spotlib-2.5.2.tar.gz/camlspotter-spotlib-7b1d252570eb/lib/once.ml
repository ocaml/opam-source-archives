type 'a t = 'a option ref

let create () = ref None

exception Already_initialized

let set x v = match !x with
  | Some _ -> raise Already_initialized
  | None -> x := Some v

let get x = !x

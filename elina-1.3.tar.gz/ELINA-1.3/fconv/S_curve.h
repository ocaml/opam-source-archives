#pragma once

void compute_curve_bounds(double x_bound, bool is_sigmoid,
                     double& k_lb, double& b_lb, double& k_ub, double& b_ub);

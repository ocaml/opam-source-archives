#pragma once

#include <vector>

std::vector<std::vector<int>> sparse_cover(int N, int K, int s);

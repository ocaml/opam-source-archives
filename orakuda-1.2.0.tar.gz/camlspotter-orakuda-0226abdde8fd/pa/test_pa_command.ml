(* 
camlp4of xlexer.cmo lexrex.cmo pa_extlex.cmo xprintf.cmo pa_format.cmo pa_command.cmo test_pa_command.ml 
*)

let _ = $`ls` ~f:(fun x -> ());;

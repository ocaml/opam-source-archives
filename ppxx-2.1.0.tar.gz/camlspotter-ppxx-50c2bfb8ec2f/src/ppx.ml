(* PPX related tools *)

open Utils
open Ast_mapper
   
let handle_error f =
  try f () with 
  | Syntaxerr.Error e ->
      !!% "%a@." Syntaxerr.report_error e;
      exit 2
  | e ->
      Format.eprintf "%a@."  Location.report_exception e;
      exit 2
      
module Debug = struct
  let impl mapper fname =
    handle_error & fun () ->
      let str = Pparse.parse_implementation ~tool_name:"ppx" Format.err_formatter fname in
      let str = mapper.structure mapper str in
      Pprintast.structure Format.std_formatter str;
      Format.fprintf Format.std_formatter "@."
  
  let intf mapper fname =
    handle_error & fun () ->
      let sg = Pparse.parse_interface ~tool_name:"ppx" Format.err_formatter fname in
      let sg = mapper.signature mapper sg in
      Pprintast.signature Format.std_formatter sg;
      Format.fprintf Format.std_formatter "@."
      
  let anonymous mapper fname = 
    if Filename.check_suffix fname ".ml" then impl mapper fname (* .mlt ? *)
    else if Filename.check_suffix fname ".mli" then intf mapper fname 
    else assert false
end

let handle_dynlinks files =
  List.fold_right (fun f files ->
    match Filename.split_extension f with
    | _, ".cmo" | _, ".cma" | _,".cmxs" | _, ".cmxa" ->
        let open Dynlink in
        begin try
          loadfile & adapt_filename f;
          files
          with Error e ->
            raise (Location.(Error (error (Printf.sprintf "Cannot load %s: %s" f (error_message e)))))
        end
    | _ -> f :: files) files []
    
(* Read the context (the parent process tool name, some command line options etc.)
   attached at the head of the top structure/signature and restore it 
   in the PPX process.
*)
let apply_context make_mapper =
  let structure _self str =
    (* I hope ocaml-migrate-parsetree already dropped the contexts *)
    (* let _str = drop_ppx_context_str ~restore:true str in *)
    let mapper = Migrate.From404.copy_mapper & make_mapper () in
    mapper.structure mapper str
  in
  let signature _self sg =
    (* I hope ocaml-migrate-parsetree already dropped the contexts *)
    (* let _sg = drop_ppx_context_sig ~restore:true sg in *)
    let mapper = Migrate.From404.copy_mapper & make_mapper () in
    mapper.signature mapper sg
  in
  { default_mapper with structure; signature }

(*
let compiler_libs_options =
  let inappropriate =
    [ "-a"
    ; "-c"
    ; "-cc"
    ; "-cclib"
    ; "-ccopt"
    ; "-compat-32"
    ; "-custom"
    ; "-dllib"
    ; "-dllpath"
    ; "-for-pack"
    ; "-g"
    (* ; "-i" *)
    ; "-linkall"
    ; "-make-runtime"
    ; "-make_runtime"
    ; "-noassert"
    ; "-noautolink"
    ; "-o"
    ; "-output-obj"
    ; "-pack"
    ; "-pp"
    ; "-ppx"
    ; "-runtime-variant"
    ; "-use-runtime"
    ; "-use_runtime"
    ; "-where"
    ; "-"
    ; "-nopervasives"
    ; "-use-prims"
    ; "-drawlambda"
    ; "-dlambda"
    ; "-dinstr"
    ]
  in
  let module Options = Compilerlib_dependent.BytecompOptions(struct
    (* These functions are never used... *)
    let impl _ = assert false
    let intf _ = assert false
    let anonymous _ = assert false
  end)
  in
  List.filter (fun (n,_,_) -> not & List.mem n inappropriate) Options.list
 *)

let run opts name make_mapper =
  let mapper = apply_context make_mapper in
  let debug = ref false in
(*
  let module Options = Compilerlib_dependent.BytecompOptions(struct
    (* These functions are never used... *)
    let impl = Debug.impl mapper
    let intf = Debug.intf mapper
    let anonymous = Debug.anonymous mapper
  end) in
 *)
  let option_list = ("-debug", Arg.Set debug, "debug mode") :: opts in
  let rev_files = ref [] in 
  Arg.parse option_list
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    name;
  try
    let files = List.rev !rev_files in
    let files = handle_dynlinks files in
    match !debug, files with
    | true, files -> List.iter (Debug.anonymous mapper) files
    | false, [infile; outfile] ->
        Ast_mapper.apply ~source:infile ~target:outfile mapper
    | _ -> 
        failwith & name ^ " infile outfile"
  with
  | Location.Error e -> Location.report_error Format.err_formatter e

let register ~name ?args make_mapper =
  Migrate_parsetree.Driver.register
    ~name
    ?args
    Migrate_parsetree.Versions.ocaml_current
    (fun config cookies -> apply_context & fun () -> make_mapper config cookies)

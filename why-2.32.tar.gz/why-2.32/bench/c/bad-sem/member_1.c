struct S { int x; } s;
void f() { s.y = 0; } /* structure has no member named y */


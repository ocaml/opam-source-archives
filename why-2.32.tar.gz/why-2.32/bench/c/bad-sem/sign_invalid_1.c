signed struct { int x; } y;


/* should error about duplicate case 0 */
/*@ ensures \result==0 */
int f (int x){

  case 0 :
    break;
  }
  return y;
}

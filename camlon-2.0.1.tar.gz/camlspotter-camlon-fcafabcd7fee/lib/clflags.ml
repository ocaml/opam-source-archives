let fast = ref false
let applicative_functors = ref false


(** position in the target tree, based on the tree of decoder/encoder *)     
module Address = struct
  type t = int list
  let top = []
  let to_list = List.rev
  let of_list = List.rev
  let add n t = n::t
end

module type S = sig
  type t
  
  module Encode : sig
    val tuple : t list -> t
    val variant : string -> t list -> t
    val record : (string * t) list -> t
  end

  module Decode : sig
    val tuple : (t * Address.t) -> (t * Address.t) list
    val variant : (t * Address.t) -> string * (t * Address.t) list
    val record : (t * Address.t) -> (string * (t * Address.t)) list
  end
end

module Make_Decode_Adrs(D : sig
  type t
  val tuple : t -> t list
  val variant : t -> string * t list
  val record : t -> (string * t) list
end) = struct

  let list_mapi f xs =
    List.rev (fst (List.fold_left (fun (rev,i) x ->
      (f x i :: rev), i+1) ([],0) xs))
    
  let tuple (t, adrs) = list_mapi (fun t i -> (t, i::adrs)) (D.tuple t)
  let variant (t, adrs) = 
    let tag, ts = D.variant t in
    tag, list_mapi (fun t i -> (t, i::adrs)) ts
  let record (t, adrs) =
    list_mapi (fun (tag,t) i -> (tag, (t, i::adrs))) (D.record t)
end


(** Decoding may fail *)
type 'target error_desc = 
  | Deconstruction_error of exn
  | Unknown_fields of string * (string * 'target) list
    (** listed fields in target record have no corresponding OCaml record fields *)
  | Required_fields_not_found of string * string list * (string * 'target) list
    (** required record fields are not found in the target value *)
  | Wrong_arity of int (** expected *) * int (** actual *) * (string * string) option
  | Primitive_decoding_failure of string

type 'target error = 'target error_desc * 'target * Address.t

type ('host, 'target) result = 
  [ `Ok of 'host 
  | `Error of 'target error
  ]

type ('host, 'target) decoder = ?adrs: Address.t -> 'target -> ('host, 'target) result
type ('host, 'target) decoder_exn = ?adrs: Address.t -> 'target -> 'host
type 'target fields = (string * ('target * Address.t)) list

let bind t f = match t with
  | `Ok v -> f v
  | `Error (err, v, adrs) -> `Error (err, v, adrs)

let (>>=) = bind

let fmap f t = match t with
  | `Ok v -> `Ok (f v)
  | `Error (err, v, adrs) -> `Error (err, v, adrs)

let mapM : ('a, 'target) decoder -> ('target * Address.t) list -> ('a list, 'target) result
= fun d xs ->
    let rec f rev_st = function
      | [] -> `Ok (List.rev rev_st)
      | (x,adrs)::xs ->
          match d ?adrs:(Some adrs) x with
          | `Ok v -> f (v::rev_st) xs
          | `Error e -> `Error e
    in
    f [] xs

external (|>) : 'a -> ('a -> 'b) -> 'b = "%revapply"

let tuple_arity_error exp_len act_len v adrs = 
  `Error (Wrong_arity (exp_len, act_len, None), v, adrs)
let variant_arity_error type_name constructor_name exp_len act_len v adrs = 
  `Error (Wrong_arity (exp_len, act_len, Some (type_name, constructor_name)), v, adrs)
let variant_unknown_tag_error type_name tag_name v adrs =
  `Error (Unknown_fields (type_name, [ tag_name, v ]), v, adrs) 
(*
let record_unknown_fields_error type_name v adrs =
  `Error (Unknown_fields (type_name, v), adrs) 
*)
let primitive_decoding_failure mes v adrs = 
  `Error (Primitive_decoding_failure mes, v, adrs)

let field_assoc name v adrs key alist (decode : (_,_) decoder) =
  try 
    let (v, adrs) = List.assoc key alist in
    decode ~adrs v
  with Not_found -> 
    `Error (Required_fields_not_found (name, [key], 
                                       List.map (fun (k,(t,_a)) -> k,t) alist), 
            v, adrs)

let field_assoc_optional _name _v _adrs key alist (decode : (_,_) decoder) =
  try 
    let (v, adrs) = List.assoc key alist in
    match decode ~adrs v with
    | `Ok v -> `Ok (Some v)
    | `Error e -> `Error e
  with Not_found -> `Ok None

let filter_record_fields type_system actual =
  List.filter (fun (f,_) -> not (List.mem f type_system)) actual 

type ('host, 'target) field_checker =
    string (** type name *)
    -> 'target (** the input *)
    -> Address.t 
    -> (string * ('target * Address.t)) list (** unknown fields *)
    -> (unit -> ('host, 'target) result) 
    -> ('host, 'target) result

let record_unknown_field_check name v adrs unknowns k = match unknowns with
  | [] -> k ()
  | _ -> `Error (Unknown_fields (name, List.map (fun (k, (v,_a)) -> k,v) unknowns), v, adrs)

let record_ignore_unknown_fields _name _v _adrs _unknons k = k ()

let integer_of_float min max conv n =
  if floor n <> n then `Error "not an integer"
  else if min <= n && n <= max then `Ok (conv n)
  else `Error "overflow"

let add_addresses base xs = 
  List.fold_left (fun (i,rev_xs) x ->
    (i+1, (x, i::base) :: rev_xs)) (0, []) xs
  |> snd 
  |> List.rev

let generic_list_of gets d ?(adrs=[]) v = match gets v with
  | Some xs -> 
      let xs = add_addresses adrs xs in
      mapM d xs
  | None -> 
      primitive_decoding_failure 
        "Meta_conv.Conv.generic_list_of: listable expected" 
        v adrs

let generic_array_of gets d ?(adrs=[]) v =
  fmap Array.of_list 
  (generic_list_of gets d ~adrs v)

let generic_option_of is_none f ?(adrs=([] : Address.t)) v =
  if is_none v then `Ok None
  else f ?adrs:(Some adrs) v >>= fun x -> `Ok (Some x)

let generic_lazy_t_of f ?(adrs=([] : Address.t)) v = 
  f ?adrs:(Some adrs) v >>= fun x -> `Ok (Lazy.from_val x)

(** Special types *)

type 'a mc_option = 'a option
type 'a mc_leftovers = (string * 'a) list

module V0 = struct
  include Amf_v0
end

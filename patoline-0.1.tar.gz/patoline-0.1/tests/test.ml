(*
  Copyright Florian Hatat, Tom Hirschowitz, Pierre Hyvernat,
  Pierre-Etienne Meunier, Christophe Raffalli, Guillaume Theyssier 2012.

  This file is part of Patoline.

  Patoline is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Patoline is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Patoline.  If not, see <http://www.gnu.org/licenses/>.
*)

=> Titre
=<

=> Un autre titre

Juste un paragraphe, qui va raconter l'aventure de TexPrime, une pationnante quête d saint grâle de la typographie.
 
=> Sous-titre 

Puis un autre paragraphe, car on peut vraiment bosser avec TexPrime. C'est vraiment chouette tout ça.

Enfin un dernier ... pour la route.
=<

Pourquoi ça ne marche pas à la fin !

Et si ça marche.

=<

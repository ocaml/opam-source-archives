# CamlON: Caml Object Notion

CamlON is JSON in OCaml, a tree like data type structure with OCaml values'
look and feel.

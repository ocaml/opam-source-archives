ppx_test : ppx replacement of pa_ounit
========================================

`Ppx_test.Location` and `Ppx_test.Longident`
==============================================

The types of source code location and module path from OCaml compiler,
are available in `Ppx_test`.

`_with_location_`
===========================

Source code location of any expression can be extracted as 
a value of `Ppx_test.Location.t` using `_with_location_` pseudo function.
`_with_location_ <exp>` is translated to `(<exp>, <location of <exp>>)`.

```ocaml
(Staying at the top directory of ppx_test)
$ ocaml -ppx ppx/ppx_test -I lib
        OCaml version 4.02.0

# _with_location_ 3;;
- : int * Location.t =
(3,
 {Location.loc_start =
   {Lexing.pos_fname = "//toplevel//"; pos_lnum = 1; pos_bol = 0;
    pos_cnum = 0};
  loc_end =
   {Lexing.pos_fname = "//toplevel//"; pos_lnum = 1; pos_bol = 0;
    pos_cnum = 1};
  loc_ghost = false})
```

`_module_path_`
===========================

`_module_path_` is a pseudo value which returns the current module path
as a value of `Ppx_test.Longident.t`.

```ocaml
(Staying at the top directory of ppx_test)
$ ocaml -ppx ppx/ppx_test -I lib
        OCaml version 4.02.0

# module M = struct let x = _module_path_ end;;
module M : sig val x : Ppx_test.Longident.t end
# M.x;;
- : Ppx_test.Longident.t =
Ppx_test.Longident.Ldot (Ppx_test.Longident.Lident "//toplevel//", "M")
```


`_for_package_`
===========================

`_for_package_` is a pseudo value of type `string option`
which returns the package name specified by comipler's `-for-package` option. 
as a value of `Ppx_test.Longident.t`.

Test expression `let %TEST name = e`
=======================================

`let %TEST name = e` is a replacement of `pa_ounit`'s `TEST name = e`.
It has the following forms:

* `let %TEST_UNIT name = e` : test whose type is unit, which replaces `TEST_UNIT name = e`
* `let %TEST name_ = e` : test whose type is unit, which replaces `TEST_UNIT name = e`
* `let %TEST name = e` : test whose type is bool, which replaces `TEST name = e`

Requirement
---------------------------------------

`let %TEST*` are translated to vanilla OCaml code which may use the following
functions:

* `Ptest.test : Ppx_test.Location.t -> string option -> (unit -> unit) -> unit`
* `Ptest.test_unit : Ppx_test.Location.t -> string option -> (unit -> unit) -> unit`

It is the client responsibility to prepare the module `Ptest` in the name space
where `let %TEST*` is used. `Ppx_test.Test` is a simple example ready to use.
`examples/wrap_pa_ounit.ml` provides a simple wrapper for `pa_ounit`.

Test names
----------------------------------------

Test names can be one of the following:

* `_` : anonymous
* `"name"` : string
* `name` : variable
* `M.X` : "constr_longident"

If a name is a string, variable or constr_longident, it is prefixed 
by the current module path. For example, in the following code,

```ocaml
(* x.ml *)
module M = struct
  let %TEST test = ...
end
```

The test has the name `X.M.test`. If the file is compiled with `-for-package P`, then it is prefixed as `P.X.M.test`.

If a name is not anonymous and ends with `_`, it is considered 
a test of type `unit`. This follows the convention of Haskell function naming (ex. `mapM_ :: Monad m => (a -> m b) -> [a] -> m ()`.)


`unit` tests
-------------------------------------------

Struct item `let %TEST_UNIT name = e`
and struct item `let %TEST name_ = e (* when name ends with _ *)`
are translated to the following

`let () = Ptest.test_unit <location of <name = e>> <name> (fun () -> <e>)`

`bool` tests
-------------------------------------------

Struct item `let %TEST name = e`
is translated to the following

`let () = Ptest.test <location of <name = e>> <name> (fun () -> <e>)`

`module` tests
-------------------------------------------

Currently there is no direct replacement of `TEST_MODULE name = struct .. end` of `pa_ounit`, since we have no simple syntax with ppx extensions for now. 
However, you can write an equivalent as follows:

```ocaml
let %TEST name = 
  let module M = struct
    ..
  end in ()
```

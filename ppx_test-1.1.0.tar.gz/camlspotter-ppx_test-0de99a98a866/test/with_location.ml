(* This is not needed but with this you can make the module compilable without -ppx ppx_test *)
let _with_location_ _ = failwith "use ppx_test" (* this should not be called *)

let (_, (_, l2)), l1 = _with_location_ (3, _with_location_ 4)

let () =
  Format.eprintf "loc1= %a@." Ppx_test.Location.format l1;
  Format.eprintf "loc2= %a@." Ppx_test.Location.format l2

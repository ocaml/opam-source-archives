open Migrate_parsetree_versions
module To404 = Convert(OCaml_current)(OCaml_404)
module From404 = Convert(OCaml_404)(OCaml_current)


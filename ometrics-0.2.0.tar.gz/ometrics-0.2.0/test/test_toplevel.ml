module Toplevel = Ometrics__Toplevel

let () =
  let open Toplevel in
  let _ = to_entries in
  ()

let tests = ("Toplevel", [])

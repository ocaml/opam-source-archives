module Misc = Ometrics__Misc

let () =
  let open Misc in
  let _ = is_documented in
  ()

let tests = ("Misc", [])

let dbg f = Format.kasprintf (Printf.eprintf "[ometrics] %s\n") f

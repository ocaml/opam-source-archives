int keep() {
  return 27;
}

int main() {
  return 27;
}

int main() {
  return 27;
}

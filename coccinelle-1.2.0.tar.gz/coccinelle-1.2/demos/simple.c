int main(int i) {
  f("ca va");
  f(g("ca va pas"));
}

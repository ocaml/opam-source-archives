int x;

int main(int y) {
  int z;
  return x + y + z;
}

void main(int i)
{
	list_for_each_safe(a,b,c)
		i++;


	list_for_each(a,b)
		i++;

}

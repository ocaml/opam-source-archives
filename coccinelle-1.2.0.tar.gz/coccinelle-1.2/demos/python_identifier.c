int main () {
  one(12);
  one_more(15);
  another_one(20);
  two(1,2);
  two_more(3,4);
  three(1,2,3);
}

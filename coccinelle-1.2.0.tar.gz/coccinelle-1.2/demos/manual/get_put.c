void main(int i)
{

  get();
  if(1) {
    put();
  }
  put();
}

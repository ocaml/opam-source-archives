exception Semantic of string * Common.parse_info

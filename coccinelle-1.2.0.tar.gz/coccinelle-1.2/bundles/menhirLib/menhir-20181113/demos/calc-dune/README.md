This demo is identical to the `calc` demo
but uses dune instead of ocamlbuild.

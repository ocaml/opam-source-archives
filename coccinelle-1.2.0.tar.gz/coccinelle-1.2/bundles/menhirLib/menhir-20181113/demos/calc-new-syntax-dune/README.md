This demo illustrates the new rule syntax,
and heavily exploits parameterized symbols.

### 7.3.5 (2018-10-25)

  * Switched to dune, dune-release, and OPAM 2.0


### 7.3.4 (2017-11-22)

  * Improved finalization of regular expressions and tables for better
    performance


### 7.3.3 (2017-10-17)

  * Fixed external declaration bug in internal regexp compile function


### 7.3.2 (2017-10-10)

  * Improved compatibility with MSVC


### 7.3.1 (2017-10-08)

  * Used untagged integers when declaring external functions


### 7.3.0 (2017-07-27)

  * Switched to jbuilder and topkg

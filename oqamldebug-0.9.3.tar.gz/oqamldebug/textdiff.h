#ifndef TEXTDIFF_H
#define TEXTDIFF_H
#include <QString>

QString htmlDiff( const QString &cur, const QString &ref );

#endif


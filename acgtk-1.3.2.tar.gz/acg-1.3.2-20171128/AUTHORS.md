The **ACGtk** software package is developped by the [SÉMAGRAMME](http://semagramme.loria.fr) team of the [INRIA Nancy - Grand Est](https://www.inria.fr/centre/nancy) and [LORIA](http://www.loria.fr) (former [CALLIGRAMME](http://calligramme.loria.fr) team).

Main authors of the ACG software code are:
- [Philippe de Groote](http://members.loria.fr/philippe.degroote)
- [Jiří Maršík](http://jirka.marsik.me/)
- [Sylvain Pogodalla](http://members.loria.fr/sylvain.pogodalla)
- [Sylvain Salvati](http://www.labri.fr/perso/salvati/)


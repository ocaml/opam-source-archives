# OPAMFind : Making a bridge between OCamlFind and OPAM package systems

OPAMFind is a library to analyze the installed OCamlFind and OPAM packages
and obtain the relationship between them: which OCamlFind package is installed
by which OPAM package.

# Requirements

## `system` switch does not work

OCaml compiler's stdlib must be installed under OPAM directory (normally
`$HOME/.opam`.  This means OPAMFind does not work with `system` switch.

## `OPAMKEEPBUILDDIR=yes`

The analysis of OCamlFind and OPAM package relationships is done by checksums
of some key files (META and .cmi files) in OCamlFind installation directories
and OPAM build directories.  Therefore the build files created by `opam install`
must be preserved, by setting `OPAMKEEPBUILDDIR=yes` for example.

# Typical usage

```ocaml
open Opamfind

let result =
  let stdlib_dir, ocamlfinds, opam_switch = Opamfind.Assoc.init () in
  let ocamlfind_analyzed_groups = Ocamlfind.group_and_analyze ~stdlib_dir ocamlfinds in
  let opams = Opam.get_intalled opam_switch in
  Opamfind.Assoc.associate ocamlfind_analyzed_groups opams
```

Currently OPAMFind does not depend on opam-lib package, all the information
of OPAM is obtained by executing `opam` command.

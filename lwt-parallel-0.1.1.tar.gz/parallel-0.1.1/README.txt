(* OASIS_START *)
(* DO NOT EDIT (digest: d6200166caaa6dac811a59a7ae3556a6) *)

lwt-parallel - Lwt-enabled parallel computing library
=====================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

lwt-parallel is distributed under the terms of the MIT License.

(* OASIS_STOP *)

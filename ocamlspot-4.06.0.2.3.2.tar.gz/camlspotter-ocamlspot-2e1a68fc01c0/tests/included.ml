module type (* S => *) S (* <= S *) = sig val x : int end

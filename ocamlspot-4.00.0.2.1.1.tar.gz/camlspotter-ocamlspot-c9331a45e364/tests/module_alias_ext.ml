open Module_alias

module M3 = M2 (* ? M0 *)

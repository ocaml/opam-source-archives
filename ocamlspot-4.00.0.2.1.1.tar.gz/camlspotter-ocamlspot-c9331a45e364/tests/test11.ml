let _ = Test10.x (* ? x *) (* FIXED bug : include hided previously defined *)
let _ = Test10.y (* ? M.y *) (* FIXED bug : include hided previously defined *)

let f = function
  | X -> 1
  | X | Y -> 2
  | X -> 1
  | (X | Y) -> 3
  | X -> 1
  | Y -> 
      1
  | Y -> 1
           2
  | _ -> Z
  | ( X 
    | Y
    | Z ) -> 4


let rec lparen_read_ahead lnum str =
  match Filter.destr str with
  | None -> false
  | Some (i, _) when Region.lnum i.Filter.region <> lnum -> false
  | Some (i, str) ->
      match i.Filter.token with
      | FUN -> false
      | FUNCTION -> false
      | COMMENT -> lparen_read_ahead lnum str
      | _ -> true

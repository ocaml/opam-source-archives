let x y =
  1, 2

let x y =
  1, 
  2

let x y = 1
  , 2 

let x y = 1,
  2 

let x y = ( 1
          , 2) 

let x y = ( 1,
            2 )

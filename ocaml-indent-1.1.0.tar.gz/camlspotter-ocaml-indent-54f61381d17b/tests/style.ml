(************************************************** Parens *)

(* ( / { / [ + newline does not move the indent to the token's column,
   but just shifts the indent.

   Comments are allowed between the parens and newline.
*)

let _ = ( (* indent += 2 *)
  1,
  2,
  3
) (* closing corresponds the line indent of the opening *)
  
(* Paren-20: If something follows after (, {, [ in the line, 
   these open-parens introduce a block.
   The indent is moved to the columns of the open-parens.
*)

let _ = ( 1,
          2,
          3 
        ) (* closing corresponds the line indent of the opening *)

(* See the same in type definitions *)

type t = { x : foo;
           y : boo 
         }

type t = {
  x : foo;
  y : boo;
}

(* begin/end *)

(* begin looks like (, but not exactly. It does not follow Paren-20,
   since begin/end are not used for tuples but for codes, mainly. 
 *)
let _ = begin 1,
  2,
  3
end

let _ = begin 
  1,
  2,
  3
end

(************************************************** Commas *)

(* Comma w/ an open-paren uses the pos of the paren *)
let x = ( 1, 
          2 )

(* Commas-20: Comma w/o an open-paren shifts the current indent *)
let x = 1, 
  2        (* Having the same indentation as the version w/ paren is,
              actually hard. *)

(* Comma w/ paren unwinds the indentation to the paren *)
let x = ( 1
        , 2 )  

(* Comma is not separator of list elements, so 
   it cannot unwinds the level upto [ *)
let x = [ 1
          , 2,
          3 ]  

let x = { x = 1, 
          2 } (* Hmmm, I do not like this, but it follows Commas-20 *)

(************************************************** Semis *)

let x = [ 1;
          2 ]

let x = f;
  g

let f = [ 1
        ; 2
        ; 3
        ]
         
let f = [
; 1
; 2
; 3
]

let x = begin
  f;
  g;
  h;
end

let x = begin f;
  g;
; h
end

let x = { x = 1;
          y = 2;
        ; z = 3 
        }

let x = { 
  x = 1;
  y = 2;
; z = 3 
}

(*************************************************************** fun *) 

let f = fun x y z w -> (* fun does not introduce a block *)
  x y z w

let f = fun x -> g x (* but if there is a code after ->, it overrides *)
                   y

(********************************************************** function *) 

let f = function X -> 1 
               | Y -> 2 

let f = function 
    X -> 1 
  | Y -> 2 

let f = function 
  | X -> 1 
  | Y -> 2 

let f = 
  zzz (function 
    | X -> 1
    | Y -> 2
  )

let f = 
  zzz (function X -> 1
              | Y -> 2
      )

(************************************************************* match *) 

let x = match y with
  | X -> 1
  | Y -> 2

let x = 
  match y with
  | X -> 1
  | Y -> 2

let x = match y with X -> 1
                   | Y -> 2

(******************************************************** OR pattern *) 

let x = match y with
  | X | Y -> 1
  | Z 
  | W -> 2
  | ( A | B ) -> 3
  | ( A |
      B
    | C ) -> 4

(****************************************************** struct / sig *)

module X = struct
  let x = 1
end

module X = 
  struct
    let x = 1
  end

module X : sig
  val x : int
end = struct
  let x = 1
end

module type X = sig
  val x : int
end

module type X = 
  sig
    val x : int
  end




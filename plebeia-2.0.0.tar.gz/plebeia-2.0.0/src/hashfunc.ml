module Blake2B(A : sig
    val bytes : int
  end) = struct
  open Hacl_star

  let () =
    if A.bytes < 1 || A.bytes > 64 then
      invalid_arg "Blake2B.Make: bytes must be between 1 and 64"

  let key = Bytes.create 0

  let hash_bytes inbuf =
    (* HACL* doesn't yet provide a multiplexing interface for Blake2b so we
     * perform this check here and use the faster version if possible *)
    if AutoConfig2.(has_feature VEC256) then
      Hacl.Blake2b_256.hash ~key inbuf A.bytes
    else Hacl.Blake2b_32.hash ~key inbuf A.bytes

  let hash_string inbuf =
    Bytes.unsafe_to_string @@ hash_bytes @@ Bytes.unsafe_of_string inbuf

  let hash_strings ss = hash_string (String.concat "" ss)
end

module Blake3(A : sig
    val bytes : int
  end) = struct

  let () =
    if A.bytes < 1 then
      invalid_arg "Blake3.Make: bytes must be between 1 and 2^64-1"

  let hash_bytes inbuf =
    let outbuf = Blake3.hash A.bytes inbuf in
    outbuf

  let hash_string inbuf =
    Bytes.unsafe_to_string @@ hash_bytes @@ Bytes.unsafe_of_string inbuf

  let hash_strings ss = hash_string (String.concat "" ss)
end

let blake2b bytes = (module Blake2B(struct let bytes = bytes end) : Hashfunc_intf.S)
let blake3 bytes = (module Blake3(struct let bytes = bytes end) : Hashfunc_intf.S)

let make = function
  | `Blake2B -> blake2b
  | `Blake3 -> blake3

module Env = struct
  let flag name =
    try
      Sys.getenv name <> ""
    with
    | Not_found -> false

  let one_of name kvs =
    let vo = try Some (Sys.getenv name) with Not_found -> None in
    match vo with
    | None -> None
    | Some k ->
        match List.assoc_opt k kvs with
        | Some v -> Some v
        | None -> failwith (Printf.sprintf "%s: invalid value" name)

  let int name =
    let vo = try Some (Sys.getenv name) with Not_found -> None in
    match vo with
    | None -> None
    | Some n ->
        match int_of_string n with
        | v -> Some v
        | exception _ -> failwith (Printf.sprintf "%s: <INT>" name)

  let bool name =
    let vo = try Some (Sys.getenv name) with Not_found -> None in
    match vo with
    | None -> None
    | Some n ->
        match bool_of_string n with
        | v -> Some v
        | exception _ -> failwith (Printf.sprintf "%s: <true/false>" name)
end

(* Do not use this in production *)
let use_reachable_words = Env.flag "PLEBEIA_USE_REACHABLE_WORDS"

let madvise_read_ahead = Env.flag "PLEBEIA_READ_AHEAD"

let count_segments = Env.flag "PLEBEIA_SEGMENT_COUNT"

let cell_bytes_override = Env.int "PLEBEIA_CELL_BYTES_OVERRIDE"
let hash_bytes_override = Env.int "PLEBEIA_HASH_BYTES_OVERRIDE"
let hash_function_override = Env.one_of "PLEBEIA_HASH_FUNCTION_OVERRIDE" ["blake2b", `Blake2B; "blake3", `Blake3]
let keep_hash_override = Env.bool "PLEBEIA_KEEP_HASH_OVERRIDE"

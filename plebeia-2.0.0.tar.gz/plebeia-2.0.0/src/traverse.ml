open Node_type

module Iter : sig
  (** Iteration.  Parent nodes are iterated before their subnodes.
  *)

  type state

  val iter :
    (t -> [`Continue of view | `Return of unit ]) ->
    t -> unit

  val iter_interleaved :
    (t -> [`Continue of view | `Return of unit ]) ->
    t ->
    (state -> [`Left of state | `Right of unit ]) * state

end = struct
  type job = t

  type state = job list

  let step enter js =
    match js with
    | [] -> `Right ()
    | n::js ->
        (* traversal of n *)
        match enter n with
        | `Return () -> `Left js
        | `Continue v ->
            (* continue as v, not as n itself *)
            match v with
            | Leaf _ -> `Left js
            | Bud (None, _, _) -> `Left js
            | Bud (Some n, _, _) ->
                `Left (n :: js)
            | Extender (_, n, _, _) ->
                `Left (n :: js)
            | Internal (nl, nr, _, _) ->
                `Left (nl :: nr :: js)

  let iter_interleaved enter n =
    let js = [n] in
    let stepper x = step enter x in
    stepper, js

  let iter enter n =
    let rec loop js = match step enter js with
      | `Right res -> res
      | `Left js -> loop js
    in
    loop [n]
end

module Map : sig
  type state

  val map :
    enter:(t -> [`Continue of view | `Return of t ]) ->
    leave:(org:view -> view -> t) ->
    t -> t

  val map_interleaved :
    enter:(t -> [`Continue of view | `Return of t ]) ->
    leave:(org:view -> view -> t) ->
    t ->
    (state -> [`Left of state | `Right of t ]) * state

end = struct
  type job =
    | Do of t
    | BudSome of view
    | Extender of view * Segment.t
    | Internal of view

  type state = job list * t list

  let step ~enter ~leave (js, ns) =
    match js, ns with
    | [], [n] -> `Right n
    | [], _ -> assert false
    | BudSome v::js, n::ns ->
        let v' = _Bud (Some n, Not_Indexed, Not_Hashed) in
        let n = leave ~org:v v' in
        `Left (js, (n::ns))
    | Extender (v, seg)::js, n::ns ->
        let v' = _Extender (seg, n, Not_Indexed, Not_Hashed) in
        let n = leave ~org:v v' in
        `Left (js, (n::ns))
    | Internal v::js, nr::nl::ns ->
        let v' = _Internal (nl, nr, Not_Indexed, Not_Hashed) in
        let n = leave ~org:v v' in
        `Left (js, (n::ns))
    | (BudSome _ | Extender _ | Internal _)::_, _ -> assert false
    | Do n::js, ns ->
        (* traversal of n *)
        match enter n with
        | `Return n -> `Left (js, (n::ns))
        | `Continue v ->
            (* continue as v, not as n itself *)
            match v with
            | Leaf _ ->
                let n = leave ~org:v v in
                `Left (js, n::ns)
            | Bud (None, _, _) ->
                let n = leave ~org:v v in
                `Left (js, n::ns)
            | Bud (Some n, _, _) ->
                `Left ((Do n :: BudSome v :: js), ns)
            | Extender (seg, n, _, _) ->
                `Left ((Do n :: Extender (v, seg) :: js), ns)
            | Internal (nl, nr, _, _) ->
                `Left ((Do nl :: Do nr :: Internal v :: js), ns)

  let map_interleaved ~enter ~leave n =
    let js_ss = [Do n], [] in
    let stepper x = step ~enter ~leave x in
    stepper, js_ss

  let map ~enter ~leave n =
    let rec loop js_ss = match step ~enter ~leave js_ss with
      | `Right res -> res
      | `Left js_ss -> loop js_ss
    in
    loop ([Do n], [])
end

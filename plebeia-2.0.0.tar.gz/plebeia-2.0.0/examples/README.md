# Examples
## git-interp
An example of use of `Plebeia.Fs` (FileSystem module).
Manipulates a plebeia tree via `Fs` by interpreter-style.

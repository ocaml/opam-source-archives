open Plebeia
open Test_utils
open Cursor

(* XXX The first half is a copy of test_full_deep_random.ml *)
let test () =
  with_random @@ fun st ->
  let removed = ref 0 in
  for _i = 0 to 15 do
    run_ignore_lwt @@ with_cursor @@ fun c ->
    let c, _ops = Do_random.Deep.do_random st 500 c in
    let leaves = get_leaves c in
    let empty_buds = get_empty_buds c in
    let c = List.fold_left (fun c p ->
        let c = from_Ok @@ Deep.subtree c @@ Path.to_segments p in
        match c with
        | Cursor (Top, _, _, _) -> c (* we cannot remove the top *)
        | _ ->
            let c = Error.from_Ok @@ Cursor.remove_empty_bud c in
            Cursor.go_top c) c empty_buds
    in
    let leaves' = get_leaves c in
    let empty_buds' = get_empty_buds c in
    if not @@ SegmentListSet.equal leaves leaves' then begin
      prerr_endline "leaves";
      List.iter (fun segs ->
          prerr_endline @@ String.concat "/" (List.map Segment.to_string segs))
        (SegmentListSet.elements leaves);
      prerr_endline "AND...";
      prerr_endline "leaves'";
      List.iter (fun segs ->
          prerr_endline @@ String.concat "/" (List.map Segment.to_string segs))
        (SegmentListSet.elements leaves');
    end;
    assert (SegmentListSet.equal leaves leaves');
    assert (empty_buds' = []);
    removed := !removed + List.length empty_buds;

    ignore begin
      List.fold_left (fun (c, old_leaves) leaf ->
          let c = Error.from_Ok @@ Deep.delete_and_clean_empty c leaf in
          let c = Cursor.go_top c in
          let empty_buds = get_empty_buds c in
          let new_leaves = get_leaves c in
          assert (empty_buds = []);

          if not @@ SegmentListSet.equal old_leaves (SegmentListSet.add leaf new_leaves) then begin
            prerr_endline "leaves";
            List.iter (fun segs ->
                prerr_endline @@ String.concat "/" (List.map Segment.to_string segs))
              (SegmentListSet.elements old_leaves);
            prerr_endline "AND...";
            prerr_endline "leaves'";
            List.iter (fun segs ->
                prerr_endline @@ String.concat "/" (List.map Segment.to_string segs))
              (SegmentListSet.elements new_leaves);
          end;

          Format.eprintf "#new_leaves = %d@." (List.length (SegmentListSet.elements new_leaves));

          assert (SegmentListSet.equal (SegmentListSet.add leaf new_leaves) old_leaves);
          (c, new_leaves)) (c, leaves) @@ Gen.shuffle (SegmentListSet.elements leaves) st
    end
  done;
  Format.eprintf "Removed %d empty buds@." !removed


let () =
  let open Alcotest in
  run "remove_empty_bud"
    ["remove_empty_bud", ["test", `Quick, test]]

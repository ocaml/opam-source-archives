open Plebeia
open Test_utils

let unit_test () =
  ignore @@ with_context @@ fun ctxt ->
  let h = ctxt.hash in
  let c = Cursor.empty ctxt in
  (function Ok x -> x | Error e -> Format.eprintf "Error: %a@." Error.pp e; Error.raise e) @@
  let open Result.Op in
  let* c = Cursor.set_hashonly c (from_Some @@ Segment.of_string "LRL") (h.zero, "1") in
  let* c = Cursor.set_hashonly c (from_Some @@ Segment.of_string "LLR") (h.zero, "2") in
  let* c = Cursor.upsert c (from_Some @@ Segment.of_string "LLR") (Value.of_string "y") in
  Ok (Debug.save_cursor_to_dot "hashonly1.dot" c)

let () =
  let open Alcotest in
  run "api" [
    "hashonly", [ "unit_test", `Quick, unit_test ] ]

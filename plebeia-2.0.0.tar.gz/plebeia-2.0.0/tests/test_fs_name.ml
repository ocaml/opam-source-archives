open Plebeia.Internal
open Test_utils

module P = Plebeia

module NameCompressed = Fs.NameCompressed

let test () =
  List.iter NameCompressed.test ["hello"; "world"; "data"; "contracts"; "big_map"; "-2"];
  List.iter NameCompressed.test (List.init 100 string_of_int);
  with_random @@ fun rng ->
  for _ = 0 to 100 do
    let h =
      let open Gen in
      let open Gen.Infix in
      string (int 10 >|= fun i -> i * 2 + 16)
        (elements ['0'; '1'; '2'; '3'; '4'; '5'; '6'; '7'; '8'; '9';
                   'a'; 'b'; 'c'; 'd'; 'e'; 'f']) rng
    in
    NameCompressed.test h;
    NameCompressed.test ("-" ^ h);
  done

let test_init () =
  with_random @@ fun rng ->
  for _ = 0 to 100 do
    let hl, segl =
      let rec loop () =
        let f i =
          let open Gen in
          let open Gen.Infix in
          let str = string (int 10 >|= fun i -> i * 2 + 16) alpha_numeric rng in
          if i = 0 then (* To fail below exception *) "x" ^ str else str
        in
        let hl = List.init 10 f in
        (* Hash collision may occur *)
        match List.map NameCompressed.to_segment hl with
        | exception _ -> loop ()
        | segl -> hl, segl
      in
      loop ()
    in
    NameCompressed.init [];
    let exception Assert_is_not_raised in
    begin try
        let _ = NameCompressed.of_segment (List.hd segl) in
        raise Assert_is_not_raised
      with
      | Assert_is_not_raised as e -> raise e
      | _e -> ()
    end;
    NameCompressed.init hl;
    let hl' = List.map (fun seg -> from_Some @@ NameCompressed.of_segment seg) segl in
    assert (hl = hl')
  done


let () =
  let open Alcotest in
  run "fs_name"
    ["unit", [ "test", `Quick, test
             ; "test2", `Quick, test_init]
    ]

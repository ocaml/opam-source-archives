# Branches

* `master`: MUST compile, standalone.
* `tezos`: MUST compiles under `vendors/` directory of Tezos source code.

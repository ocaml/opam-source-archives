======================================
Planck: Parser LANguage Combinator Kit
======================================

Tiny Parsec in OCaml.

Requirements
============

Planck version 2.1.0, what you require are:

* ocaml 4.00.1
* ocamlfind
* spotlib 2.1.2
* omake
* sexplib 108.07.00

Install
=======

1. set PREFIX env var
2. yes no | omake --install
3. omake

let x = t.desc <- 1 (* t.desc is parsed by simple_expr... though the exp must be parsed by expr_11 *)


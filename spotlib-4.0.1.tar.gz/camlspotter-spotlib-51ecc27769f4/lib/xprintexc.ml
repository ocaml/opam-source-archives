let prerr_endline exc = prerr_endline (Printexc.to_string exc)

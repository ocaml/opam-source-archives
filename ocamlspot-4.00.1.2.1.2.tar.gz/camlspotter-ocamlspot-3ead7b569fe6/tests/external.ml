external ext : int -> int = "ext"

let _ = ext
let _ = Target.external_value


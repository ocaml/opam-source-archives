class x = object
end

let _ = new x

type ('a, 'b) result = [ `Ok of 'a | `Error of 'b ]

let failwithf fmt = Printf.kprintf failwith fmt
let invalid_argf fmt = Printf.kprintf invalid_arg fmt

let memoize f =
  let cache = Hashtbl.create 101 in
  fun v -> try Hashtbl.find cache v with Not_found ->
    let r = f v in
    Hashtbl.replace cache v r;
    r

let memoize_rec f =
  let cache = Hashtbl.create 101 in
  let rec g v = 
    try Hashtbl.find cache v with Not_found ->
      let r = f g v in
      Hashtbl.replace cache v r;
      r
  in
  g

external (&) : ('a -> 'b) -> 'a -> 'b = "%apply"
external (&~) : (f:'a -> 'b) -> 'a -> 'b = "%apply"
external (|!) : 'a -> ('a -> 'b) -> 'b = "%revapply"
external (|>) : 'a -> ('a -> 'b) -> 'b =  "%revapply"

let ( ** ) f g = fun x -> f (g x)
external power : float -> float -> float = "caml_power_float" "pow" "float"

external id : 'a -> 'a = "%identity"
external (!&) : _ -> unit = "%ignore"

exception Finally of exn * exn
;;

(* CR jfuruse: looks lousy... *)
let protect ~f v ~(finally : 'a -> unit) =
  let res =
    try f v
    with exn ->
      (try finally v with final_exn -> raise (Finally (exn, final_exn)));
      raise exn
  in
  finally v;
  res
;;

let catch ~f v = try `Ok (f v) with e -> `Error e;;

let try_ignore ~f v = try f v with _ -> ();;
let try_bool ~f v = try ignore (f v); true with _ -> false

let with_final v f final =
  match try `Ok (f v) with e -> `Error e with
  | `Ok res -> final v; res
  | `Error e -> try_ignore ~f:final v; raise e

let time f v =
  let start = Unix.gettimeofday () in
  let res = f v in
  let end_ = Unix.gettimeofday () in
  res, end_ -. start

let imp init f =
  let r = ref init in
  let res = f r in
  !r, res

let imp_ init f = fst (imp init f)
 
(* Printf *)
let sprintf = Printf.sprintf
let (!%) = Printf.sprintf

let with_ref r v f =
  let back_v = !r in
  r := v;
  protect ~f () ~finally:(fun () -> r := back_v)

let from_Ok = Result.from_Ok
let result = Result.result
let from_Some = Option.from_Some

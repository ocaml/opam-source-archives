let lowercase = String.lowercase

let mapi = List.mapi

let lazy_from_fun = Lazy.from_fun

let lowercase = String.lowercase_ascii

let mapi = List.mapi

let lazy_from_fun = Lazy.from_fun

module P = Omd_parser.Default_env(struct end)
module Parser = Omd_parser.Make(P)

let () =
  let msg = String.create 1916 in
  for x = 0 to String.length msg - 1 do
    if x land 1 <> 0 then msg.[x] <- ' ' else msg.[x] <- 'x'
  done;
  print_endline msg;
  msg |> Omd_lexer.lex |> Parser.parse |> ignore

open Base
open String

let index_opt s c = try Some (index s c) with Not_found -> None

let rec index_rec s lim i c =
  if i >= lim then None else
    if String.unsafe_get s i = c then Some i else index_rec s lim (i +
  1) c
;;
  
let index_from_to s from to_ c =
  let l = String.length s in
  if from < 0 || from > to_ || to_ >= l then 
    invalid_arg "Xstring.index_from_to" 
  else
    index_rec s (to_+1) from c
;;

let chop_newline s =
  let len = String.length s in
  if len > 1 && s.[len-1] = '\n' then
    if len > 2 && s.[len-2] = '\r' then String.sub s 0 (len-2)
    else String.sub s 0 (len-1)
  else s

let sub_from_to s from to_ = 
  if from > to_ then invalid_arg "sub_from_to";
  String.sub s from (to_ - from + 1)

let split_by_newline s =
  let length = String.length s in
  let rec aux st start_pos pos = 
    if pos = length then List.rev st else match s.[pos] with
    | '\r' | '\n' -> 
        let st = String.sub s start_pos (pos - start_pos) :: st in
        skip st (pos+1)
    | _ -> aux st start_pos (pos+1)
  and skip st pos = 
    if pos = length then List.rev st else match s.[pos] with
    | '\r' | '\n' -> skip st (pos+1)
    | _ -> aux st pos (pos+1)
  in
  aux [] 0 0

(* split a string according to char_sep predicate *)
let split char_sep str =
  let len = String.length str in
  if len = 0 then [] else
    let rec skip_sep cur =
      if cur >= len then cur
      else if char_sep str.[cur] then skip_sep (succ cur)
      else cur  in
    let rec split beg cur =
      if cur >= len then 
	if beg = cur then []
	else [String.sub str beg (len - beg)]
      else if char_sep str.[cur] 
	   then 
	     let nextw = skip_sep cur in
	      (String.sub str beg (cur - beg))
		::(split nextw nextw)
	   else split beg (succ cur) in
    let wstart = skip_sep 0 in
    split wstart wstart

let make1 = String.make 1

module Set = Xset.Make(struct type t = string let compare (x:string) y = compare x y end)

module Pervasives = struct
  let chop_newline = chop_newline
  let split_by_newline = split_by_newline
end

let split_at len str = String.sub str 0 len, String.sub str len (String.length str - len)

TEST_UNIT "Xstring.split_at" = 
    assert (split_at 3 "hello world" = ("hel", "lo world"))
;;

let take len str = String.sub str 0 len
let prefix = take
let drop len str = String.sub str len (String.length str - len)
let drop_postfix len str = String.sub str 0 (String.length str - len)

TEST_UNIT "Xstring.drop_postfix" = 
    assert (drop_postfix 6 "hello world" = "hello")
;;

let postfix len str = 
  let l = String.length str in
  String.sub str (l-len) len

TEST_UNIT "Xstring.drop_postfix" = 
    assert (postfix 5 "hello world" = "world")
;;

let is_prefix' ?(from=0) sub str =
  let sublen = String.length sub in
  try 
    if String.sub str from sublen = sub then Some (drop (from + sublen) str)
    else None
  with _ -> None

TEST_UNIT "Xstring.is_prefix'" = 
    assert (is_prefix' "hello" "hello world" = Some " world")
;;

let is_prefix ?(from=0) sub str =
  let sublen = String.length sub in
  try 
    String.sub str from sublen = sub
  with _ -> false

TEST_UNIT "Xstring.is_prefix" = 
    assert (is_prefix "hello" "hello world")
;;

let contains ?from:(pos=0) ~needle:sub str =
  let str_len = String.length str in
  let sub_len = String.length sub in
  if pos + sub_len > str_len then false
  else 
    let rec iter pos = 
      if pos + sub_len > str_len then false
      else if is_prefix ~from:pos sub str then true
      else iter (pos+1)
    in
    iter pos

TEST_UNIT "Xstring.contains" = 
    assert (contains ~needle:"hello" "hello world")
    assert (contains ~needle:"hello" "bye world" = false)
    assert (contains ~needle:"shindanmaker.com" "http://shindanmaker.com/341161")
;;    

let is_postfix sub str =
  let sublen = String.length sub in
  try postfix sublen str = sub with _ -> false
  
TEST_UNIT "Xstring.is_postfix" = 
    assert (is_postfix "world" "hello world")
;;

let is_postfix' sub str =
  let sublen = String.length sub in
  try
    if postfix sublen str = sub then Some (drop_postfix sublen str)
    else None
  with _ -> None

TEST_UNIT "Xstring.is_postfix" = 
    assert (is_postfix' "world" "hello world" = Some "hello ")
;;

let index_string_from str pos sub =
  let sub_len = String.length sub in
  if sub_len = 0 then pos 
  else 
    let limit = String.length str - sub_len in
    let rec iter i = 
      if i > limit then raise Not_found
      else if contains str ~from:i ~needle:sub then i
      else iter (i+1)
    in
    iter pos

let scani_left f acc ?from ?to_ s = 
  let from = Option.default from (fun () -> 0) in
  let to_ = Option.default to_ (fun () -> String.length s - 1) in
  let rec fold acc pos = 
    if pos >= to_ then acc
    else 
      match f pos acc & String.unsafe_get s pos with
      | `Continue acc -> fold acc & pos + 1
      | `Stop acc -> acc
  in
  fold acc from
    
let foldi_left f acc s = scani_left f acc s

module Levenshtein = struct
  let (@) = String.unsafe_get

  (* It is not tail recursive, but so far I am happy *)    
  let dist_non_tco s1 s2 =
    let lev lev_fix (i, j) = match i, j with
      | -1, d | d, -1 -> max d 0
      | _ ->
          min (lev_fix (i-1, j) + 1)
          & min (lev_fix (i, j-1) + 1)
                (lev_fix (i-1, j-1) + if s1@i = s2@j then 0 else 1)
    in
    memoize_rec lev (String.length s1 - 1, String.length s2 - 1)
end

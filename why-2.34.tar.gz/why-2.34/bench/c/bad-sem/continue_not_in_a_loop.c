void f() { continue; }

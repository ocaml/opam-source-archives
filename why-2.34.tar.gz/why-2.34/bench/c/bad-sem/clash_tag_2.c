struct S { int x; };
union S { double f; };


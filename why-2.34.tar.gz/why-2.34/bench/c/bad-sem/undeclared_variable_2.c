void f() { x = 1; }


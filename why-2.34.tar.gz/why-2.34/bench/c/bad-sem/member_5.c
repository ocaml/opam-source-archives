int s;
void f() { s->x = 0; } /* invalid type argument of `->' */


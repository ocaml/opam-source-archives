typedef int x = 0;

ppx_monadic
=================================

ppx_monadic is a PPX syntax extension for monadic 'do' notation.

ppx_monadic follows the tradition of pa_monad, a CamlP4 syntax extension
for `do` notation. Basically code with pa_monad should work with ppx_monadic
only by replacing `perform` by `do_;`. (I find `perform` is bit too long to type.)

`do_;` clause
========================================

`do_;` (and also `M.do_;` for a module path `M`) is treated as a new keyword in ppx_monadic. It can only appear at the head of an expresison. `do_;` introduces syntactic sugar for the monadic operations against the expressions followed by it as far as they are sequenced using `;`. Therefore a `do_;` clause looks like:

```ocaml
do_
; e1
; ..
; en
```

or

```
M.do_
; e1
; ..
; en
```

You cannot omit `;` after `do_`. (`do_ x <-- e` is parsed as `(do_ x) <-- e` which is troublesome).

Syntactic sugar inside `do_;` clauses
========================================

Bind: `[%p? p] <-- e1; e2`
--------------------------

`[%p? p] <-- e1; e2` is desugared to:

```
bind e1 (fun p -> e2')
```

when `e2` is desugared to `e2'`. You can write any pattern `p` inside `[%p? ..]` as opposed to the following `p <-- e1; e2`.

`bind` must be available in the scope so that the desugared expression can be properly compiled.

Simplified bind: `p <-- e1; e2`
-----------------------------------

`p <-- e1; e2` is desugared to

```
bind e1 (fun p -> e2')
```

when `e2` is desugared to `e2'`. The syntax of the pattern `p` is limited to those which are compatible as expressions. For example, you cannot write `(Foo x as y) <- e1; e2` since `Foo x as y` is not a valid expression. For such complex patterns you must use `[%p? p] <-- e1; e2`, ex. `[%p? (Foo x as y)] <-- e1; e2`.

Bind with unit: `e1; e2`
-----------------------

`e1; e2` is desugared to

```
bind e1 (fun () -> e2')
```

when `e2` is desugared to `e2'`.

Escape: `(); e1; e2`
---------------------------

Inside `do_;`, the syntax for sequence execution `e1; e2` is overridden 
by the monadic bind. We need another syntax sugar to recover the original
semantics of `;`.

`(); e1; e2` is desugared to

```
e1; e2'
```

when `e2` is desugared to `e2'`.

Lets: `let p = e1 in e2`, `let module` and `let open`
-------------------------------------------------------------------------

`do_;` also desugars `let` body expressions. For example `let p = e1 in e2`
is desugared to `let p = e1 in e2'` when `e2` is desugared to `e2'`.

Extensions: `[%ext e]`
-------------------------------------------------------------------------

`do_;` also desugars the expressions inside extensions `[%ext ..]`,
including `let%ext p = e in e'`.

If you do not want `do_;` desugar the internal of your extension,
use `(); [%your_ext ..]` to escape it.

With a module path: `M.do_;`
========================================

`do_;` clause with a module path, `M.do_;`, has the same syntactic sugar as `do_;` but adds `let open M in` at the head of the desugared expression in addition. For example, `Option.do_; x <- e1; e2` is desugared to:

```
let open Option in
bind e1 (fun x -> e2')
```

when `e2` is desugared to `e2'`. This is convenient when `bind` and other monadic operators are defined in the module specified by the module path.

Notation `let%m`
==================================

`let%m p = e1 in e2` is another form of `[%p? p] <-- e1; e2` and desugared to

```
bind e1 (fun p -> e2')
```

when `e2` is desugared to `e2'`. `let%m` is not required inside `do_`. You can also write `let%M.m p = e1 in e2` which uses `M.bind`.

You cannot currently write more than one bindings in `let%m`: `let%m p1 = e1 and p2 = e2 in e` is invalid. 

Difference between Haskell's `do` notation
===========================================

ppx_monadic is different from Haskell's `do` notation in the following points:

* `do_;`: We cannot use `do` since it is a keyword in OCaml which cannot be used at the head of expressions.
* `<--`: We cannot use `<-` since it is for record/object field mutation in OCaml.
* `(); e1; e2`: OCaml is impure and side effects are often used even inside `do_;`. `(); e;` is to regain the original meaning of `;`.

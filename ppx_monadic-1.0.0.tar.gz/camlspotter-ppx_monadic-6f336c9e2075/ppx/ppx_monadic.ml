open Ppxx (* must come after Ast_helper *)
open Ast_mapper
open Parsetree
open Longident
open Location

let is_m s =
  match Longident.parse s with
  | Lident "m" -> Some None
  | Ldot (l, "m") -> Some (Some l)
  | _ -> None
  | exception _ -> None

let is_do e = match e.pexp_desc with
  | Pexp_ident {txt=Lident "do_"} -> Some None
  | Pexp_ident {txt=Ldot (lid, "do_"); loc} -> Some (Some {txt=lid; loc})
  | _ -> None
  
let is_do_clause e = match e.pexp_desc with
  | Pexp_sequence (e1, e2) -> 
      (* e1; e2; e3   is  e1; (e2; e3) *)
      begin match is_do e1 with
      | None -> None
      | Some lo -> Some (lo, e2)
      end
  | _ ->
      match is_do e with
      | None -> None
      | Some _ ->
          raise_errorf ~loc:e.pexp_loc "ppx_monadic: do_ must be followed by ;"

let is_bind e = 
  match e.pexp_desc with
  | Pexp_apply({ pexp_desc= Pexp_ident({txt=Lident "<--"}) }, [("",p); ("",e)]) ->
      begin match Pat.of_expr p with
      | `Ok p -> Some (p, e)
      | `Error e ->
          raise_errorf ~loc:e.pexp_loc "ppx_monadic: the left hand side of <-- must be a pattern"
      end
  | Pexp_apply({ pexp_desc= Pexp_ident({txt=Lident "<--"}) }, _) ->
      raise_errorf ~loc:e.pexp_loc "ppx_monadic: syntax error of <--. It must have the form p <-- e"
  | _ -> None

let is_unit e = match e.pexp_desc with
  | Pexp_construct ({txt=Lident "()"}, None) -> true
  | _ -> false

let rec desugar_do e = match e.pexp_desc with
  | Pexp_sequence ( u, { pexp_desc= Pexp_sequence( e1, e2 ) } ) when is_unit u ->
      (* <(); e1; e2> => e1; <e2> *) 
      [%expr [%e e1] ; [%e desugar_do e2] ]

  | Pexp_sequence ( u, e ) when is_unit u -> 
      (* <(); e> => e *) 
      e

  | Pexp_sequence ({ pexp_desc = Pexp_sequence _; pexp_loc=loc }, _) ->
      (* <do_; ..; (e1; e2); ..> => error *) 
      raise_errorf ~loc "ppx_monadic: do_; cannot take a nested sequence. It must be flattened"
      
  | Pexp_sequence (e1, e2) ->
      begin match is_bind e1 with
      | Some (p, e) ->
          (* <p <-- e1; e2> => bind e1 (fun p -> <e2>)  *)
          [%expr 
              bind [%e e] (fun [%p p] -> [%e desugar_do e2])
          ]
      | None ->
          (* <e1; e2> => bind e1 (fun () -> <e2>) *)
          [%expr
              bind [%e e1] (fun () -> [%e desugar_do e2])
          ]
      end

  | Pexp_let(rf, vbs, e) ->
      (* <let p = e1 in e2> => let p = e1 in <e2> *)
      { e with pexp_desc = Pexp_let (rf, vbs, desugar_do e) }  
      
  | Pexp_letmodule(s, mexp, e) ->
      (* <let module M = mexp in e2> => let module M = mexp in <e2> *)
      { e with pexp_desc = Pexp_letmodule(s, mexp, desugar_do e) }  
      
  | Pexp_open(ov, lid, e) ->
      (* <let open M in e2> => let open M in <e2> *)
      { e with pexp_desc = Pexp_open(ov, lid, desugar_do e) }  
      
  | Pexp_extension ( ext,
                     PStr [({ pstr_desc= Pstr_eval (exp, attr) } as sitem)]) ->
      (* <let%m p = e1 in e2> => let%m p = e1 in <e2> 
         
         If you do not want ppx_monadic invades in your extension,
         use (); [%your_ext ..];
      *)
      { e with pexp_desc =
          Pexp_extension ( ext,
                           PStr [{ sitem with pstr_desc = Pstr_eval ( desugar_do exp, attr) }]) }

  | _ ->
      begin match is_bind e with
      | Some _ ->
          raise_errorf ~loc:e.pexp_loc "ppx_monadic: the last expression of do_; clause cannot have the form p <-- e"
      | None -> e
      end

let extend super = 
  let expr self e = 
    match is_do_clause e with
    | Some (None, e) ->
        (* Format.eprintf "do_ clause: %a@." Pprintast.expression e; *)
        self.expr self & desugar_do e
    | Some (Some lid, e) ->
        (* Format.eprintf "do_ clause: %a@." Pprintast.expression e; *)
        self.expr self & Exp.open_ Fresh lid & desugar_do e
    | None ->
        match e.pexp_desc with
        | Pexp_extension ({txt=x; loc}, PStr [{ pstr_desc= Pstr_eval ({ pexp_desc = Pexp_let(rec_flag, vbs, e)}, _attr) }]) ->
            (* let%XXX p = e1 in e2 *)
            begin match is_m x with
            | None -> super.expr self e
            | Some lidopt ->
                if rec_flag = Recursive then
                  raise_errorf ~loc:e.pexp_loc "ppx_monadic: let%%m cannot be recursive";
                match vbs with
                | [] -> assert false (* impos *)
                | [vb] ->
                    let bind = match lidopt with
                      | None -> [%expr bind]
                      | Some l -> Exp.ident ~loc {txt= Ldot (l, "bind"); loc}
                    in
                    self.expr self
                    & [%expr
                           [%e bind] [%e vb.pvb_expr] (fun [%p vb.pvb_pat] -> [%e e])
                       ]
                | _ ->
                    raise_errorf ~loc:e.pexp_loc "ppx_monadic: let%%m can take only one binding"
            end
        | _ -> super.expr self e
  in
  { super with expr }

let mapper = extend default_mapper

let () = Ppxx.run "ppx_monadic" mapper

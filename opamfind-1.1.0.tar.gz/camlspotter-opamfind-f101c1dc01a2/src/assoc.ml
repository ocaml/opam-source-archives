open Spotlib.Spot
open Utils
open List

open Ppx_orakuda.Regexp.Re_pcre.Infix
open Ppx_orakuda.Regexp.Re_pcre.Literal

let init () =
  let stdlib_dir, packages = Ocamlfind.get () in
  let sw = Opam.Switch.get () in
  if File.contains sw.Opam.Switch.prefix stdlib_dir = None then
    failwithf "Error: We cannot proceed since stdlib dir %s is not under OPAM switch dir %s"
      stdlib_dir sw.Opam.Switch.prefix;
  stdlib_dir, packages, sw

let is_valid_meta path =
  match File.to_lines path with
  | `Error (`Exn e) -> raise e
  | `Ok ls ->
      not & flip exists ls & fun l -> l =~ {m|version\s*=\s*"\[.*\]"|m} <> None

let get_fingerprint_files ?(deep=false) dir = 
  Unix.Find.fold [dir] [] & fun st path ->
    match path#base with
    | "META" when path#is_reg ->
        `Continue,
        if is_valid_meta path#path then path#path :: st
        else st
    | (".hg" | ".git") when path#is_dir -> `Prune, st
    | s ->
        match snd (Filename.split_extension s) with
        | ".cmi" (* | ".cmo" | ".cma" | ".cmxa" | ".cmxs" *) -> `Continue, path#path :: st
        | _ -> if not deep && path#depth > 0 then `Prune, st else `Continue, st

type fingerprint = (string * ((string, [`Exn of exn]) Result.t) Lazy.t) list

let get_fingerprint ?deep dir : fingerprint =
  let paths = get_fingerprint_files ?deep dir in
  map (fun p -> (p, lazy (Exn.catch Digest.file p))) paths

let compare_fingerprints ocamlfind ~in_:opam =
  let (!!) = Lazy.force in
  let compare_name x y = match x, y with
    | "META", "META" -> 0
    | "META", _ -> -1
    | _, "META" -> 1
    | _ -> compare x y
  in
  (* Check META first *)
  let ocamlfind = sort (fun (p,_) (p',_) ->
    compare_name (Filename.basename p) (Filename.basename p')) ocamlfind
  in
  let check_ocamlfind (p,d) =
    flip exists opam & fun (p',d') ->
      Filename.basename p = Filename.basename p'
      && match !!d, !!d' with
      | `Ok d, `Ok d' -> d = d'
      | _ -> false
  in
  let rec loop found = function
    | f::fs ->
        let found = if check_ocamlfind f then fst f :: found else found in
        if length found >= 5 then `Ok found
        else loop found fs
    | [] -> `Error (found, map fst ocamlfind)
  in
  loop [] ocamlfind

let debug = ref false

let associate ocapgs opams =
  let open Ocamlfind in
  let open Package in
  let open Analyzed in
  let open Analyzed_group in
  let ocfingers = 
    flip map ocapgs & fun apg -> (apg, get_fingerprint (hd apg.packages).package.dir) 
  in
  let found = flip map opams & fun opam ->
    let opfinger = get_fingerprint ~deep:true & Opam.Package.build_dir opam in
    let res = 
      flip filter_map ocfingers & fun (apg,ocfinger) ->
        (* OCaml distributed packages are not installed by any Opam package.
           This prevents compiler-libs is misconsidered as installed by camlp4,
           which copies the compilier-libs code..
           But camlp4 itself has version "[distributed with Ocaml]", which is not good!
        *)
        if 
          apg.name <> "camlp4"
          && let p = (hd apg.packages).package in is_distributed_with_ocaml p
        then
          if opam.Opam.Package.name = "ocaml" then Some (apg, []) else None
        else
          match compare_fingerprints ocfinger ~in_:opfinger with
          | `Ok found -> Some (apg, found)
          | `Error ([],[]) -> None
          | `Error (n,all) when length n > 0 && length n >= length all / 2 -> Some (apg,n)
              (* META can be different (cppo.1.3.2/META and lib/cppo_ocamlbuild/META) *)
          | `Error (_n,_all) -> None
    in
    begin match res with
    | [] ->
        !!% "warning: Opam %a : no associatable OCamlFind package found@."
          Opam.Package.format opam
    | res ->
        if !debug then !!% "Opam %a : @[%a@]@."
          Opam.Package.format opam
          (Ocaml.format_with [%derive.ocaml_of: (string * string list) list]) (map (fun (x,fs) -> x.Ocamlfind.Analyzed_group.name, fs) res)
    end;
    opam, res
  in
  let rev_found = 
    flip map ocapgs & fun apg ->
      (apg, 
       flip filter_map found & fun (opam, res) ->
         let found = flip exists res & fun (apg', _) -> 
           apg.name = apg'.name 
         in
         if found then Some opam else None)
  in
  flip iter rev_found (fun (apg, opams) ->
    match opams with
    | [] ->
        if not & for_all (fun ap -> Ocamlfind.Package.is_distributed_with_ocaml (ap.Analyzed.package)) apg.packages then 
          !!% "Warning: OCamlFind: %s: no associated Opam package found@." apg.name
    | [o] -> if !debug then !!% "%s: %a@." apg.name Opam.Package.format o
    | os -> 
        !!% "@[<2>Warning: OCamlFind package %s is provided more than one OPAM package?: @[%a@]@]@." 
          apg.name 
          (Format.list ";@ " Opam.Package.format) os);
  found, rev_found
    
let test () =
  let open Ocamlfind in
  let ocapgs = 
    let stdlib_dir, packages = get () in
    map (analyze_group ~stdlib_dir)
    & Ocamlfind.group packages
  in
  let sw = Opam.Switch.get () in
  let opams = Opam.get_installed sw in
  let _ = associate ocapgs opams in
  ()

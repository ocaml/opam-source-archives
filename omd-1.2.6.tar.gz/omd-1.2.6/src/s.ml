let rec p x =
  let f x = Printf.printf"z%!"; p (List.rev[2;3;2;1]) in
  f []

let _ = p []

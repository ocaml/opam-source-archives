# CamlON: Caml Object Notion

CamlON is JSON in OCaml, a tree like data type structure with OCaml values'
look and feel.

# License

CamlON contains module sources from OCaml compiler.  Therefore its license
follows the one of "the OCaml Core System": GNU Lesser General Public License
(LGPL) version 2.1 (included below) with a special linking exception.
See the file LICENSE for more details.


type t = int * [ `Foo of int | `Bar as "BAR" ] with conv(json)


(* OASIS_START *)
(* DO NOT EDIT (digest: 8b12e84a141fffe2e2bd716dd9db9224) *)

tiny_json - A small Json library from OCAMLTTER
===============================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

tiny_json is distributed under the terms of the GNU Lesser General Public
License version 2.0 with OCaml linking exception.

(* OASIS_STOP *)

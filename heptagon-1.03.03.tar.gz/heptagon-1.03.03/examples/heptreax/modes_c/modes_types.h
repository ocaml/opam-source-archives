/* --- Generated the 4/3/2017 at 14:3 --- */
/* --- heptagon compiler, version 1.03.02 (compiled thu. mar. 2 17:43:26 CET 2017) --- */
/* --- Command line: /home/gwen/bin/heptc.byte -target c -target ctrln modes.ept --- */

#ifndef MODES_TYPES_H
#define MODES_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
#include "modes_controller_types.h"
typedef enum {
  Modes__St_Up,
  Modes__St_Down
} Modes__st;

Modes__st Modes__st_of_string(char* s);

char* string_of_Modes__st(Modes__st x, char* buf);

#endif // MODES_TYPES_H

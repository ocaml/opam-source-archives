/* --- Generated the 4/3/2017 at 14:3 --- */
/* --- heptagon compiler, version 1.03.02 (compiled thu. mar. 2 17:43:26 CET 2017) --- */
/* --- Command line: /home/gwen/bin/heptc.byte -target c -target ctrln modes.ept --- */

#ifndef MODES_H
#define MODES_H

#include "modes_types.h"
#include "modes_controller.h"
typedef struct Modes__twomodes_mem {
  Modes__st ck;
  int pnr;
  int y_1;
} Modes__twomodes_mem;

typedef struct Modes__twomodes_out {
  int o;
} Modes__twomodes_out;

void Modes__twomodes_reset(Modes__twomodes_mem* self);

void Modes__twomodes_step(int v, Modes__twomodes_out* _out,
                          Modes__twomodes_mem* self);

#endif // MODES_H

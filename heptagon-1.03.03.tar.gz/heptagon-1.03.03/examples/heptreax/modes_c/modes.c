/* --- Generated the 4/3/2017 at 14:3 --- */
/* --- heptagon compiler, version 1.03.02 (compiled thu. mar. 2 17:43:26 CET 2017) --- */
/* --- Command line: /home/gwen/bin/heptc.byte -target c -target ctrln modes.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "modes.h"

void Modes__twomodes_reset(Modes__twomodes_mem* self) {
  self->ck = Modes__St_Up;
  self->pnr = false;
  self->y_1 = 0;
}

void Modes__twomodes_step(int v, Modes__twomodes_out* _out,
                          Modes__twomodes_mem* self) {
  Modes_controller__twomodes_ctrlr0_out Modes_controller__twomodes_ctrlr0_out_st;
  
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v_1;
  int c;
  int v_7;
  int v_8;
  int nr_St_Down;
  Modes__st ns_St_Down;
  int y_St_Down;
  int nr_St_Up;
  Modes__st ns_St_Up;
  int y_St_Up;
  Modes__st ns;
  int r;
  int nr;
  int y;
  r = self->pnr;
  switch (self->ck) {
    case Modes__St_Down:
      y_St_Down = (self->y_1-v);
      y = y_St_Down;
      break;
    case Modes__St_Up:
      y_St_Up = (self->y_1+v);
      y = y_St_Up;
      break;
    default:
      break;
  };
  _out->o = y;
  Modes_controller__twomodes_ctrlr0_step(self->ck, self->pnr, v, self->y_1,
                                         &Modes_controller__twomodes_ctrlr0_out_st);
  c = Modes_controller__twomodes_ctrlr0_out_st.c;
  switch (self->ck) {
    case Modes__St_Down:
      v_7 = !(c);
      if (v_7) {
        ns_St_Down = Modes__St_Up;
        nr_St_Down = true;
      } else {
        ns_St_Down = Modes__St_Down;
        nr_St_Down = false;
      };
      ns = ns_St_Down;
      nr = nr_St_Down;
      break;
    case Modes__St_Up:
      v_8 = !(c);
      if (v_8) {
        ns_St_Up = Modes__St_Down;
      } else {
        ns_St_Up = Modes__St_Up;
      };
      ns = ns_St_Up;
      if (v_8) {
        nr_St_Up = true;
      } else {
        nr_St_Up = false;
      };
      nr = nr_St_Up;
      break;
    default:
      break;
  };
  self->ck = ns;
  self->pnr = nr;
  self->y_1 = y;
  v_1 = (v<=1);
  v_2 = (v>=0);
  v_3 = (v_1&&v_2);
  v_4 = (_out->o<=10);
  v_5 = (_out->o>=0);
  v_6 = (v_4&&v_5);;
}


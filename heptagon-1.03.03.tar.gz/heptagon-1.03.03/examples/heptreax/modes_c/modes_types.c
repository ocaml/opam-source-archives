/* --- Generated the 4/3/2017 at 14:3 --- */
/* --- heptagon compiler, version 1.03.02 (compiled thu. mar. 2 17:43:26 CET 2017) --- */
/* --- Command line: /home/gwen/bin/heptc.byte -target c -target ctrln modes.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "modes_types.h"

Modes__st Modes__st_of_string(char* s) {
  if ((strcmp(s, "St_Up")==0)) {
    return Modes__St_Up;
  };
  if ((strcmp(s, "St_Down")==0)) {
    return Modes__St_Down;
  };
}

char* string_of_Modes__st(Modes__st x, char* buf) {
  switch (x) {
    case Modes__St_Up:
      strcpy(buf, "St_Up");
      break;
    case Modes__St_Down:
      strcpy(buf, "St_Down");
      break;
    default:
      break;
  };
  return buf;
}


/* --- Generated the 10/2/2017 at 12:35 --- */
/* --- heptagon compiler, version 1.03.02 (compiled fri. feb. 10 9:52:16 CET 2017) --- */
/* --- Command line: /home/gwen/.opam/4.02.3/bin/heptc -target c -target ctrln twomodes.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "twomodes_types.h"

Twomodes__st Twomodes__st_of_string(char* s) {
  if ((strcmp(s, "St_Up")==0)) {
    return Twomodes__St_Up;
  };
  if ((strcmp(s, "St_Down")==0)) {
    return Twomodes__St_Down;
  };
}

char* string_of_Twomodes__st(Twomodes__st x, char* buf) {
  switch (x) {
    case Twomodes__St_Up:
      strcpy(buf, "St_Up");
      break;
    case Twomodes__St_Down:
      strcpy(buf, "St_Down");
      break;
    default:
      break;
  };
  return buf;
}


/* --- Generated the 10/2/2017 at 12:35 --- */
/* --- heptagon compiler, version 1.03.02 (compiled fri. feb. 10 9:52:16 CET 2017) --- */
/* --- Command line: /home/gwen/.opam/4.02.3/bin/heptc -target c -target ctrln twomodes.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "twomodes.h"

void Twomodes__twomodes_reset(Twomodes__twomodes_mem* self) {
  self->ck = Twomodes__St_Up;
  self->pnr = false;
  self->y_1 = 0;
}

void Twomodes__twomodes_step(int v, Twomodes__twomodes_out* _out,
                             Twomodes__twomodes_mem* self) {
  
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v_1;
  int v_7;
  int v_8;
  int nr_St_Down;
  Twomodes__st ns_St_Down;
  int y_St_Down;
  int nr_St_Up;
  Twomodes__st ns_St_Up;
  int y_St_Up;
  Twomodes__st ns;
  int r;
  int nr;
  int y;
  r = self->pnr;
  switch (self->ck) {
    case Twomodes__St_Down:
      y_St_Down = (self->y_1-v);
      y = y_St_Down;
      v_7 = (y<=0);
      if (v_7) {
        ns_St_Down = Twomodes__St_Up;
        nr_St_Down = true;
      } else {
        ns_St_Down = Twomodes__St_Down;
        nr_St_Down = false;
      };
      ns = ns_St_Down;
      nr = nr_St_Down;
      break;
    case Twomodes__St_Up:
      y_St_Up = (self->y_1+v);
      y = y_St_Up;
      v_8 = (y>=10);
      if (v_8) {
        ns_St_Up = Twomodes__St_Down;
      } else {
        ns_St_Up = Twomodes__St_Up;
      };
      ns = ns_St_Up;
      if (v_8) {
        nr_St_Up = true;
      } else {
        nr_St_Up = false;
      };
      nr = nr_St_Up;
      break;
    default:
      break;
  };
  _out->o = y;
  self->ck = ns;
  self->pnr = nr;
  self->y_1 = y;
  v_1 = (v<=1);
  v_2 = (v>=0);
  v_3 = (v_1&&v_2);
  v_4 = (_out->o<=10);
  v_5 = (_out->o>=0);
  v_6 = (v_4&&v_5);;
}


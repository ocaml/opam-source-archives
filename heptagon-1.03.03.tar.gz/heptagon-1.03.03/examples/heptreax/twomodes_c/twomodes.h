/* --- Generated the 10/2/2017 at 12:35 --- */
/* --- heptagon compiler, version 1.03.02 (compiled fri. feb. 10 9:52:16 CET 2017) --- */
/* --- Command line: /home/gwen/.opam/4.02.3/bin/heptc -target c -target ctrln twomodes.ept --- */

#ifndef TWOMODES_H
#define TWOMODES_H

#include "twomodes_types.h"
typedef struct Twomodes__twomodes_mem {
  Twomodes__st ck;
  int pnr;
  int y_1;
} Twomodes__twomodes_mem;

typedef struct Twomodes__twomodes_out {
  int o;
} Twomodes__twomodes_out;

void Twomodes__twomodes_reset(Twomodes__twomodes_mem* self);

void Twomodes__twomodes_step(int v, Twomodes__twomodes_out* _out,
                             Twomodes__twomodes_mem* self);

#endif // TWOMODES_H

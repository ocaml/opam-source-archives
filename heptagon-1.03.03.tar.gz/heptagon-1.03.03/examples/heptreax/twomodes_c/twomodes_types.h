/* --- Generated the 10/2/2017 at 12:35 --- */
/* --- heptagon compiler, version 1.03.02 (compiled fri. feb. 10 9:52:16 CET 2017) --- */
/* --- Command line: /home/gwen/.opam/4.02.3/bin/heptc -target c -target ctrln twomodes.ept --- */

#ifndef TWOMODES_TYPES_H
#define TWOMODES_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Twomodes__St_Up,
  Twomodes__St_Down
} Twomodes__st;

Twomodes__st Twomodes__st_of_string(char* s);

char* string_of_Twomodes__st(Twomodes__st x, char* buf);

#endif // TWOMODES_TYPES_H

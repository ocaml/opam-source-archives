open Containers

open Compiler

let tool_name = ref "Rotor"

let version = "0.1"
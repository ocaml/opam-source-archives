let bar x = x

let foo x = x
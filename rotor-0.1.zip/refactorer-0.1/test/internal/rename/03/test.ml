let hd x = x

open List

let foo x = hd x
let foo x y = x

let foo x = x

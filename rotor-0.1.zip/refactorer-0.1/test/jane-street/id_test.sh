#!/bin/bash
if [[ "$1" =~ ^[_a-zA-Z].* ]]; then
  exit 0
else
  exit 1
fi

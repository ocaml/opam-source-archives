#!/bin/bash
opam config exec --switch rotor-testbed -- jbuilder clean

#!/bin/bash
cp ./_build/log "$1"

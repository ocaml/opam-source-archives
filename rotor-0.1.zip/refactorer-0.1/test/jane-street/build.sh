#!/bin/bash
opam config exec --switch rotor-testbed -- jbuilder build > /dev/null 2>&1

open Camlp4                                             (* -*- camlp4of -*- *)

module Id : Sig.Id = struct
  let name = "pa_command"
  let version = "1.0"
end

module Make (Syntax : Sig.Camlp4Syntax) = struct
  (* open Sig *)
  include Syntax

  module Pa_format = Pa_format.Make(Syntax) 

  let parse stopat _loc _loc_var_opt s =
    match Pa_format.parse stopat _loc _loc_var_opt s with
    | (`Const _ | `Fun _), Some rem ->
        let pos = String.length s - String.length rem in
        raise (Lexformat.Error (pos, pos + 1,
		                Printf.sprintf "Unescaped special character %C found" rem.[0]))
    | `Const s, _ -> <:expr<command $s$>>
    | `Fun (_abss, f), _ -> 
	f <:expr<
	    Printf.ksprintf command
	  >>
  ;;

  let _ =
    Syntax.Quotation.add "qx"
      Syntax.Quotation.DynAst.expr_tag
      (parse []);

    Syntax.Quotation.add "$qx"
      Syntax.Quotation.DynAst.expr_tag
      (parse ['`']);

    Syntax.Quotation.add "qx"
      Syntax.Quotation.DynAst.str_item_tag
      (fun _loc _loc_var_opt s ->
	let e = parse [] _loc _loc_var_opt s in
	<:str_item< $exp:e$ >>);

    Syntax.Quotation.add "$qx"
      Syntax.Quotation.DynAst.str_item_tag
      (fun _loc _loc_var_opt s ->
	let e = parse ['`'] _loc _loc_var_opt s in
	<:str_item< $exp:e$ >>)
    ;;
end


let module M = Register.OCamlSyntaxExtension(Id)(Make) in ()

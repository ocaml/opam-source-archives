let with_compacts f v =
  let stat_before = 
    Gc.compact ();
    Gc.stat ()
  in

  Exn.protect_with f v
    ~finally:(fun _ ->
      let stat_after =
        Gc.compact ();
        Gc.stat ()
      in
      stat_before, stat_after)

type t = { l: p; r: n }


# R2PIPE-OCAML

This is a OCaml binding of R2Pipe. Please visit ![R2PipeAPI](https://github.com/radare/radare2/wiki/R2PipeAPI)
to learn about R2Pipe.R2Pipe.


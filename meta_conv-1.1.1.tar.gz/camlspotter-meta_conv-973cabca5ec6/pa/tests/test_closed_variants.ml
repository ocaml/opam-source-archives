type t = [ `Foo of int | `Bar as "BAR" ] with conv(json)


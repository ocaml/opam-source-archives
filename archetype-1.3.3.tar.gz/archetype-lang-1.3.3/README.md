# Archetype language

[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://github.com/edukera/archetype-lang/blob/master/LICENSE)
[![Build Status](https://travis-ci.org/edukera/archetype-lang.svg?branch=master)](https://travis-ci.org/edukera/archetype-lang)


Archetype is a general purpose language to develop Smart Contracts on the Tezos blockchain.

[Online documentation](https://archetype-lang.org/)
